scoreboard objectives add zmc dummy zmc
scoreboard players set @a[tag=!invshop] zmc 0
tag @a[tag=!invshop] add invshop
