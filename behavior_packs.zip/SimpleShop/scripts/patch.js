import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

/**
 * SBKK MARKET & EKONOMİ SİSTEMİ - ULTIMATE EDITION V5
 * Şifre: byzng08
 * Tüm sistemler korundu + 23 yeni özellik eklendi
 * İKON DESTEĞİ TÜM BUTONLARA ENTEGRE EDİLDİ
 */

// ==================== DIŞARIYA AÇILAN "Patch" ARAYÜZÜ ====================
// 04_military.js gibi diğer modüller globalThis.Krallik.Patch.init() bekliyor
// fakat bu dosya hiç "export" içermiyordu, hem de hiçbir yerden import
// edilmiyordu. Bu yüzden patch.js'in TÜM içeriği (market, açık artırma,
// krallık savaşları, sistem döngüsü vs.) hiç çalışmıyordu.
// Aşağıdaki export, "zmc" scoreboard objective'inin var olduğundan emin olur
// ve idempotent'tir (defalarca çağrılması güvenlidir).
let _zmcHazir = false;
function ensureZmcObjective() {
    if (_zmcHazir) return;
    try {
        if (!world.scoreboard.getObjective("zmc")) {
            world.scoreboard.addObjective("zmc", "ZMC");
        }
        _zmcHazir = true;
    } catch (e) {
        // world henüz hazır değilse (early-execution) sessizce geç, sonraki çağrıda tekrar denenir
    }
}

export const Patch = {
    init: ensureZmcObjective,
};

// ==================== VERİ YAPILARI VE GLOBAL DEĞİŞKENLER ====================
const orijinalFiyatlar = JSON.parse(JSON.stringify(getMagazaVerisi()));
let magazaVerisi = getMagazaVerisi();
let borsaKayitlari = [];
let piyasaYorumu = "Piyasa stabil, yatırımcılar beklemede.";
let sonGuncellemeGunu = -1;
let sonStokYenilemeGunu = 0;
const ADMIN_SIFRE = "byzng08";

let globalEnflasyonOrani = 1.0;
let aktifOlay = { ad: "Normal Seyir", etki: "Yok", tip: "NÖTR" };
let dunyaTicaretHacmi = 0;
let fiyatGecmisi = {};
let fiyatDonduruldu = false;
let havaDurumu = "GÜNEŞLİ";

// Savaş ve Diplomasi
let savasDurumlari = {};
let savasTeklifleri = {};
let ortaklikDurumlari = {};

// Tüccar Pazarı (Player Shops) -> Ticaret Loncası
let oyuncuDukkanlari = {};

// Açık Artırma
let acikArtirmalar = [];
let oyuncuArtirmaLimitleri = {};

// Krallık Sistemi
let kralliklar = {};
let oyuncuKralliklari = {};

// YENİ: Dinamik Ekonomi Verileri
let dinamikEkonomiVerisi = {};

// YENİ: Ekonomi Event Sistemi
let aktifEventler = [];
const EVENT_TANIMLARI = [
    { id: 'market_crash', ad: 'Piyasa Çöküşü', aciklama: 'Tüm fiyatlar %30 düşer!', fiyatMod: 0.7, sure: 1800, tip: 'dusus' },
    { id: 'ekonomi_patlamasi', ad: 'Ekonomi Patlaması', aciklama: 'Tüm fiyatlar %25 artar!', fiyatMod: 1.25, sure: 1200, tip: 'yukselis' },
    { id: 'ticaret_haftasi', ad: 'Ticaret Haftası', aciklama: 'Vergiler yarıya indi!', vergiMod: 0.5, sure: 3600, tip: 'indirim' },
    { id: 'bereket_donemi', ad: 'Bereket Dönemi', aciklama: 'Tarım ürünleri %40 ucuzladı!', kategoriMod: {kat: 'tarim', mod: 0.6}, sure: 2400, tip: 'indirim' },
    { id: 'maden_atesi', ad: 'Maden Ateşi', aciklama: 'Maden fiyatları %35 arttı!', kategoriMod: {kat: 'madenler', mod: 1.35}, sure: 1800, tip: 'yukselis' },
    { id: 'enflasyon_dalgasi', ad: 'Enflasyon Dalgası', aciklama: 'Enflasyon %15 arttı!', enflasyonMod: 0.15, sure: 3000, tip: 'enflasyon' },
    { id: 'indirim_gunu', ad: 'İndirim Günü', aciklama: 'Market fiyatları %20 düştü!', fiyatMod: 0.8, sure: 900, tip: 'indirim' }
];

// YENİ: Stok dalgalanma sistemi
let stokDalgalanmaZamani = 0;

// YENİ: Ekonomi haberleri
let ekonomiHaberleri = [];

// YENİ: İşlem güvenlik kayıtları
let islemGecmisi = [];
let supheliIslemler = [];

// YENİ: İkon özelleştirme kayıtları
let ozelIkonlar = {};

// Dedikodu mesajları
const DEDIKODU_MESAJLARI = [
    "{oyuncu} tam {miktar} adet {urun} stokladı! Piyasa hareketlenecek.",
    "{oyuncu} bugün {miktar} ZMC'lik dev satış yaptı.",
    "{oyuncu} ve {oyuncu2} arasında büyük bir ticaret anlaşması oldu.",
    "Piyasada {urun} kıtlığı başladı! Herkes stok yapıyor.",
    "{oyuncu} yeni unvan kazandı: {unvan}",
    "{oyuncu} krallığı {krallik} hızla büyüyor.",
    "Kervanlar yolda! {urun} fiyatları düşebilir.",
    "{oyuncu} az kalsın soyuluyordu! Güvenlik artırıldı."
];

// Görevler
const GUNLUK_GOREVLER = [
    { id: "alim_100", aciklama: "100 adet ürün satın al", hedef: 100, tip: "alim", odul: 500 },
    { id: "satis_50", aciklama: "50 adet ürün sat", hedef: 50, tip: "satis", odul: 400 },
    { id: "kar_1000", aciklama: "1000 ZMC kâr elde et", hedef: 1000, tip: "kar", odul: 300 },
    { id: "islem_10", aciklama: "10 farklı işlem yap", hedef: 10, tip: "islem", odul: 600 },
    { id: "hacim_5000", aciklama: "5000 ZMC ticaret hacmi yap", hedef: 5000, tip: "hacim", odul: 800 },
    { id: "dukkan_satis", aciklama: "Dükkanından 3 satış yap", hedef: 3, tip: "dukkan", odul: 1000 },
    { id: "acik_artirma", aciklama: "Açık artırmada 1 teklif ver", hedef: 1, tip: "acik_artirma", odul: 350 }
];

// Krallık avantaj/dezavantaj havuzu
const KRALLIK_AVANTAJLARI = [
    { id: 'savasci', ad: '🛡️ Savaşçı Krallık', aciklama: 'Savaş çarpanı 1.2x (daha az zarar)', tip: 'savas', deger: 0.8 },
    { id: 'tuccar', ad: '💰 Tüccar Krallık', aciklama: '%5 ek indirim', tip: 'indirim', deger: 0.05 },
    { id: 'bereketli', ad: '📦 Bereketli Krallık', aciklama: 'Stok yenileme 2 kat hızlı', tip: 'stok', deger: 2 },
    { id: 'pazar', ad: '🏪 Pazar Krallığı', aciklama: 'Dükkan vergisi %50 az', tip: 'dukkanVergi', deger: 0.5 },
    { id: 'hizli', ad: '⚡ Hızlı Krallık', aciklama: 'Açık artırma süresi %30 kısa', tip: 'artirma', deger: 0.7 },
    { id: 'guvenli', ad: '🔒 Güvenli Krallık', aciklama: 'Soygun riski %50 az', tip: 'soygun', deger: 0.5 }
];

const KRALLIK_DEZAVANTAJLARI = [
    { id: 'vergi_yuku', ad: '💸 Vergi Yükü', aciklama: '%3 ek vergi', tip: 'vergi', deger: 0.03 },
    { id: 'yavas', ad: '🐌 Yavaş Krallık', aciklama: 'Stok yenileme 2 kat yavaş', tip: 'stok', deger: 0.5 },
    { id: 'hedef', ad: '🎯 Hedef Krallık', aciklama: 'Soygun riski %50 fazla', tip: 'soygun', deger: 1.5 },
    { id: 'dalgalı', ad: '📉 Dalgalı Krallık', aciklama: 'Fiyatlar %10 daha dalgalı', tip: 'dalga', deger: 0.1 },
    { id: 'savas_cagrisi', ad: '🔥 Savaş Çağrısı', aciklama: 'Savaş çarpanı 1.3x (daha çok zarar)', tip: 'savas', deger: 1.3 }
];

// ==================== UNVAN SİSTEMİ (30+ UNVAN) ====================
const UNVAN_SISTEMI = [
    { minHacim: 0, unvan: "§7Acemi", indirim: 0.00, vergi: 0.12, bonus: 0, rozet: "⬜" },
    { minHacim: 5000, unvan: "§fÇırak", indirim: 0.01, vergi: 0.11, bonus: 100, rozet: "🔹" },
    { minHacim: 15000, unvan: "§aSatıcı", indirim: 0.02, vergi: 0.11, bonus: 250, rozet: "🔸" },
    { minHacim: 30000, unvan: "§2Esnaf", indirim: 0.03, vergi: 0.10, bonus: 500, rozet: "🟢" },
    { minHacim: 50000, unvan: "§eToptancı", indirim: 0.04, vergi: 0.10, bonus: 1000, rozet: "🟡" },
    { minHacim: 75000, unvan: "§6Temsilci", indirim: 0.05, vergi: 0.09, bonus: 1500, rozet: "🟠" },
    { minHacim: 100000, unvan: "§bLonca Üyesi", indirim: 0.06, vergi: 0.09, bonus: 2500, rozet: "🔷" },
    { minHacim: 150000, unvan: "§3Kaptan", indirim: 0.07, vergi: 0.08, bonus: 3500, rozet: "🔵" },
    { minHacim: 200000, unvan: "§9Deniz Tüccarı", indirim: 0.08, vergi: 0.08, bonus: 5000, rozet: "🌊" },
    { minHacim: 250000, unvan: "§5Kervan Başı", indirim: 0.09, vergi: 0.07, bonus: 7500, rozet: "🐫" },
    { minHacim: 300000, unvan: "§dUsta", indirim: 0.10, vergi: 0.07, bonus: 10000, rozet: "🟣" },
    { minHacim: 400000, unvan: "§cLord", indirim: 0.11, vergi: 0.06, bonus: 15000, rozet: "👑" },
    { minHacim: 500000, unvan: "§4Şehir Tüccarı", indirim: 0.12, vergi: 0.06, bonus: 20000, rozet: "🏙️" },
    { minHacim: 600000, unvan: "§eKraliyet Taciri", indirim: 0.13, vergi: 0.05, bonus: 30000, rozet: "🏰" },
    { minHacim: 750000, unvan: "§6İmparatorluk", indirim: 0.14, vergi: 0.05, bonus: 40000, rozet: "🏛️" },
    { minHacim: 1000000, unvan: "§bSpekülatör", indirim: 0.15, vergi: 0.04, bonus: 50000, rozet: "📊" },
    { minHacim: 1500000, unvan: "§3Bakan", indirim: 0.16, vergi: 0.04, bonus: 75000, rozet: "📋" },
    { minHacim: 2000000, unvan: "§9Hazine Lordu", indirim: 0.17, vergi: 0.03, bonus: 100000, rozet: "💰" },
    { minHacim: 3000000, unvan: "§5Altın Baron", indirim: 0.18, vergi: 0.03, bonus: 150000, rozet: "🥇" },
    { minHacim: 4000000, unvan: "§dElmas Kral", indirim: 0.19, vergi: 0.02, bonus: 200000, rozet: "💎" },
    { minHacim: 5000000, unvan: "§cPlatin Lord", indirim: 0.20, vergi: 0.02, bonus: 300000, rozet: "🔴" },
    { minHacim: 7500000, unvan: "§4Netherit İmp.", indirim: 0.21, vergi: 0.02, bonus: 500000, rozet: "🔥" },
    { minHacim: 10000000, unvan: "§eKüresel", indirim: 0.22, vergi: 0.01, bonus: 750000, rozet: "🌍" },
    { minHacim: 15000000, unvan: "§6Dev", indirim: 0.23, vergi: 0.01, bonus: 1000000, rozet: "🏆" },
    { minHacim: 20000000, unvan: "§bEfsane", indirim: 0.24, vergi: 0.01, bonus: 1500000, rozet: "⭐" },
    { minHacim: 30000000, unvan: "§3İmparator", indirim: 0.25, vergi: 0.00, bonus: 2500000, rozet: "👑" },
    { minHacim: 50000000, unvan: "§9Tanrı", indirim: 0.26, vergi: 0.00, bonus: 5000000, rozet: "⚡" },
    { minHacim: 75000000, unvan: "§5Hükümdar", indirim: 0.27, vergi: 0.00, bonus: 7500000, rozet: "🔱" },
    { minHacim: 100000000, unvan: "§dSonsuzluk", indirim: 0.28, vergi: 0.00, bonus: 10000000, rozet: "♾️" },
    { minHacim: 200000000, unvan: "§c§lBABA", indirim: 0.30, vergi: 0.00, bonus: 20000000, rozet: "💀" }
];

function getMagazaVerisi() {
    return {
        bloklar: [
            { id: "minecraft:grass", name: "Çimen", icon: "textures/blocks/grass_side_carried", buy: 5, sell: 2, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:dirt", name: "Toprak", icon: "textures/blocks/dirt", buy: 2, sell: 1, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:sand", name: "Kum", icon: "textures/blocks/sand", buy: 5, sell: 2, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:red_sand", name: "Kırmızı Kum", icon: "textures/blocks/red_sand", buy: 6, sell: 2, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:gravel", name: "Çakıl", icon: "textures/blocks/gravel", buy: 3, sell: 1, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:cobblestone", name: "Kırıktaş", icon: "textures/blocks/cobblestone", buy: 5, sell: 2, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:stone", name: "Taş", icon: "textures/blocks/stone", buy: 10, sell: 3, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:granite", name: "Granit", icon: "textures/blocks/stone_granite", buy: 15, sell: 5, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:diorite", name: "Diyorit", icon: "textures/blocks/stone_diorite", buy: 15, sell: 5, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:andesite", name: "Andezit", icon: "textures/blocks/stone_andesite", buy: 15, sell: 5, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:deepslate", name: "Derintaş", icon: "textures/blocks/deepslate", buy: 20, sell: 7, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:tuff", name: "Tüf", icon: "textures/blocks/tuff", buy: 20, sell: 7, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:obsidian", name: "Obsidyen", icon: "textures/blocks/obsidian", buy: 500, sell: 150, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:crying_obsidian", name: "Ağlayan Obsidyen", icon: "textures/blocks/crying_obsidian", buy: 800, sell: 240, buyCount: 0, sellCount: 0, stock: 200 },
            { id: "minecraft:clay", name: "Kil Bloğu", icon: "textures/blocks/clay", buy: 15, sell: 5, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:snow", name: "Kar Bloğu", icon: "textures/blocks/snow", buy: 10, sell: 3, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:ice", name: "Buz", icon: "textures/blocks/ice", buy: 25, sell: 8, buyCount: 0, sellCount: 0, stock: 800 },
            { id: "minecraft:blue_ice", name: "Mavi Buz", icon: "textures/blocks/ice_blue", buy: 150, sell: 50, buyCount: 0, sellCount: 0, stock: 300 }
        ],
        aletler: [
            { id: "minecraft:iron_sword", name: "Demir Kılıç", icon: "textures/items/iron_sword", buy: 600, sell: 150, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:iron_pickaxe", name: "Demir Kazma", icon: "textures/items/iron_pickaxe", buy: 600, sell: 150, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:iron_axe", name: "Demir Balta", icon: "textures/items/iron_axe", buy: 600, sell: 150, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:iron_shovel", name: "Demir Kürek", icon: "textures/items/iron_shovel", buy: 400, sell: 100, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:shears", name: "Makas", icon: "textures/items/shears", buy: 200, sell: 50, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:fishing_rod", name: "Olta", icon: "textures/items/fishing_rod_uncast", buy: 300, sell: 75, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:golden_sword", name: "Altın Kılıç", icon: "textures/items/gold_sword", buy: 500, sell: 120, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:diamond_sword", name: "Elmas Kılıç", icon: "textures/items/diamond_sword", buy: 2500, sell: 900, buyCount: 0, sellCount: 0, stock: 50 }
        ],
        kutukler: [
            { id: "minecraft:oak_log", name: "Meşe Kütüğü", icon: "textures/blocks/log_oak", buy: 110, sell: 35, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:spruce_log", name: "Ladin Kütüğü", icon: "textures/blocks/log_spruce", buy: 110, sell: 35, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:birch_log", name: "Huş Kütüğü", icon: "textures/blocks/log_birch", buy: 110, sell: 35, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:jungle_log", name: "Orman Kütüğü", icon: "textures/blocks/log_jungle", buy: 110, sell: 35, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:acacia_log", name: "Akasya Kütüğü", icon: "textures/blocks/log_acacia", buy: 110, sell: 35, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:dark_oak_log", name: "Koyu Meşe Kütüğü", icon: "textures/blocks/log_big_oak", buy: 110, sell: 35, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:mangrove_log", name: "Mangrov Kütüğü", icon: "textures/blocks/mangrove_log", buy: 110, sell: 35, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:cherry_log", name: "Kiraz Kütüğü", icon: "textures/blocks/cherry_log", buy: 220, sell: 75, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:crimson_stem", name: "Kızıl Sap (Nether)", icon: "textures/blocks/crimson_stem_side", buy: 130, sell: 40, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:warped_stem", name: "Yamuk Sap (Nether)", icon: "textures/blocks/warped_stem_side", buy: 130, sell: 40, buyCount: 0, sellCount: 0, stock: 500 }
        ],
        tarim: [
            { id: "minecraft:wheat", name: "Buğday", icon: "textures/items/wheat", buy: 30, sell: 12, buyCount: 0, sellCount: 0, stock: 2000 },
            { id: "minecraft:carrot", name: "Havuç", icon: "textures/items/carrot", buy: 25, sell: 10, buyCount: 0, sellCount: 0, stock: 2000 },
            { id: "minecraft:potato", name: "Patates", icon: "textures/items/potato", buy: 25, sell: 10, buyCount: 0, sellCount: 0, stock: 2000 },
            { id: "minecraft:beetroot", name: "Pancar", icon: "textures/items/beetroot", buy: 30, sell: 12, buyCount: 0, sellCount: 0, stock: 2000 },
            { id: "minecraft:sugar_cane", name: "Şeker Kamışı", icon: "textures/items/reeds", buy: 40, sell: 15, buyCount: 0, sellCount: 0, stock: 2000 },
            { id: "minecraft:pumpkin", name: "Kabak", icon: "textures/blocks/pumpkin_side", buy: 120, sell: 45, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:melon_block", name: "Karpuz Bloğu", icon: "textures/blocks/melon_side", buy: 120, sell: 45, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:cactus", name: "Kaktüs", icon: "textures/blocks/cactus_side", buy: 50, sell: 20, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:nether_wart", name: "Nether Siğili", icon: "textures/items/nether_wart", buy: 200, sell: 80, buyCount: 0, sellCount: 0, stock: 500 }
        ],
        yiyecek: [
            { id: "minecraft:bread", name: "Ekmek", icon: "textures/items/bread", buy: 50, sell: 15, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:cooked_beef", name: "Pişmiş İnek Eti", icon: "textures/items/beef_cooked", buy: 80, sell: 25, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:cooked_chicken", name: "Pişmiş Tavuk", icon: "textures/items/chicken_cooked", buy: 70, sell: 22, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:cooked_porkchop", name: "Pişmiş Domuz Eti", icon: "textures/items/porkchop_cooked", buy: 80, sell: 25, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:golden_apple", name: "Altın Elma", icon: "textures/items/apple_golden", buy: 800, sell: 250, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:enchanted_golden_apple", name: "Büyülü Elma", icon: "textures/items/apple_golden", buy: 25000, sell: 7000, buyCount: 0, sellCount: 0, stock: 10 },
            { id: "minecraft:cake", name: "Pasta", icon: "textures/items/cake", buy: 500, sell: 100, buyCount: 0, sellCount: 0, stock: 50 }
        ],
        madenler: [
            { id: "minecraft:coal", name: "Kömür", icon: "textures/items/coal", buy: 60, sell: 25, buyCount: 0, sellCount: 0, stock: 1500 },
            { id: "minecraft:iron_ingot", name: "Demir Külçesi", icon: "textures/items/iron_ingot", buy: 200, sell: 85, buyCount: 0, sellCount: 0, stock: 800 },
            { id: "minecraft:gold_ingot", name: "Altın Külçesi", icon: "textures/items/gold_ingot", buy: 400, sell: 180, buyCount: 0, sellCount: 0, stock: 500 },
            { id: "minecraft:copper_ingot", name: "Bakır Külçesi", icon: "textures/items/copper_ingot", buy: 100, sell: 40, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:diamond", name: "Elmas", icon: "textures/items/diamond", buy: 1800, sell: 800, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "minecraft:emerald", name: "Zümrüt", icon: "textures/items/emerald", buy: 1500, sell: 600, buyCount: 0, sellCount: 0, stock: 150 },
            { id: "minecraft:lapis_lazuli", name: "Lapis Lazuli", icon: "textures/items/lapis_lazuli", buy: 300, sell: 120, buyCount: 0, sellCount: 0, stock: 600 },
            { id: "minecraft:netherite_ingot", name: "Netherit Külçesi", icon: "textures/items/netherite_ingot", buy: 12000, sell: 5500, buyCount: 0, sellCount: 0, stock: 20 },
            { id: "minecraft:raw_iron", name: "Ham Demir", icon: "textures/items/raw_iron", buy: 150, sell: 60, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:raw_gold", name: "Ham Altın", icon: "textures/items/raw_gold", buy: 300, sell: 130, buyCount: 0, sellCount: 0, stock: 800 }
        ],
        hayvanCiftligi: [
            { id: "minecraft:leather", name: "Deri", icon: "textures/items/leather", buy: 20, sell: 8, buyCount: 0, sellCount: 0, stock: 2000 },
            { id: "minecraft:beef", name: "Çiğ İnek Eti", icon: "textures/items/beef_raw", buy: 30, sell: 12, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:chicken", name: "Çiğ Tavuk", icon: "textures/items/chicken_raw", buy: 25, sell: 10, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:porkchop", name: "Çiğ Domuz Eti", icon: "textures/items/porkchop_raw", buy: 30, sell: 12, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:mutton", name: "Çiğ Koyun Eti", icon: "textures/items/mutton_raw", buy: 30, sell: 12, buyCount: 0, sellCount: 0, stock: 1000 },
            { id: "minecraft:rabbit", name: "Çiğ Tavşan", icon: "textures/items/rabbit_raw", buy: 35, sell: 14, buyCount: 0, sellCount: 0, stock: 800 },
            { id: "minecraft:egg", name: "Yumurta", icon: "textures/items/egg", buy: 15, sell: 6, buyCount: 0, sellCount: 0, stock: 3000 },
            { id: "minecraft:feather", name: "Tüy", icon: "textures/items/feather", buy: 10, sell: 4, buyCount: 0, sellCount: 0, stock: 2000 },
            { id: "minecraft:wool", name: "Yün", icon: "textures/blocks/wool_colored_white", buy: 25, sell: 10, buyCount: 0, sellCount: 0, stock: 1500 }
        ],
        orduFransa: [
            { id: "knights:french_cuirassier_spawn_egg", name: "Fransa Atlı", icon: "textures/items/knights_french_cuirassier", buy: 5000, sell: 0, buyCount: 0, sellCount: 0, stock: 50 },
            { id: "knights:french_infantry_spawn_egg", name: "Fransa Piyade", icon: "textures/items/knights_french_infantry", buy: 3000, sell: 0, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "knights:napoleonic_flag_of_france_spawn_egg", name: "Fransa Bayrağı", icon: "textures/items/knights_flag_of_france", buy: 1000, sell: 0, buyCount: 0, sellCount: 0, stock: 20 }
        ],
        orduRusya: [
            { id: "knights:russian_cuirassier_spawn_egg", name: "Rusya Atlı", icon: "textures/items/knights_russian_cuirassier", buy: 5000, sell: 0, buyCount: 0, sellCount: 0, stock: 50 },
            { id: "knights:russian_infantry_spawn_egg", name: "Rusya Piyade", icon: "textures/items/knights_russian_infantry", buy: 3000, sell: 0, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "knights:napoleonic_flag_of_russia_spawn_egg", name: "Rusya Bayrağı", icon: "textures/items/knights_flag_of_russia", buy: 1000, sell: 0, buyCount: 0, sellCount: 0, stock: 20 }
        ],
        orduIngiltere: [
            { id: "knights:british_cuirassier_spawn_egg", name: "İngiltere Atlı", icon: "textures/items/knights_british_cuirassier", buy: 5000, sell: 0, buyCount: 0, sellCount: 0, stock: 50 },
            { id: "knights:british_infantry_spawn_egg", name: "İngiltere Piyade", icon: "textures/items/knights_british_infantry", buy: 3000, sell: 0, buyCount: 0, sellCount: 0, stock: 100 },
            { id: "knights:napoleonic_flag_of_united_kingdom_spawn_egg", name: "İngiltere Bayrağı", icon: "textures/items/knights_flag_of_united_kingdom", buy: 1000, sell: 0, buyCount: 0, sellCount: 0, stock: 20 }
        ]
    };
}

// ==================== YARDIMCI FONKSİYONLAR ====================
function getScore(p, obj) { try { const o = world.scoreboard.getObjective(obj); return o ? (o.getScore(p.scoreboardIdentity) ?? 0) : 0; } catch { return 0; } }
function setScore(p, obj, val) { p.runCommandAsync(`scoreboard players set @s ${obj} ${val}`); }

function getPrestigeLevel(player) {
    const hacim = player.getDynamicProperty("ticaret_hacmi") ?? 0;
    let mevcutUnvan = UNVAN_SISTEMI[0];
    for (const u of UNVAN_SISTEMI) {
        if (hacim >= u.minHacim) mevcutUnvan = u;
        else break;
    }
    return mevcutUnvan;
}

function addNotification(player, mesaj) {
    let bildirimler = JSON.parse(player.getDynamicProperty("bildirimler") ?? "[]");
    const tarih = new Date().toLocaleString();
    bildirimler.unshift({ tarih, mesaj, okundu: false });
    if (bildirimler.length > 50) bildirimler = bildirimler.slice(0, 50);
    player.setDynamicProperty("bildirimler", JSON.stringify(bildirimler));
}

function getItibar(player) { return player.getDynamicProperty("itibar") ?? 0; }
function addItibar(player, miktar) {
    let i = getItibar(player) + miktar;
    player.setDynamicProperty("itibar", Math.max(-100, Math.min(100, i)));
}

function getSavasDurumu(p1, p2) {
    const key1 = `${p1.name}:${p2.name}`;
    const key2 = `${p2.name}:${p1.name}`;
    return savasDurumlari[key1] || savasDurumlari[key2] || null;
}

function getOyuncuSavasCarpani(p) {
    let carpan = 1.0;
    for (const diger of world.getAllPlayers()) {
        if (diger.name === p.name) continue;
        const durum = getSavasDurumu(p, diger);
        if (durum && durum.tur === "savas") {
            const key = `${p.name}:${diger.name}`;
            const acanMi = savasDurumlari[key] !== undefined;
            carpan = acanMi ? 1.5 : 3.0;
            break;
        }
    }
    const krallik = oyuncuKralliklari[p.name];
    if (krallik && kralliklar[krallik]) {
        const k = kralliklar[krallik];
        if (k.avantaj === 'savasci') carpan *= 0.8;
        if (k.dezavantaj === 'savas_cagrisi') carpan *= 1.3;
        for (const [digerKrallik, durum] of Object.entries(k.savaslar || {})) {
            if (durum) carpan *= 2.0;
        }
    }
    return carpan;
}

function getOrtaklikIndirimi(p) {
    let indirim = 0;
    for (const diger of world.getAllPlayers()) {
        if (diger.name === p.name) continue;
        const durum = getSavasDurumu(p, diger);
        if (durum && durum.tur === "ortaklik") indirim = 0.12;
    }
    const krallik = oyuncuKralliklari[p.name];
    if (krallik && kralliklar[krallik] && kralliklar[krallik].avantaj === 'tuccar') indirim += 0.05;
    return indirim;
}

function getKrallikAvantaji(player) {
    const krallik = oyuncuKralliklari[player.name];
    if (!krallik || !kralliklar[krallik]) return null;
    return KRALLIK_AVANTAJLARI.find(a => a.id === kralliklar[krallik].avantaj) || null;
}

function getKrallikDezavantaji(player) {
    const krallik = oyuncuKralliklari[player.name];
    if (!krallik || !kralliklar[krallik]) return null;
    return KRALLIK_DEZAVANTAJLARI.find(d => d.id === kralliklar[krallik].dezavantaj) || null;
}

function findUrunById(id) {
    for (const kat of Object.keys(magazaVerisi)) {
        for (const urun of magazaVerisi[kat]) {
            if (urun.id === id) return urun;
        }
    }
    return null;
}

function getPortfoyDegeri(player) {
    let toplamDeger = getScore(player, "zmc");
    const hacim = player.getDynamicProperty("ticaret_hacmi") ?? 0;
    toplamDeger += Math.floor(hacim * 0.1);
    return toplamDeger;
}

function findItemCategory(item) {
    for (const [kat, urunler] of Object.entries(magazaVerisi)) {
        if (urunler.some(u => u.id === item.id)) return kat;
    }
    return null;
}

function isOrduKategori(kat) {
    return kat.toLowerCase().includes("ordu");
}

// İKON YÖNETİMİ
function getIcon(kategori, itemName) {
    const key = `${kategori}:${itemName}`;
    if (ozelIkonlar[key]) return ozelIkonlar[key];
    return null;
}

function setIcon(kategori, itemName, iconPath) {
    const key = `${kategori}:${itemName}`;
    if (iconPath && iconPath.trim()) {
        ozelIkonlar[key] = iconPath.trim();
    } else {
        delete ozelIkonlar[key];
    }
    world.setDynamicProperty("ozel_ikonlar", JSON.stringify(ozelIkonlar));
}

function loadIcons() {
    try {
        const saved = world.getDynamicProperty("ozel_ikonlar");
        if (saved) ozelIkonlar = JSON.parse(saved);
    } catch (e) {
        ozelIkonlar = {};
    }
}

// İkon çözümleyici: özel ikon varsa onu, yoksa varsayılanı döndürür
function resolveIcon(kategori, item, fallback) {
    const custom = getIcon(kategori, item);
    return custom && custom.trim() ? custom.trim() : (fallback || "textures/ui/icon_money");
}

// Envanter eşya listeleme
function getEnvanterEsyalari(player) {
    const esyalar = [];
    const container = player.getComponent("inventory")?.container;
    if (!container) return esyalar;
    for (let i = 0; i < container.size; i++) {
        const item = container.getItem(i);
        if (item && item.typeId && item.amount > 0) {
            const mevcut = esyalar.find(e => e.typeId === item.typeId);
            if (mevcut) mevcut.amount += item.amount;
            else esyalar.push({ typeId: item.typeId, amount: item.amount });
        }
    }
    return esyalar;
}

function getTurkceIsim(typeId) {
    for (const [kat, urunler] of Object.entries(magazaVerisi)) {
        for (const urun of urunler) {
            if (urun.id === typeId) return urun.name;
        }
    }
    const isimler = {
        "minecraft:diamond": "Elmas", "minecraft:iron_ingot": "Demir Külçesi",
        "minecraft:gold_ingot": "Altın Külçesi", "minecraft:emerald": "Zümrüt",
        "minecraft:coal": "Kömür", "minecraft:lapis_lazuli": "Lapis Lazuli",
        "minecraft:netherite_ingot": "Netherit Külçesi", "minecraft:copper_ingot": "Bakır Külçesi",
        "minecraft:raw_iron": "Ham Demir", "minecraft:raw_gold": "Ham Altın",
        "minecraft:oak_log": "Meşe Kütüğü", "minecraft:spruce_log": "Ladin Kütüğü",
        "minecraft:birch_log": "Huş Kütüğü", "minecraft:wheat": "Buğday",
        "minecraft:carrot": "Havuç", "minecraft:potato": "Patates",
        "minecraft:bread": "Ekmek", "minecraft:cooked_beef": "Pişmiş İnek Eti",
        "minecraft:cobblestone": "Kırıktaş", "minecraft:stone": "Taş",
        "minecraft:dirt": "Toprak", "minecraft:sand": "Kum",
        "minecraft:gravel": "Çakıl", "minecraft:obsidian": "Obsidyen",
        "minecraft:leather": "Deri", "minecraft:beef": "Çiğ İnek Eti",
        "minecraft:chicken": "Çiğ Tavuk", "minecraft:egg": "Yumurta",
        "minecraft:feather": "Tüy", "minecraft:wool": "Yün"
    };
    if (isimler[typeId]) return isimler[typeId];
    const parts = typeId.replace("minecraft:", "").split("_");
    return parts.map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(" ");
}

// Dinamik ekonomi
function dinamikFiyatGuncelle(item, islemTipi, miktar) {
    if (!dinamikEkonomiVerisi[item.id]) {
        dinamikEkonomiVerisi[item.id] = { alimSayisi: 0, satimSayisi: 0, sonFiyat: item.buy, trend: 'stable', volatilite: 0.1 };
    }
    const veri = dinamikEkonomiVerisi[item.id];
    if (islemTipi === 'al') {
        veri.alimSayisi += miktar;
        const talepFaktoru = 1 + (veri.alimSayisi / Math.max(1, item.stock)) * 0.15;
        item.buy = Math.round(item.buy * talepFaktoru);
    } else if (islemTipi === 'sat') {
        veri.satimSayisi += miktar;
        const arzFaktoru = Math.max(0.7, 1 - (veri.satimSayisi / Math.max(1, item.stock)) * 0.1);
        item.buy = Math.round(item.buy * arzFaktoru);
    }
    item.buy = Math.max(1, Math.min(item.buy, 100000000));
    if (item.sell > 0) item.sell = Math.max(1, Math.round(item.buy * (0.35 + Math.random() * 0.1)));
    veri.sonFiyat = item.buy;
    dinamikEkonomiVerisi[item.id] = veri;
}

// Event yönetimi
function eventKontrolEt() {
    const simdi = system.currentTick;
    aktifEventler = aktifEventler.filter(e => simdi < e.bitisTick);
    let eventSansi = 0.15;
    if (globalEnflasyonOrani > 1.15) eventSansi += 0.1;
    if (dunyaTicaretHacmi > 10000) eventSansi += 0.05;
    if (aktifEventler.length < 2 && Math.random() < eventSansi) {
        const event = EVENT_TANIMLARI[Math.floor(Math.random() * EVENT_TANIMLARI.length)];
        eventBaslat(event);
    }
}

function eventBaslat(event) {
    const simdi = system.currentTick;
    aktifEventler.push({ ...event, baslangicTick: simdi, bitisTick: simdi + (event.sure * 20) });
    if (event.fiyatMod) {
        Object.values(magazaVerisi).forEach(kat => {
            kat.forEach(urun => {
                urun.buy = Math.round(urun.buy * event.fiyatMod);
                if (urun.sell > 0) urun.sell = Math.round(urun.sell * event.fiyatMod);
            });
        });
    }
    if (event.kategoriMod) {
        const {kat, mod} = event.kategoriMod;
        if (magazaVerisi[kat]) {
            magazaVerisi[kat].forEach(urun => {
                urun.buy = Math.round(urun.buy * mod);
                if (urun.sell > 0) urun.sell = Math.round(urun.sell * mod);
            });
        }
    }
    if (event.enflasyonMod) globalEnflasyonOrani += event.enflasyonMod;
    world.sendMessage(`§6[EKONOMİ OLAYI] §e${event.ad} §fbaşladı! ${event.aciklama}`);
    ekonomiHaberleri.unshift({ tip: 'event', mesaj: `${event.ad}: ${event.aciklama}`, zaman: Date.now() });
    if (ekonomiHaberleri.length > 30) ekonomiHaberleri.pop();
}

// Stok dalgalanma
function stokDalgalanmaKontrol() {
    const simdikiGun = Math.floor(world.getAbsoluteTime() / 24000);
    if (stokDalgalanmaZamani === 0) { stokDalgalanmaZamani = simdikiGun; return; }
    const fark = simdikiGun - stokDalgalanmaZamani;
    let yenilemeOrani = 0;
    if (fark >= 2 && fark < 3) yenilemeOrani = 0.20;
    else if (fark >= 3 && fark < 5) yenilemeOrani = 0.25;
    else if (fark >= 5 && fark < 7) yenilemeOrani = 0.35;
    else if (fark >= 7 && fark < 10) yenilemeOrani = 0.65;
    else if (fark >= 10 && fark < 15) yenilemeOrani = 0.30;
    else if (fark >= 15) yenilemeOrani = 0.20;
    if (Math.random() < yenilemeOrani) {
        stokDalgalanmasiUygula();
        stokDalgalanmaZamani = simdikiGun;
    }
}

function stokDalgalanmasiUygula() {
    Object.entries(magazaVerisi).forEach(([kat, urunler]) => {
        if (isOrduKategori(kat)) return;
        urunler.forEach(urun => {
            const rastgele = Math.random();
            let carpan;
            if (rastgele < 0.13) carpan = 5 + Math.random();
            else if (rastgele < 0.33) carpan = 4 + Math.random();
            else if (rastgele < 0.55) carpan = 3 + Math.random();
            else if (rastgele < 0.81) carpan = 2 + Math.random();
            else carpan = 1 + Math.random();
            if (Math.random() < 0.4) carpan = 1 / carpan;
            urun.stock = Math.max(1, Math.round(urun.stock * carpan));
        });
    });
}

// Haber üretimi
function haberUret() {
    const analiz = piyasaAnalizEt();
    const yeniHaberler = [];
    analiz.yukselenUrunler.slice(0, 2).forEach(urun => {
        yeniHaberler.push({ tip: 'yukselis', mesaj: `${urun.ad} piyasasında yükseliş var! (+%${urun.degisim.toFixed(1)})`, zaman: Date.now() });
    });
    analiz.dusenUrunler.slice(0, 2).forEach(urun => {
        yeniHaberler.push({ tip: 'dusus', mesaj: `${urun.ad} fiyatları düşüşte. (-%${urun.degisim.toFixed(1)})`, zaman: Date.now() });
    });
    ekonomiHaberleri = [...yeniHaberler, ...ekonomiHaberleri].slice(0, 30);
}

function piyasaAnalizEt() {
    const analiz = { yukselenUrunler: [], dusenUrunler: [], genelTrend: 'stable' };
    const tumUrunler = [];
    Object.entries(magazaVerisi).forEach(([kat, urunler]) => {
        if (isOrduKategori(kat)) return;
        urunler.forEach(u => tumUrunler.push({...u, kategori: kat}));
    });
    tumUrunler.forEach(urun => {
        const gecmis = fiyatGecmisi[urun.id] || [];
        if (gecmis.length < 2) return;
        const sonFiyat = gecmis[gecmis.length - 1];
        const eskiFiyat = gecmis[0];
        const degisim = ((sonFiyat - eskiFiyat) / eskiFiyat) * 100;
        if (degisim > 5) analiz.yukselenUrunler.push({ad: urun.name, degisim});
        else if (degisim < -5) analiz.dusenUrunler.push({ad: urun.name, degisim: Math.abs(degisim)});
    });
    if (analiz.yukselenUrunler.length > analiz.dusenUrunler.length * 2) analiz.genelTrend = 'bullish';
    else if (analiz.dusenUrunler.length > analiz.yukselenUrunler.length * 2) analiz.genelTrend = 'bearish';
    return analiz;
}

// Güvenlik
function islemKaydet(player, item, miktar, fiyat, tip) {
    const kayit = { id: Date.now() + Math.random(), player: player.name, itemId: item.id, itemName: item.name, miktar, fiyat, toplam: miktar * fiyat, tip, zaman: Date.now() };
    islemGecmisi.unshift(kayit);
    if (islemGecmisi.length > 500) islemGecmisi.length = 500;
    supheliIslemKontrol(kayit);
}

function supheliIslemKontrol(kayit) {
    const sonIslemler = islemGecmisi.filter(i => i.player === kayit.player && i.zaman > Date.now() - 60000);
    if (sonIslemler.length > 20) {
        supheliIslemler.push({ ...kayit, neden: 'Çok hızlı işlem (1 dakikada 20+)', zaman: Date.now() });
        if (supheliIslemler.length > 50) supheliIslemler.shift();
    }
    if (kayit.miktar > 10000) {
        supheliIslemler.push({ ...kayit, neden: 'Anormal miktar (10,000+)', zaman: Date.now() });
    }
}

// ==================== STOK YENİLEME ====================
function tumStoklariYenile() {
    Object.keys(magazaVerisi).forEach(kat => {
        magazaVerisi[kat].forEach(urun => {
            urun.buyCount = 0;
            urun.sellCount = 0;
            if (isOrduKategori(kat)) urun.stock = 50 + Math.floor(Math.random() * 50);
            else if (urun.buy > 1000) urun.stock = 10 + Math.floor(Math.random() * 40);
            else urun.stock = 500 + Math.floor(Math.random() * 1500);
        });
    });
    world.sendMessage("§a[Stok] Tüm market stokları yenilendi!");
}

// ==================== DEDİKODU ====================
function dedikoduYap() {
    const players = world.getAllPlayers();
    if (players.length < 2) return;
    let mesaj = DEDIKODU_MESAJLARI[Math.floor(Math.random() * DEDIKODU_MESAJLARI.length)];
    const p1 = players[Math.floor(Math.random() * players.length)];
    const p2 = players[Math.floor(Math.random() * players.length)];
    const tumUrunler = [];
    Object.values(magazaVerisi).forEach(kat => kat.forEach(u => tumUrunler.push(u)));
    const urun = tumUrunler[Math.floor(Math.random() * tumUrunler.length)];
    mesaj = mesaj.replace("{oyuncu}", p1.name).replace("{oyuncu2}", p2.name).replace("{urun}", urun.name)
        .replace("{miktar}", Math.floor(Math.random() * 500 + 100))
        .replace("{unvan}", getPrestigeLevel(p1).unvan)
        .replace("{krallik}", oyuncuKralliklari[p1.name] || "Bağımsız");
    world.sendMessage(`§7[🗣️ Dedikodu] §f${mesaj}`);
}

// ==================== SOYGUN RİSKİ ====================
function soygunRiski(player, miktar) {
    if (miktar < 5000) return false;
    let itibar = getItibar(player);
    let risk = Math.max(2, 15 - itibar / 10);
    const krallik = oyuncuKralliklari[player.name];
    if (krallik && kralliklar[krallik]) {
        if (kralliklar[krallik].avantaj === 'guvenli') risk *= 0.5;
        if (kralliklar[krallik].dezavantaj === 'hedef') risk *= 1.5;
    }
    if (Math.random() * 100 < risk) {
        const kayip = Math.floor(miktar * (Math.random() * 0.3 + 0.1));
        const para = getScore(player, "zmc");
        setScore(player, "zmc", Math.max(-500, para - kayip));
        player.sendMessage(`§c[SOYGUN] Kervanın soyuldu! §c${kayip.toLocaleString()} ZMC kaybettin.`);
        addNotification(player, `Soygun! ${kayip.toLocaleString()} ZMC kaybettin.`);
        world.sendMessage(`§4[SOYGUN] §e${player.name}§f'in kervanı soyuldu!`);
        return true;
    }
    return false;
}

// ==================== MARKET AI ====================
function getAIResponse(soru, player) {
    const soruLower = soru.toLowerCase();
    const prestige = getPrestigeLevel(player);
    const itibar = getItibar(player);
    const savasCarpan = getOyuncuSavasCarpani(player);
    const ortaklikInd = getOrtaklikIndirimi(player);
    if (soruLower.includes("merhaba") || soruLower.includes("selam") || soruLower.includes("hey")) {
        return `Hoş geldin ${prestige.unvan}§f! İtibarın: ${itibar > 0 ? '§a+' + itibar : '§c' + itibar}. Bugün piyasa ${globalEnflasyonOrani > 1.1 ? 'dalgalı' : 'sakin'}.`;
    }
    if (soruLower.includes("savaş")) {
        if (savasCarpan > 1.5) return `Savaştasın! Fiyatların 3 kat. Acilen barış yap.`;
        if (savasCarpan > 1) return `Savaş açtın, fiyatların 1.5 kat.`;
        return `Şu an savaşta değilsin.`;
    }
    if (soruLower.includes("ortak")) {
        if (ortaklikInd > 0) return `Ortaklığın var, %${(ortaklikInd*100).toFixed(0)} indirimdesin!`;
        return `Ortaklığın yok.`;
    }
    if (soruLower.includes("trend") || soruLower.includes("analiz")) {
        const analiz = piyasaAnalizEt();
        return `Trend: ${analiz.genelTrend}. ${analiz.yukselenUrunler.length} ürün yükseliyor.`;
    }
    return `Enflasyon %${((globalEnflasyonOrani-1)*100).toFixed(1)}. ${globalEnflasyonOrani > 1.1 ? 'Paran erimesin diye maden al.' : 'Normal.'}`;
}

function showMarketAI(player) {
    new ModalFormData().title("§l§d🧠 MARKET AI").textField("§fNe sormak istersin?", "Örnek: Hangi ürünü alayım?").show(player).then(res => {
        if (res.canceled) return showEkonomiAnaliz(player);
        const cevap = getAIResponse(res.formValues[0], player);
        new ActionFormData().title("§l§d🧠 AI CEVABI").body(`§fCevap: §b${cevap}`).button("§l§aTAMAM").button("§l§eYENİ SORU").button("§l§c← GERİ").show(player).then(r => {
            if (r.canceled || r.selection === 2) showEkonomiAnaliz(player);
            else if (r.selection === 1) showMarketAI(player);
            else showEkonomiAnaliz(player);
        });
    });
}

// ==================== BİLDİRİM SİSTEMİ ====================
function showNotifications(player) {
    const bildirimler = JSON.parse(player.getDynamicProperty("bildirimler") ?? "[]");
    let body = "§l§b📬 BİLDİRİMLERİM\n§8────────────────\n\n";
    if (bildirimler.length === 0) body += "§7Henüz bildirimin yok.\n";
    else bildirimler.slice(0, 15).forEach(b => body += `${b.okundu ? "§a✓" : "§c•"} §8[§7${b.tarih}§8]\n§f${b.mesaj}\n§8────────────────\n`);
    new ActionFormData().title("§l§b📬 BİLDİRİMLER").body(body).button("§l§aOKUNDU İŞARETLE").button("§l§cTÜMÜNÜ SİL").button("§l§c← GERİ").show(player).then(res => {
        if (res.canceled || res.selection === 2) return showProfilBildirim(player);
        if (res.selection === 0) {
            let b = JSON.parse(player.getDynamicProperty("bildirimler") ?? "[]");
            b.forEach(n => n.okundu = true);
            player.setDynamicProperty("bildirimler", JSON.stringify(b));
            player.sendMessage("§aOkundu.");
        }
        if (res.selection === 1) {
            player.setDynamicProperty("bildirimler", "[]");
            player.sendMessage("§cTemizlendi.");
        }
        showProfilBildirim(player);
    });
}

// ==================== BORSA VE EKONOMİ ====================
function borsaGuncelle() {
    if (fiyatDonduruldu) return;
    const tumKategoriler = Object.keys(magazaVerisi);
    let toplamTicaret = 0;
    globalEnflasyonOrani += (Math.random() * 0.004 - 0.001);
    globalEnflasyonOrani = Math.max(0.95, Math.min(1.25, globalEnflasyonOrani));
    const havalar = ["GÜNEŞLİ", "YAĞMURLU", "FIRTINALI", "KARLI"];
    havaDurumu = havalar[Math.floor(Math.random() * havalar.length)];
    const olaylar = [
        { ad: "Nether Savaşı", etki: "Maden fiyatları yükseldi!", tip: "MADEN", carpan: 1.4 },
        { ad: "Büyük Hasat", etki: "Tarım ürünleri ucuzladı!", tip: "TARIM", carpan: 0.6 },
        { ad: "Madenci Grevi", etki: "Alet fiyatları arttı!", tip: "ALET", carpan: 1.25 },
        { ad: "Kıtlık", etki: "Yiyecek fiyatları fırladı!", tip: "YIYECEK", carpan: 2.0 },
        { ad: "Orman Yangını", etki: "Kütük fiyatları arttı!", tip: "KUTUK", carpan: 1.5 }
    ];
    aktifOlay = Math.random() > 0.6 ? olaylar[Math.floor(Math.random() * olaylar.length)] : { ad: "Normal", etki: "Piyasa dengeli.", tip: "NÖTR", carpan: 1.0 };
    
    const tumUrunListesi = [];
    tumKategoriler.forEach(kat => {
        if (isOrduKategori(kat)) return;
        magazaVerisi[kat].forEach((urun, idx) => tumUrunListesi.push({ urun, kat, idx }));
    });
    const secilecekSayi = Math.floor(Math.random() * 14) + 13;
    const secilenUrunler = [];
    const karisik = [...tumUrunListesi].sort(() => Math.random() - 0.5);
    for (let i = 0; i < Math.min(secilecekSayi, karisik.length); i++) secilenUrunler.push(karisik[i]);
    
    tumKategoriler.forEach(kat => {
        if (isOrduKategori(kat)) return;
        magazaVerisi[kat].forEach(urun => {
            // Eksik sayaçları başlat
            urun.buyCount = urun.buyCount || 0;
            urun.sellCount = urun.sellCount || 0;
            
            const secildi = secilenUrunler.some(s => s.kat === kat && s.idx === magazaVerisi[kat].indexOf(urun));
            if (!secildi) {
                if (!fiyatGecmisi[urun.id]) fiyatGecmisi[urun.id] = [];
                fiyatGecmisi[urun.id].push(urun.buy);
                if (fiyatGecmisi[urun.id].length > 14) fiyatGecmisi[urun.id].shift();
                toplamTicaret += urun.buyCount + urun.sellCount;
                return;
            }
            let carpan = (Math.random() * 0.12 + 0.94) * globalEnflasyonOrani;
            if (havaDurumu === "YAĞMURLU" && kat === "tarim") carpan *= 1.1;
            if (havaDurumu === "KARLI" && kat === "yiyecek") carpan *= 1.15;
            const arzTalepOrani = urun.buyCount > 0 ? (urun.sellCount / urun.buyCount) : 1;
            if (arzTalepOrani < 0.5) carpan *= 1.05;
            else if (arzTalepOrani > 2.0) carpan *= 0.95;
            if (kat.toUpperCase().includes(aktifOlay.tip.toUpperCase())) carpan *= aktifOlay.carpan;
            urun.buy = Math.max(1, Math.round(urun.buy * carpan));
            if (urun.sell > 0) urun.sell = Math.max(1, Math.round(urun.buy * (0.35 + Math.random() * 0.1)));
            if (!fiyatGecmisi[urun.id]) fiyatGecmisi[urun.id] = [];
            fiyatGecmisi[urun.id].push(urun.buy);
            if (fiyatGecmisi[urun.id].length > 14) fiyatGecmisi[urun.id].shift();
            toplamTicaret += urun.buyCount + urun.sellCount;
        });
    });
    dunyaTicaretHacmi = toplamTicaret;
    borsaKayitlari.unshift(`§b[${new Date().toLocaleTimeString()}] §f${aktifOlay.ad} §8| §7${havaDurumu}`);
    if (borsaKayitlari.length > 20) borsaKayitlari.pop();
    piyasaYorumu = `${aktifOlay.etki} Hava ${havaDurumu}, enflasyon %${((globalEnflasyonOrani - 1) * 100).toFixed(1)}.`;
}

// ==================== GÖREV SİSTEMİ ====================
function gorevAta(player) {
    const mevcut = player.getDynamicProperty("gunluk_gorev");
    if (mevcut) return JSON.parse(mevcut);
    const gorev = GUNLUK_GOREVLER[Math.floor(Math.random() * GUNLUK_GOREVLER.length)];
    player.setDynamicProperty("gunluk_gorev", JSON.stringify({...gorev, ilerleme: 0, tamamlandi: false}));
    return {...gorev, ilerleme: 0, tamamlandi: false};
}

function gorevIlerlet(player, tip, miktar, kar = 0) {
    const mevcut = player.getDynamicProperty("gunluk_gorev");
    if (!mevcut) return;
    let gorev = JSON.parse(mevcut);
    if (gorev.tamamlandi) return;
    if (gorev.tip === tip) gorev.ilerleme += miktar;
    if (gorev.tip === "kar" && kar > 0) gorev.ilerleme += kar;
    if (gorev.ilerleme >= gorev.hedef && !gorev.tamamlandi) {
        gorev.tamamlandi = true;
        setScore(player, "zmc", getScore(player, "zmc") + gorev.odul);
        player.sendMessage(`§a[Görev] Tamamlandı! +${gorev.odul} ZMC`);
        addNotification(player, `Günlük görev tamam! +${gorev.odul} ZMC`);
        addItibar(player, 5);
    }
    player.setDynamicProperty("gunluk_gorev", JSON.stringify(gorev));
}

// ==================== GÜNLÜK GİRİŞ ====================
function gunlukGirisOdulu(player) {
    const son = player.getDynamicProperty("son_gunluk_odul") ?? 0;
    const bugun = Math.floor(world.getAbsoluteTime() / 24000);
    if (son < bugun) {
        const odul = 100 + Math.floor(Math.random() * 200);
        setScore(player, "zmc", getScore(player, "zmc") + odul);
        player.setDynamicProperty("son_gunluk_odul", bugun);
        player.sendMessage(`§a[Giriş Ödülü] +${odul} ZMC!`);
    }
}

// ==================== TİCARET LONCASI (butonlarda ikon desteği ile) ====================
function showTicaretLoncasi(player) {
    const menu = new ActionFormData().title("§l§6🏛️ TİCARET LONCASI");
    menu.button("§l§a🏪 DÜKKANIM", resolveIcon("butonlar", "dukkanim", "textures/ui/icon_steve"));
    menu.button("§l§e🔍 DÜKKANLARI KEŞFET", resolveIcon("butonlar", "kesfet", "textures/ui/magnifyingGlass"));
    menu.button("§l§6⭐ EN POPÜLER", resolveIcon("butonlar", "populer", "textures/ui/icon_best3"));
    menu.button("§l§b💰 EN UCUZ", resolveIcon("butonlar", "ucuz", "textures/ui/icon_money"));
    menu.button("§l§6📋 AÇIK ARTIRMA", resolveIcon("butonlar", "acik_artirma", "textures/ui/icon_money"));
    menu.button("§l§c← GERİ DÖN");
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 5) return ShopMain(player);
        if (res.selection === 0) showMyShop(player);
        if (res.selection === 1) showAllShops(player);
        if (res.selection === 2) showTopShops(player);
        if (res.selection === 3) showCheapestShops(player);
        if (res.selection === 4) showAuctionHouse(player);
    });
}

// showMyShop, shopAddProductEnvanter, vb. aynen korunuyor...

function showMyShop(player) {
    let dukkan = oyuncuDukkanlari[player.name] || { urunler: [], puan: 0, toplamSatis: 0, aciklama: "" };
    let body = "§l§a🏪 DÜKKANIN\n§8────────────────\n\n";
    body += `§fPuan: §e${dukkan.puan || 0} §8| §fSatış: §b${dukkan.toplamSatis || 0}\n`;
    body += `§fAçıklama: §7${dukkan.aciklama || "Henüz yok"}\n\n§eÜRÜNLER (${dukkan.urunler.length}/3):\n`;
    if (dukkan.urunler.length === 0) body += "§7Henüz ürün koymadın.\n";
    else dukkan.urunler.forEach((u, i) => body += `§e${i+1}. §f${u.name} §8x${u.miktar} §8- §a${u.fiyat.toLocaleString()} ZMC\n`);
    new ActionFormData().title("§lDÜKKANIN").body(body).button("§l§a➕ ÜRÜN EKLE").button("§l§c➖ ÜRÜN KALDIR").button("§l§e📝 AÇIKLAMA").button("§l§c← GERİ").show(player).then(res => {
        if (res.canceled || res.selection === 3) return showTicaretLoncasi(player);
        if (res.selection === 0) shopAddProductEnvanter(player);
        if (res.selection === 1) shopRemoveProduct(player);
        if (res.selection === 2) shopChangeDescription(player);
    });
}

function shopAddProductEnvanter(player) {
    let dukkan = oyuncuDukkanlari[player.name] || { urunler: [], puan: 0, toplamSatis: 0, aciklama: "" };
    if (dukkan.urunler.length >= 3) { player.sendMessage("§cMaksimum 3 ürün!"); return showMyShop(player); }
    const envanter = getEnvanterEsyalari(player);
    if (envanter.length === 0) { player.sendMessage("§cEnvanterinde eşya yok!"); return showMyShop(player); }
    const menu = new ActionFormData().title("§l📦 ENVANTERDEN SEÇ").button("§l§c← GERİ");
    envanter.forEach(e => {
        const isim = getTurkceIsim(e.typeId);
        const marketUrunu = findUrunById(e.typeId);
        const fiyat = marketUrunu ? marketUrunu.buy.toLocaleString() : "?";
        menu.button(`§f${isim}\n§8Adet: §e${e.amount} §8| §7Piyasa: §a${fiyat} ZMC`);
    });
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showMyShop(player);
        const secilen = envanter[res.selection - 1];
        const isim = getTurkceIsim(secilen.typeId);
        const marketUrunu = findUrunById(secilen.typeId);
        new ModalFormData().title(`§lÜrünü Dükkana Koy: ${isim}`)
            .textField("Miktar:", String(Math.min(secilen.amount, 64)))
            .textField("Fiyat (ZMC):", marketUrunu ? String(marketUrunu.buy) : "100")
            .show(player).then(r => {
                if (r.canceled) return showMyShop(player);
                const miktar = Math.max(1, Math.min(secilen.amount, parseInt(r.formValues[0]) || 1));
                const fiyat = Math.max(1, parseInt(r.formValues[1]) || 1);
                dukkan.urunler.push({ id: secilen.typeId, name: isim, miktar, fiyat });
                oyuncuDukkanlari[player.name] = dukkan;
                player.sendMessage(`§a[✔] ${isim} x${miktar} - ${fiyat.toLocaleString()} ZMC dükkana eklendi.`);
                showMyShop(player);
            });
    });
}

function shopRemoveProduct(player) {
    let dukkan = oyuncuDukkanlari[player.name];
    if (!dukkan || dukkan.urunler.length === 0) { player.sendMessage("§cDükkanında ürün yok."); return showMyShop(player); }
    const menu = new ActionFormData().title("§lÜRÜN KALDIR").button("§l§c← GERİ");
    dukkan.urunler.forEach(u => menu.button(`§f${u.name} §8x${u.miktar} §8- §a${u.fiyat} ZMC`));
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showMyShop(player);
        const silinen = dukkan.urunler.splice(res.selection - 1, 1)[0];
        oyuncuDukkanlari[player.name] = dukkan;
        player.runCommandAsync(`give @s ${silinen.id} ${silinen.miktar}`);
        player.sendMessage(`§c[✔] ${silinen.name} dükkandan kaldırıldı.`);
        showMyShop(player);
    });
}

function shopChangeDescription(player) {
    let dukkan = oyuncuDukkanlari[player.name] || { urunler: [], puan: 0, toplamSatis: 0, aciklama: "" };
    new ModalFormData().title("§lDÜKKAN AÇIKLAMASI").textField("Yeni Açıklama:", dukkan.aciklama || "").show(player).then(res => {
        if (res.canceled) return showMyShop(player);
        dukkan.aciklama = res.formValues[0] || "Kaliteli ürünler!";
        oyuncuDukkanlari[player.name] = dukkan;
        player.sendMessage("§aAçıklama güncellendi.");
        showMyShop(player);
    });
}

function showAllShops(player) {
    const tumDukkanlar = Object.entries(oyuncuDukkanlari).filter(([ad, d]) => d.urunler.length > 0 && ad !== player.name);
    const menu = new ActionFormData().title("§l§e🔍 TÜM DÜKKANLAR").button("§l§c← GERİ");
    if (tumDukkanlar.length === 0) menu.body("§7Henüz dükkan yok.");
    tumDukkanlar.forEach(([ad, d]) => menu.button(`§f${ad}\n§8Ürün: §e${d.urunler.length} §8| Puan: §6${d.puan || 0}`));
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showTicaretLoncasi(player);
        showShopDetail(player, tumDukkanlar[res.selection - 1][0]);
    });
}

function showTopShops(player) {
    const sirali = Object.entries(oyuncuDukkanlari).filter(([ad, d]) => d.urunler.length > 0).sort((a, b) => (b[1].puan || 0) - (a[1].puan || 0)).slice(0, 10);
    const menu = new ActionFormData().title("§l§6⭐ EN POPÜLER").button("§l§c← GERİ");
    sirali.forEach(([ad, d], i) => menu.button(`§e${i+1}. §f${ad}\n§8Puan: §6${d.puan||0} §8| Satış: §b${d.toplamSatis||0}`));
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showTicaretLoncasi(player);
        showShopDetail(player, sirali[res.selection - 1][0]);
    });
}

function showCheapestShops(player) {
    const dukkanOrt = Object.entries(oyuncuDukkanlari).filter(([ad, d]) => d.urunler.length > 0).map(([ad, d]) => {
        const ort = d.urunler.reduce((s, u) => s + u.fiyat, 0) / d.urunler.length;
        return { ad, dukkan: d, ortalama: ort };
    }).sort((a, b) => a.ortalama - b.ortalama).slice(0, 10);
    const menu = new ActionFormData().title("§l§b💰 EN UCUZ").button("§l§c← GERİ");
    dukkanOrt.forEach(({ad, ortalama}) => menu.button(`§f${ad}\n§8Ort. Fiyat: §a${Math.floor(ortalama).toLocaleString()} ZMC`));
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showTicaretLoncasi(player);
        showShopDetail(player, dukkanOrt[res.selection - 1].ad);
    });
}

function showShopDetail(player, dukkanAdi) {
    const dukkan = oyuncuDukkanlari[dukkanAdi];
    if (!dukkan) { player.sendMessage("§cDükkan yok."); return showAllShops(player); }
    let body = `§l§6${dukkanAdi} DÜKKANI\n§8────────────────\n\n§fAçıklama: §7${dukkan.aciklama || "Kaliteli ürünler!"}\n§fPuan: §e${dukkan.puan||0} §8| §fSatış: §b${dukkan.toplamSatis||0}\n\n§eÜRÜNLER:\n`;
    dukkan.urunler.forEach((u, i) => body += `§e${i+1}. §f${u.name} §8x${u.miktar} §8- §a${u.fiyat.toLocaleString()} ZMC\n`);
    const menu = new ActionFormData().title(`§l${dukkanAdi}'nin Dükkanı`).body(body);
    dukkan.urunler.forEach((u, i) => menu.button(`§l§aSATIN AL: §f${u.name} §8x${u.miktar}`));
    menu.button("§l§c← GERİ");
    menu.show(player).then(res => {
        if (res.canceled || res.selection >= dukkan.urunler.length) return showAllShops(player);
        buyFromShop(player, dukkanAdi, res.selection);
    });
}

function buyFromShop(player, dukkanAdi, urunIndex) {
    const dukkan = oyuncuDukkanlari[dukkanAdi];
    if (!dukkan || urunIndex >= dukkan.urunler.length) { player.sendMessage("§cÜrün yok."); return showTicaretLoncasi(player); }
    const urun = dukkan.urunler[urunIndex];
    const para = getScore(player, "zmc");
    const komisyon = Math.floor(urun.fiyat * 0.08);
    const toplam = urun.fiyat + komisyon;
    if (para < toplam && para < -500) { player.sendMessage(`§cYetersiz bakiye! Borç limitin: -500 ZMC`); return; }
    new ModalFormData().title(`§lSATIN AL: ${urun.name}`).slider(`Fiyat: ${urun.fiyat.toLocaleString()} ZMC\nKomisyon: ${komisyon} ZMC (%8)\nToplam: ${toplam.toLocaleString()} ZMC\n\nKaç adet?`, 1, urun.miktar, 1, 1).show(player).then(res => {
        if (res.canceled) return showShopDetail(player, dukkanAdi);
        const adet = Math.floor(res.formValues[0]);
        const toplamOdeme = (urun.fiyat + komisyon) * adet;
        setScore(player, "zmc", Math.max(-500, para - toplamOdeme));
        player.runCommandAsync(`give @s ${urun.id} ${adet}`);
        const satici = world.getAllPlayers().find(p => p.name === dukkanAdi);
        if (satici) { setScore(satici, "zmc", getScore(satici, "zmc") + (urun.fiyat * adet)); addNotification(satici, `${player.name} ${adet}x ${urun.name} aldı!`); }
        urun.miktar -= adet;
        if (urun.miktar <= 0) dukkan.urunler.splice(urunIndex, 1);
        dukkan.puan = (dukkan.puan || 0) + adet;
        dukkan.toplamSatis = (dukkan.toplamSatis || 0) + adet;
        oyuncuDukkanlari[dukkanAdi] = dukkan;
        player.sendMessage(`§a[✔] ${adet}x ${urun.name} alındı.`);
        addItibar(player, 1);
        if (satici) addItibar(satici, 2);
        showShopDetail(player, dukkanAdi);
    });
}

// ==================== AÇIK ARTIRMA ====================
function showAuctionHouse(player) {
    const menu = new ActionFormData().title("§l§6📋 AÇIK ARTIRMA");
    menu.body(`§fAktif: §e${acikArtirmalar.length}\n§fLimit: §b${oyuncuArtirmaLimitleri[player.name]||0}/5`);
    menu.button("§l§a📋 TÜM ARTIRMALAR");
    menu.button("§l§e➕ ARTIRMA BAŞLAT");
    menu.button("§l§c← GERİ");
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 2) return showTicaretLoncasi(player);
        if (res.selection === 0) showAllAuctions(player);
        if (res.selection === 1) startAuctionEnvanter(player);
    });
}

function showAllAuctions(player) {
    const menu = new ActionFormData().title("§l📋 AKTİF ARTIRMALAR").button("§l§c← GERİ");
    acikArtirmalar.forEach((a, i) => {
        if (system.currentTick > a.bitisTick) return;
        const kalan = Math.floor((a.bitisTick - system.currentTick) / 20);
        menu.button(`§e#${i+1} §f${a.baslatan}\n§a${a.mevcutTeklif.toLocaleString()} §8| §c${kalan}sn`);
    });
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showAuctionHouse(player);
        showAuctionDetail(player, res.selection - 1);
    });
}

function startAuctionEnvanter(player) {
    if ((oyuncuArtirmaLimitleri[player.name]||0) >= 5) { player.sendMessage("§cLimit doldu! (5/5)"); return showAuctionHouse(player); }
    const envanter = getEnvanterEsyalari(player);
    if (envanter.length === 0) { player.sendMessage("§cEnvanterinde eşya yok!"); return showAuctionHouse(player); }
    const menu = new ActionFormData().title("§l📦 ENVANTERDEN SEÇ").button("§l§c← GERİ");
    envanter.forEach(e => {
        const isim = getTurkceIsim(e.typeId);
        menu.button(`§f${isim}\n§8Adet: §e${e.amount}`);
    });
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showAuctionHouse(player);
        const secilen = envanter[res.selection - 1];
        const isim = getTurkceIsim(secilen.typeId);
        new ModalFormData().title(`§lARTIRMA: ${isim}`)
            .textField("Miktar:", String(Math.min(secilen.amount, 64)))
            .textField("Başlangıç Fiyatı:", "100")
            .textField("Süre (sn):", "120")
            .show(player).then(r => {
                if (r.canceled) return showAuctionHouse(player);
                const miktar = Math.max(1, parseInt(r.formValues[0]) || 1);
                const fiyat = Math.max(1, parseInt(r.formValues[1]) || 100);
                const sure = Math.min(600, Math.max(60, parseInt(r.formValues[2]) || 120));
                acikArtirmalar.push({
                    id: Date.now(), urunler: [{ id: secilen.typeId, name: isim, miktar }],
                    baslangicFiyat: fiyat, mevcutTeklif: fiyat, teklifVeren: null,
                    teklifSayisi: 0, bitisTick: system.currentTick + (sure * 20), baslatan: player.name
                });
                oyuncuArtirmaLimitleri[player.name] = (oyuncuArtirmaLimitleri[player.name]||0) + 1;
                world.sendMessage(`§6[Açık Artırma] §e${player.name} §f${miktar}x ${isim} - ${fiyat.toLocaleString()} ZMC`);
                showAuctionHouse(player);
            });
    });
}

function showAuctionDetail(player, index) {
    const a = acikArtirmalar[index];
    if (!a || system.currentTick > a.bitisTick) { acikArtirmalarSonuclandir(index); return showAllAuctions(player); }
    const kalan = Math.floor((a.bitisTick - system.currentTick) / 20);
    let body = `§l§6#${index+1}\n§8────────────────\n§fBaşlatan: §b${a.baslatan}\n§fÜrün: §e${a.urunler[0].name} §8x${a.urunler[0].miktar}\n§fTeklif: §e${a.mevcutTeklif.toLocaleString()} ZMC\n§fVeren: §b${a.teklifVeren||'Yok'}\n§fKalan: §c${kalan}sn\n`;
    new ActionFormData().title("§lARTIRMA DETAYI").body(body).button("§l§e💰 TEKLİF VER").button("§l§c← GERİ").show(player).then(res => {
        if (res.canceled || res.selection === 1) return showAllAuctions(player);
        if (player.name === a.baslatan) { player.sendMessage("§cKendi artırmana teklif veremezsin!"); return; }
        new ModalFormData().title("§lTEKLİF VER").textField("Teklif (ZMC):", String(a.mevcutTeklif + 100)).show(player).then(r => {
            if (r.canceled) return;
            const teklif = parseInt(r.formValues[0]);
            if (isNaN(teklif) || teklif <= a.mevcutTeklif) { player.sendMessage("§cDaha yüksek teklif ver!"); return; }
            if (getScore(player, "zmc") < teklif) { player.sendMessage("§cYetersiz bakiye!"); return; }
            if (a.teklifVeren) {
                const eski = world.getAllPlayers().find(p => p.name === a.teklifVeren);
                if (eski) setScore(eski, "zmc", getScore(eski, "zmc") + a.mevcutTeklif);
            }
            setScore(player, "zmc", getScore(player, "zmc") - teklif);
            a.mevcutTeklif = teklif;
            a.teklifVeren = player.name;
            a.teklifSayisi = (a.teklifSayisi||0) + 1;
            if (kalan <= 10) { a.bitisTick += 200; world.sendMessage("§6[Açık Artırma] Süre 10 sn uzadı!"); }
            world.sendMessage(`§6[Açık Artırma] §e${player.name} §f${teklif.toLocaleString()} ZMC teklif verdi!`);
            gorevIlerlet(player, "acik_artirma", 1);
            oyuncuArtirmaLimitleri[player.name] = (oyuncuArtirmaLimitleri[player.name]||0) + 1;
            showAuctionDetail(player, index);
        });
    });
}

function acikArtirmalarSonuclandir(index) {
    const a = acikArtirmalar[index];
    if (!a) return;
    if (a.teklifVeren && a.mevcutTeklif > a.baslangicFiyat) {
        const kazanan = world.getAllPlayers().find(p => p.name === a.teklifVeren);
        if (kazanan) { a.urunler.forEach(u => kazanan.runCommandAsync(`give @s ${u.id} ${u.miktar}`)); world.sendMessage(`§6[Açık Artırma] §e${kazanan.name} §fkazandı!`); }
        const satici = world.getAllPlayers().find(p => p.name === a.baslatan);
        if (satici) { const komisyon = Math.floor(a.mevcutTeklif * 0.05); setScore(satici, "zmc", getScore(satici, "zmc") + a.mevcutTeklif - komisyon); }
    } else { world.sendMessage("§6[Açık Artırma] Teklif gelmedi, iptal."); }
    acikArtirmalar.splice(index, 1);
}

// ==================== SAVAŞ & DİPLOMASİ (butonlarda ikon desteği ile) ====================
function showSavasDiplomasi(player) {
    new ActionFormData().title("§l§c⚔️ SAVAŞ & DİPLOMASİ")
        .button("§l§4⚔️ SAVAŞ İLAN ET", resolveIcon("butonlar", "savas_ilan", "textures/ui/icon_steve"))
        .button("§l§e📨 GELEN TEKLİFLER", resolveIcon("butonlar", "gelen_teklifler", "textures/ui/icon_steve"))
        .button("§l§a🕊️ BARIŞ YAP", resolveIcon("butonlar", "baris", "textures/ui/icon_steve"))
        .button("§l§b🤝 ORTAKLIK TEKLİF", resolveIcon("butonlar", "ortaklik", "textures/ui/icon_steve"))
        .button("§l§7📊 SAVAŞ DURUMUM", resolveIcon("butonlar", "savas_durum", "textures/ui/icon_steve"))
        .button("§l§5🏰 KRALLIK MENÜSÜ", resolveIcon("butonlar", "krallik", "textures/ui/icon_steve"))
        .button("§l§c← GERİ")
        .show(player).then(res => {
            if (res.canceled || res.selection === 6) return ShopMain(player);
            if (res.selection === 0) savasTeklifGonder(player);
            if (res.selection === 1) gelenTeklifleriGoster(player);
            if (res.selection === 2) barisYap(player);
            if (res.selection === 3) ortaklikTeklifEt(player);
            if (res.selection === 4) savasDurumGoster(player);
            if (res.selection === 5) krallikMenu(player);
        });
}

function savasTeklifGonder(player) {
    const hedefler = world.getAllPlayers().filter(p => p.name !== player.name && !getSavasDurumu(player, p));
    if (hedefler.length === 0) { player.sendMessage("§cHedef yok."); return; }
    const menu = new ActionFormData().title("§lSAVAŞ İLAN ET").button("§l§c←");
    hedefler.forEach(p => menu.button(`§f${p.name}`));
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return;
        const hedef = hedefler[res.selection - 1];
        savasTeklifleri[hedef.name] = { gonderen: player.name, tur: "savas", zaman: system.currentTick };
        player.sendMessage(`§c⚔️ ${hedef.name}'e savaş teklifi gönderildi.`);
        addNotification(hedef, `§c${player.name} sana savaş açmak istiyor!`);
        world.sendMessage(`§c[SAVAŞ] §e${player.name} §f→ §e${hedef.name}`);
    });
}

function gelenTeklifleriGoster(player) {
    const teklif = savasTeklifleri[player.name];
    if (!teklif) { player.sendMessage("§7Teklif yok."); return; }
    const kalan = Math.floor((teklif.zaman + 12000 - system.currentTick) / 20);
    if (kalan <= 0) { delete savasTeklifleri[player.name]; player.sendMessage("§7Süre doldu."); return; }
    new ActionFormData().title("§l📨 GELEN TEKLİF").body(`§e${teklif.gonderen} §fsana §c${teklif.tur} §fteklif etti!\n§7Kalan: ${kalan}sn`)
        .button("§l§a✅ KABUL").button("§l§c❌ REDDET").show(player).then(res => {
            if (res.canceled) return;
            if (res.selection === 0) {
                if (teklif.tur === "savas") { savasDurumlari[`${teklif.gonderen}:${player.name}`] = { tur: "savas", baslangic: system.currentTick }; world.sendMessage(`§c⚔️ SAVAŞ! §e${teklif.gonderen} §fvs §e${player.name}`); }
                else { savasDurumlari[`${teklif.gonderen}:${player.name}`] = { tur: "ortaklik", baslangic: system.currentTick }; world.sendMessage(`§b🤝 ORTAKLIK! §e${teklif.gonderen} §f& §e${player.name}`); }
            }
            delete savasTeklifleri[player.name];
        });
}

function barisYap(player) {
    let liste = [];
    for (const d of world.getAllPlayers()) { if (d.name !== player.name && getSavasDurumu(player, d)?.tur === "savas") liste.push(d); }
    if (liste.length === 0) { player.sendMessage("§7Savaş yok."); return; }
    const menu = new ActionFormData().title("§lBARIŞ YAP").button("§l§c←");
    liste.forEach(p => menu.button(`§f${p.name}`));
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return;
        const h = liste[res.selection - 1];
        delete savasDurumlari[`${player.name}:${h.name}`]; delete savasDurumlari[`${h.name}:${player.name}`];
        world.sendMessage(`§a[BARIŞ] §e${player.name} §f& §e${h.name}`);
    });
}

function ortaklikTeklifEt(player) {
    const hedefler = world.getAllPlayers().filter(p => p.name !== player.name && !getSavasDurumu(player, p));
    if (hedefler.length === 0) { player.sendMessage("§cHedef yok."); return; }
    const menu = new ActionFormData().title("§lORTAKLIK").button("§l§c←");
    hedefler.forEach(p => menu.button(`§f${p.name}`));
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return;
        const h = hedefler[res.selection - 1];
        savasTeklifleri[h.name] = { gonderen: player.name, tur: "ortaklik", zaman: system.currentTick };
        player.sendMessage(`§b${h.name}'e ortaklık teklif edildi.`);
    });
}

function savasDurumGoster(player) {
    let body = "§l§7SAVAŞ DURUMUN\n§8────────────────\n\n";
    let varMi = false;
    for (const d of world.getAllPlayers()) {
        if (d.name === player.name) continue;
        const durum = getSavasDurumu(player, d);
        if (durum) {
            varMi = true;
            const renk = durum.tur === "savas" ? "§c" : durum.tur === "ortaklik" ? "§b" : "§a";
            body += `§f${d.name}: ${renk}${durum.tur.toUpperCase()}\n`;
        }
    }
    if (!varMi) body += "§7Savaş veya ortaklığın yok.";
    const krallik = oyuncuKralliklari[player.name];
    if (krallik) body += `\n§5Krallık: §d${krallik}`;
    new ActionFormData().title("§lSAVAŞ DURUMU").body(body).button("§l§aTAMAM").show(player).then(r => {});
}

function krallikMenu(player) {
    const krallik = oyuncuKralliklari[player.name];
    let body = "§l§5🏰 KRALLIK\n§8────────\n\n";
    if (krallik && kralliklar[krallik]) {
        const k = kralliklar[krallik];
        body += `§fKrallık: §d${krallik}\n§fLider: §b${k.lider}\n§fÜyeler: §e${k.uyeler.join(", ")}\n§fHazine: §a${k.hazine.toLocaleString()} ZMC\n§fSeviye: §6${k.seviye}`;
        if (k.avantaj) body += `\n§aAvantaj: ${KRALLIK_AVANTAJLARI.find(a=>a.id===k.avantaj)?.ad || k.avantaj}`;
        if (k.dezavantaj) body += `\n§cDezavantaj: ${KRALLIK_DEZAVANTAJLARI.find(d=>d.id===k.dezavantaj)?.ad || k.dezavantaj}`;
    } else body += "§7Henüz bir krallığa üye değilsin.";
    new ActionFormData().title("§lKRALLIK").body(body).button("§l§a🏰 KRALLIK KUR").button("§l§e➕ KATIL").button("§l§4⚔️ KRALLIK SAVAŞI").button("§l§c←").show(player).then(r => {
        if (r.canceled || r.selection === 3) return;
        if (r.selection === 0) krallikKur(player);
        if (r.selection === 1) krallikKatil(player);
        if (r.selection === 2) krallikSavasi(player);
    });
}

function krallikKur(player) {
    if (oyuncuKralliklari[player.name]) { player.sendMessage("§cZaten krallıktasın!"); return; }
    new ModalFormData().title("§lKRALLIK KUR").textField("Krallık Adı:", "").show(player).then(r => {
        if (r.canceled || !r.formValues[0]) return;
        const ad = r.formValues[0];
        if (kralliklar[ad]) { player.sendMessage("§cAlınmış!"); return; }
        const avantaj = KRALLIK_AVANTAJLARI[Math.floor(Math.random() * KRALLIK_AVANTAJLARI.length)];
        const dezavantaj = KRALLIK_DEZAVANTAJLARI[Math.floor(Math.random() * KRALLIK_DEZAVANTAJLARI.length)];
        kralliklar[ad] = { lider: player.name, uyeler: [player.name], hazine: 0, seviye: 1, savaslar: {}, avantaj: avantaj.id, dezavantaj: dezavantaj.id };
        oyuncuKralliklari[player.name] = ad;
        world.sendMessage(`§5[KRALLIK] §d${ad} §fkuruldu! §a${avantaj.ad} §f& §c${dezavantaj.ad}`);
    });
}

function krallikKatil(player) {
    if (oyuncuKralliklari[player.name]) { player.sendMessage("§cZaten krallıktasın!"); return; }
    const liste = Object.keys(kralliklar);
    if (!liste.length) { player.sendMessage("§7Krallık yok."); return; }
    const m = new ActionFormData().title("§lKATIL").button("§c←");
    liste.forEach(k => m.button(`§d${k} §8(${kralliklar[k].lider})`));
    m.show(player).then(r => {
        if (r.canceled || r.selection === 0) return;
        const k = liste[r.selection - 1];
        kralliklar[k].uyeler.push(player.name);
        oyuncuKralliklari[player.name] = k;
        world.sendMessage(`§5${player.name} §d${k} §fkrallığına katıldı!`);
    });
}

function krallikSavasi(player) {
    const krallik = oyuncuKralliklari[player.name];
    if (!krallik || kralliklar[krallik].lider !== player.name) { player.sendMessage("§cSadece lider!"); return; }
    const diger = Object.keys(kralliklar).filter(k => k !== krallik);
    if (!diger.length) { player.sendMessage("§7Rakip yok."); return; }
    const m = new ActionFormData().title("§lKRALLIK SAVAŞI").button("§c←");
    diger.forEach(k => m.button(`§d${k}`));
    m.show(player).then(r => {
        if (r.canceled || r.selection === 0) return;
        const h = diger[r.selection - 1];
        kralliklar[krallik].savaslar[h] = true;
        kralliklar[h].savaslar[krallik] = true;
        world.sendMessage(`§4⚔️ KRALLIK SAVAŞI! §d${krallik} §fvs §d${h}`);
    });
}

// ==================== ANA MARKET (butonlarda ikon desteği ile) ====================
function ShopMain(player) {
    gunlukGirisOdulu(player);
    const bakiye = getScore(player, "zmc");
    const prestige = getPrestigeLevel(player);
    const portfoy = getPortfoyDegeri(player);
    let baslik = `§l§8[ §6ZMC: §e${bakiye.toLocaleString()} §l§8]\n`;
    baslik += `§8Unvan: ${prestige.unvan} ${prestige.rozet} §8| Portföy: §d${portfoy.toLocaleString()}\n`;
    if (getOyuncuSavasCarpani(player) > 1) baslik += `§c⚔️ Savaşta!\n`;
    if (aktifEventler.length > 0) baslik += `§6⚡ Event: ${aktifEventler[0].ad}\n`;
    
    const menu = new ActionFormData().title(baslik);
    menu.button("§l§e🏪 MARKET", resolveIcon("ana_menu", "market", "textures/ui/icon_money"));
    menu.button("§l§4🛡️ ASKERİ MARKET", resolveIcon("ana_menu", "askeri_market", "textures/items/iron_sword"));
    menu.button("§l§b👤 PROFİLİM & BİLDİRİMLER", resolveIcon("ana_menu", "profil_bildirim", "textures/ui/icon_steve"));
    menu.button("§l§6🏛️ TİCARET LONCASI", resolveIcon("ana_menu", "ticaret_loncasi", "textures/ui/icon_money"));
    menu.button("§l§c⚔️ SAVAŞ & DİPLOMASİ", resolveIcon("ana_menu", "savas_diplomasi", "textures/ui/icon_steve"));
    menu.button("§l§d📊 EKONOMİ & ANALİZ", resolveIcon("ana_menu", "ekonomi_analiz", "textures/ui/icon_book_writable"));
    menu.button("§l§4🛠 CUSTOMIZE", resolveIcon("ana_menu", "customize", "textures/ui/settings_glyph_color_2x"));
    
    menu.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) showMarketMenu(player);
        if (res.selection === 1) showAskeriMarket(player);
        if (res.selection === 2) showProfilBildirim(player);
        if (res.selection === 3) showTicaretLoncasi(player);
        if (res.selection === 4) showSavasDiplomasi(player);
        if (res.selection === 5) showEkonomiAnaliz(player);
        if (res.selection === 6) adminPasswordCheck(player);
    });
}

function showMarketMenu(player) {
    const menu = new ActionFormData().title("§l§e🏪 MARKET").button("§l§c← GERİ");
    const marketKeys = ["bloklar", "aletler", "kutukler", "tarim", "yiyecek", "madenler", "hayvanCiftligi"];
    const marketIsimler = ["§l§8BLOKLAR", "§l§8ALETLER", "§l§8KÜTÜKLER", "§l§8TARIM", "§l§8YİYECEK", "§l§8MADENLER", "§l§e🐄 HAYVAN ÇİFTLİĞİ"];
    marketKeys.forEach((k, i) => {
        const icon = resolveIcon(k, "_kategori_baslik", magazaVerisi[k][0]?.icon || "textures/ui/icon_money");
        menu.button(marketIsimler[i], icon);
    });
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return ShopMain(player);
        showSubMenu(player, marketKeys[res.selection - 1]);
    });
}

function showAskeriMarket(player) {
    const menu = new ActionFormData().title("§l§4🛡️ ASKERİ MARKET").button("§l§c← GERİ");
    const askeriKeys = Object.keys(magazaVerisi).filter(k => isOrduKategori(k));
    askeriKeys.forEach(k => {
        const icon = resolveIcon(k, "_kategori_baslik", magazaVerisi[k][0]?.icon || "textures/items/iron_sword");
        menu.button(`§l§8${k.toUpperCase()}`, icon);
    });
    menu.show(player).then(res => {
        if (res.canceled || res.selection === 0) return ShopMain(player);
        showSubMenu(player, askeriKeys[res.selection - 1]);
    });
}

function showProfilBildirim(player) {
    new ActionFormData().title("§l§b👤 PROFİLİM & BİLDİRİMLER")
        .button("§l§b👤 PROFİLİM", resolveIcon("butonlar", "profilim", "textures/ui/icon_steve"))
        .button("§l§b📬 BİLDİRİMLER", resolveIcon("butonlar", "bildirimler", "textures/ui/icon_mail"))
        .button("§l§c← GERİ")
        .show(player).then(res => {
            if (res.canceled || res.selection === 2) return ShopMain(player);
            if (res.selection === 0) showProfile(player);
            if (res.selection === 1) showNotifications(player);
        });
}

function showEkonomiAnaliz(player) {
    new ActionFormData().title("§l§d📊 EKONOMİ & ANALİZ")
        .button("§l§e📊 BORSA ANALİZ", resolveIcon("butonlar", "borsa_analiz", "textures/ui/icon_book_writable"))
        .button("§l§6🏆 DÜNYA SIRALAMASI", resolveIcon("butonlar", "siralama", "textures/ui/icon_book_writable"))
        .button("§l§d📈 İSTATİSTİKLER", resolveIcon("butonlar", "istatistikler", "textures/ui/icon_book_writable"))
        .button("§l§e📦 ENVANTER HESAPLA", resolveIcon("butonlar", "envanter_hesapla", "textures/ui/icon_book_writable"))
        .button("§l§d🧠 MARKET AI", resolveIcon("butonlar", "market_ai", "textures/ui/icon_book_writable"))
        .button("§l§c← GERİ")
        .show(player).then(res => {
            if (res.canceled || res.selection === 5) return ShopMain(player);
            if (res.selection === 0) showBorsa(player);
            if (res.selection === 1) showLeaderboard(player);
            if (res.selection === 2) showStats(player);
            if (res.selection === 3) showEnvanterHesapla(player);
            if (res.selection === 4) showMarketAI(player);
        });
}

function showSubMenu(p, key) {
    const items = magazaVerisi[key];
    const isSabit = isOrduKategori(key);
    const menu = new ActionFormData().title(`§l§8${key.toUpperCase()}${isSabit ? ' §7(SABİT FİYAT)' : ''}`).button("§l§c← GERİ");
    items.forEach(i => {
        const savasCarpan = getOyuncuSavasCarpani(p);
        const fiyat = isSabit ? i.buy : Math.round(i.buy * savasCarpan);
        const icon = resolveIcon(key, i.name, i.icon || "textures/ui/icon_money");
        menu.button(`§l${i.name}\n§8Al: §a${fiyat.toLocaleString()} §8| Stok: §7${i.stock}`, icon);
    });
    menu.show(p).then(res => {
        if (res.canceled || res.selection === 0) return isOrduKategori(key) ? showAskeriMarket(p) : showMarketMenu(p);
        purchaseModal(p, items[res.selection - 1], key);
    });
}

function purchaseModal(p, item, key) {
    const para = getScore(p, "zmc");
    const prestige = getPrestigeLevel(p);
    const savasCarpan = getOyuncuSavasCarpani(p);
    const ortaklikInd = getOrtaklikIndirimi(p);
    const isSabit = isOrduKategori(key);
    const hamFiyat = isSabit ? item.buy : Math.round(item.buy * savasCarpan);
    const indirimliFiyat = Math.round(hamFiyat * (1 - prestige.indirim - ortaklikInd));
    const maxAl = Math.min(item.stock, Math.floor(Math.max(0, para) / Math.max(1, indirimliFiyat)));
    const maxSat = item.stock;
    const maxSlider = Math.max(1, Math.max(maxAl, maxSat, item.stock));
    
    new ModalFormData().title(`§lİŞLEM: ${item.name}`)
        .slider(`§8Cüzdan: §e${para.toLocaleString()} ZMC\n§8Fiyat: §a${hamFiyat.toLocaleString()}\n§dİndirimli: §b${indirimliFiyat.toLocaleString()}\n§7Stok: §8${item.stock}`, 1, Math.max(1, maxSlider), 1, 1)
        .toggle("§l§aÜRÜNÜ SATIN AL", false)
        .toggle("§l§cÜRÜNÜ SAT", false)
        .toggle("§l§e📌 HESAP ET", false)
        .toggle("§l§d🤝 PAZARLIK", false)
        .toggle("§l§b📊 FİYAT GRAFİĞİ", false)
        .show(p).then(res => {
            if (res.canceled || !res.formValues) return;
            const [adetRaw, al, sat, hesap, pazarlik, grafik] = res.formValues;
            const adet = Math.floor(adetRaw);
            const aktifler = [al, sat, hesap, pazarlik, grafik].filter(v => v === true);
            if (aktifler.length === 0) { p.sendMessage("§cBir işlem seçin!"); return; }
            
            if (grafik) {
                const gecmis = fiyatGecmisi[item.id] || [];
                let txt = `§l§e📊 ${item.name}\n`;
                if (gecmis.length < 2) txt += "§7Yetersiz veri.";
                else {
                    const maxF = Math.max(...gecmis), minF = Math.min(...gecmis);
                    gecmis.forEach((f, i) => {
                        const oran = (f - minF) / (maxF - minF || 1);
                        txt += `§7Gün${i+1}: §f${"█".repeat(Math.round(oran*20))} §e${f}\n`;
                    });
                }
                p.sendMessage(txt);
                return;
            }
            if (pazarlik && sat) {
                const itibar = getItibar(p);
                const sans = Math.random() * 100;
                const pahaliIhtimal = Math.max(10, 40 - itibar / 5);
                let satisFiyati;
                if (sans < pahaliIhtimal) {
                    const urunFiyat = item.sell || (item.buy * 0.35);
                    if (urunFiyat > 5000) satisFiyati = Math.round(urunFiyat * (1.1 + Math.random() * 0.2));
                    else if (urunFiyat > 1000) satisFiyati = Math.round(urunFiyat * (1.2 + Math.random() * 0.5));
                    else satisFiyati = Math.round(urunFiyat * (1.3 + Math.random() * 1.7));
                    p.sendMessage(`§a[Pazarlık BAŞARILI] Pahalı sattın! §e${satisFiyati.toLocaleString()} ZMC/adet`);
                } else {
                    const urunFiyat = item.sell || (item.buy * 0.35);
                    satisFiyati = Math.round(urunFiyat * (0.4 + Math.random() * 0.5));
                    p.sendMessage(`§c[Pazarlık] Ucuza sattın! §e${satisFiyati.toLocaleString()} ZMC/adet`);
                }
                p.runCommandAsync(`clear @s ${item.id} 0 ${adet}`).then(r => {
                    if (r.successCount >= adet) {
                        const brut = satisFiyati * adet;
                        const vergi = Math.round(brut * prestige.vergi);
                        const net = brut - vergi;
                        setScore(p, "zmc", Math.max(-500, para + net));
                        item.sellCount += adet; item.stock += adet;
                        p.setDynamicProperty("ticaret_hacmi", (p.getDynamicProperty("ticaret_hacmi") ?? 0) + net);
                        p.sendMessage(`§a[✔] ${adet}x ${item.name} satıldı. §8(+${net.toLocaleString()})`);
                        gorevIlerlet(p, "satis", adet); gorevIlerlet(p, "hacim", net); gorevIlerlet(p, "kar", net);
                        addItibar(p, 1);
                    } else p.sendMessage("§cYetersiz envanter!");
                });
                return;
            }
            if (pazarlik && !sat && !al) {
                const itibar = getItibar(p);
                const sans = Math.random() * 100;
                const zamIhtimali = Math.max(35, 62 - itibar / 3);
                if (sans < zamIhtimali) {
                    const zam = Math.round(indirimliFiyat * (1.08 + Math.random() * 0.17));
                    p.sendMessage(`§c[Pazarlık BAŞARISIZ] §e${zam.toLocaleString()} ZMC`);
                } else {
                    const ind = Math.round(indirimliFiyat * (0.82 + Math.random() * 0.12));
                    p.sendMessage(`§a[Pazarlık BAŞARILI] §b${ind.toLocaleString()} ZMC`);
                }
                addItibar(p, sans < zamIhtimali ? -1 : 1);
                return;
            }
            if (hesap) {
                p.sendMessage(`§e════════\n§lHESAP\n§fÜrün: §b${item.name}\n§fAdet: ${adet}x\n§aAlış: ${(indirimliFiyat*adet).toLocaleString()}\n§cSatış: ${(item.sell*adet).toLocaleString()}\n§e════════`);
                return;
            }
            if (al && !sat) {
                const maliyet = indirimliFiyat * adet;
                if (para < maliyet && para > -500) { setScore(p, "zmc", Math.max(-500, para - maliyet)); p.sendMessage(`§cBorca girdin! Yeni bakiye: §e${Math.max(-500, para - maliyet).toLocaleString()}`); }
                else if (para < maliyet) { p.sendMessage("§cBorç limitin doldu! (-500 ZMC)"); return; }
                else { setScore(p, "zmc", para - maliyet); }
                if (item.stock < adet) { p.sendMessage("§cYetersiz stok!"); return; }
                p.runCommandAsync(`give @s ${item.id} ${adet}`);
                item.stock -= adet; item.buyCount += adet;
                p.setDynamicProperty("ticaret_hacmi", (p.getDynamicProperty("ticaret_hacmi") ?? 0) + maliyet);
                p.sendMessage(`§a[✔] ${adet}x ${item.name} alındı.`);
                if (!isSabit) dinamikFiyatGuncelle(item, 'al', adet);
                islemKaydet(p, item, adet, indirimliFiyat, 'al');
                gorevIlerlet(p, "alim", adet); gorevIlerlet(p, "hacim", maliyet); gorevIlerlet(p, "islem", 1);
                addItibar(p, 1);
                const yeniPrestige = getPrestigeLevel(p);
                if (yeniPrestige.unvan !== prestige.unvan) { p.sendMessage(`§l§6🎉 Yeni unvan: ${yeniPrestige.unvan}`); addNotification(p, `Yeni unvan: ${yeniPrestige.unvan}`); }
                if (!soygunRiski(p, maliyet) && maliyet > 10000) dedikoduYap();
            }
            if (sat && !al && !pazarlik) {
                if (item.sell <= 0) { p.sendMessage("§cSatılamaz!"); return; }
                p.runCommandAsync(`clear @s ${item.id} 0 ${adet}`).then(r => {
                    if (r.successCount >= adet) {
                        const brut = item.sell * adet;
                        const vergi = Math.round(brut * prestige.vergi);
                        const net = brut - vergi;
                        setScore(p, "zmc", Math.max(-500, para + net));
                        item.sellCount += adet; item.stock += adet;
                        p.setDynamicProperty("ticaret_hacmi", (p.getDynamicProperty("ticaret_hacmi") ?? 0) + net);
                        p.sendMessage(`§a[✔] ${adet}x ${item.name} satıldı. §8(+${net.toLocaleString()})`);
                        if (vergi > 0) p.sendMessage(`§e[Vergi] §c${vergi.toLocaleString()} ZMC`);
                        if (!isSabit) dinamikFiyatGuncelle(item, 'sat', adet);
                        islemKaydet(p, item, adet, item.sell, 'sat');
                        gorevIlerlet(p, "satis", adet); gorevIlerlet(p, "hacim", net); gorevIlerlet(p, "kar", net);
                        addItibar(p, 1);
                    } else p.sendMessage("§cYetersiz envanter!");
                });
            }
        });
}

// ==================== EKONOMİ & ANALİZ FONKSİYONLARI ====================
function showProfile(player) {
    const prestige = getPrestigeLevel(player);
    const hacim = player.getDynamicProperty("ticaret_hacmi") ?? 0;
    const sonraki = UNVAN_SISTEMI.find(u => u.minHacim > hacim);
    const krallik = oyuncuKralliklari[player.name];
    let body = `§e════════════════\n§l§ePROFİLİN\n§f────────────────\n§fUnvan: ${prestige.unvan} ${prestige.rozet}\n§fHacim: §d${hacim.toLocaleString()} ZMC\n§fPortföy: §d${getPortfoyDegeri(player).toLocaleString()} ZMC\n§fİtibar: ${getItibar(player) > 0 ? '§a+'+getItibar(player) : '§c'+getItibar(player)}\n§fİndirim: §a%${(prestige.indirim*100).toFixed(0)}\n§fVergi: §c%${(prestige.vergi*100).toFixed(0)}\n`;
    if (krallik) { body += `§fKrallık: §d${krallik}\n`; const k = kralliklar[krallik]; if (k?.avantaj) body += `§aAvantaj: ${KRALLIK_AVANTAJLARI.find(a=>a.id===k.avantaj)?.ad}\n`; if (k?.dezavantaj) body += `§cDezavantaj: ${KRALLIK_DEZAVANTAJLARI.find(d=>d.id===k.dezavantaj)?.ad}\n`; }
    if (sonraki) body += `\n§fSonraki: ${sonraki.unvan}\n§fKalan: §e${(sonraki.minHacim-hacim).toLocaleString()} ZMC`;
    new ActionFormData().title("§lPROFİL").body(body).button("§l§aTAMAM").button("§l§c← GERİ").show(player).then(r => { if (r.canceled || r.selection === 1) showProfilBildirim(player); });
}

function showBorsa(p) {
    let body = `§l§ePİYASA\n§8────────────────\n\n§6Olay: §e${aktifOlay.ad}\n§fEtki: §7${aktifOlay.etki}\n§fHava: §b${havaDurumu}\n§fEnflasyon: §c%${((globalEnflasyonOrani-1)*100).toFixed(1)}\n\n§eSon Hareketler:\n§7${borsaKayitlari.slice(0,8).join("\n")}`;
    new ActionFormData().title("§lBORSA").body(body).button("§l§aTAMAM").show(p).then(r => {});
}

function showLeaderboard(p) {
    let body = "§l§6🏆 DÜNYA SIRALAMASI\n§8════════════════════\n\n";
    const players = world.getAllPlayers().sort((a, b) => getPortfoyDegeri(b) - getPortfoyDegeri(a));
    players.slice(0, 10).forEach((pl, i) => {
        const prestige = getPrestigeLevel(pl);
        const krallik = oyuncuKralliklari[pl.name] || "Bağımsız";
        const s = i === 0 ? '👑' : i === 1 ? '🥈' : i === 2 ? '🥉' : '  ';
        body += `${s} §e${i+1}. §f${pl.name}\n`;
        body += `   §7Krallık: §5${krallik}\n`;
        body += `   §7Unvan: ${prestige.unvan}\n`;
        body += `   §7İtibar: §a+${getItibar(pl)}\n`;
        body += `   §7Varlık: §8[GİZLİ]\n`;
        body += `§8────────────────\n`;
    });
    new ActionFormData().title("§lSIRALAMA").body(body).button("§l§aTAMAM").show(p).then(r => {});
}

function showStats(p) {
    const players = world.getAllPlayers();
    let toplamZmc = 0; players.forEach(pl => toplamZmc += getScore(pl, "zmc"));
    const tumUrunler = [];
    Object.entries(magazaVerisi).forEach(([kat, urunler]) => { if (!isOrduKategori(kat)) urunler.forEach(u => tumUrunler.push({...u, kategori: kat})); });
    const degisimli = tumUrunler.map(u => { const g = fiyatGecmisi[u.id] || []; return {...u, degisim: g.length >= 2 ? ((g[g.length-1]-g[0])/g[0])*100 : 0}; });
    const yukselen = [...degisimli].sort((a,b) => b.degisim-a.degisim).slice(0,5);
    const dusen = [...degisimli].sort((a,b) => a.degisim-b.degisim).slice(0,5);
    let stats = `§l§d════════════\n§l§d📊 İSTATİSTİK\n§l§d════════════\n\n§fOyuncu: §b${players.length}\n§fToplam: §a${toplamZmc.toLocaleString()}\n§fEnflasyon: §c%${((globalEnflasyonOrani-1)*100).toFixed(1)}\n\n§a📈 YÜKSELEN\n§8──────────\n`;
    yukselen.forEach((u,i) => stats += `§e${i+1}. §f${u.name} §a%${u.degisim.toFixed(1)}\n`);
    stats += `\n§c📉 DÜŞEN\n§8──────────\n`;
    dusen.forEach((u,i) => stats += `§e${i+1}. §f${u.name} §c%${Math.abs(u.degisim).toFixed(1)}\n`);
    new ActionFormData().title("§lİSTATİSTİK").body(stats).button("§l§aTAMAM").show(p).then(r => {});
}

function showEnvanterHesapla(player) {
    const envanter = getEnvanterEsyalari(player);
    const prestige = getPrestigeLevel(player);
    let body = "§l§e📦 ENVANTER HESAPLAMA\n§8════════════════════\n\n";
    let toplamBrut = 0, toplamVergi = 0, toplamNet = 0, urunSayisi = 0;
    if (envanter.length === 0) body += "§7Envanterinde satılabilir eşya yok.\n";
    else {
        for (const e of envanter) {
            const marketUrunu = findUrunById(e.typeId);
            if (!marketUrunu || marketUrunu.sell <= 0) continue;
            const isim = marketUrunu.name || getTurkceIsim(e.typeId);
            const birimFiyat = marketUrunu.sell;
            const brut = birimFiyat * e.amount;
            const vergi = Math.round(brut * prestige.vergi);
            const net = brut - vergi;
            body += `§f${isim}: §8x${e.amount} §7- §a${birimFiyat.toLocaleString()} ZMC/adet\n`;
            body += `  §7Toplam: §a${brut.toLocaleString()} §8| §cVergi: ${vergi.toLocaleString()} §8| §eNet: ${net.toLocaleString()}\n\n`;
            toplamBrut += brut; toplamVergi += vergi; toplamNet += net; urunSayisi += e.amount;
        }
    }
    body += `§8════════════════════\n§fToplam Ürün: §b${urunSayisi} adet\n§fBrüt Değer: §a${toplamBrut.toLocaleString()} ZMC\n§cToplam Vergi: §c${toplamVergi.toLocaleString()} ZMC\n§eNet Kazanç: §e${toplamNet.toLocaleString()} ZMC`;
    new ActionFormData().title("§l📦 ENVANTER HESAPLAMA").body(body).button("§l§aTAMAM").button("§l§c← GERİ").show(player).then(r => {});
}

// ==================== ADMIN PANELİ ====================
function adminPasswordCheck(p) {
    new ModalFormData().title("§lADMIN GİRİŞİ").textField("Şifre:", "").show(p).then(res => {
        if (res.formValues?.[0] === ADMIN_SIFRE) showAdminPanel(p);
        else p.sendMessage("§cYetkisiz.");
    });
}

function showAdminPanel(p) {
    new ActionFormData().title("§l🛠 CUSTOMIZE")
        .button("§l§e📉 BORSA TETİKLE").button("§l§6🔄 BORSA SIFIRLA").button("§l§c💀 BAKİYE SIFIRLA")
        .button("§l§1➕ ÜRÜN EKLE").button("§l§c➖ ÜRÜN SİL").button("§l§6📝 FİYAT DÜZENLE")
        .button("§l§d📂 KATEGORİ EKLE").button("§l§4🗑 KATEGORİ SİL").button("§l§a📦 STOK YENİLE")
        .button("§l§b❄️ FİYAT DONDUR").button("§l§c⚔️ SAVAŞ SIFIRLA").button("§l§6💰 ARTIRMA BAŞLAT")
        .button("§l§d⚡ EVENT TETİKLE").button("§l§c⚠️ ŞÜPHELİ İŞLEMLER")
        .button("§l§e🎨 İKON DÜZENLE").button("§l§8← GERİ")
        .show(p).then(res => {
            if (res.canceled || res.selection === 15) return ShopMain(p);
            if (res.selection === 0) { borsaGuncelle(); p.sendMessage("§aTetiklendi."); }
            if (res.selection === 1) { magazaVerisi = JSON.parse(JSON.stringify(orijinalFiyatlar)); p.sendMessage("§eSıfırlandı."); }
            if (res.selection === 2) { world.getAllPlayers().forEach(pl => setScore(pl, "zmc", 0)); p.sendMessage("§cSıfırlandı."); }
            if (res.selection === 3) adminAddProduct(p);
            if (res.selection === 4) adminRemoveProduct(p);
            if (res.selection === 5) adminEditPrice(p);
            if (res.selection === 6) adminAddCategory(p);
            if (res.selection === 7) adminDeleteCategory(p);
            if (res.selection === 8) { tumStoklariYenile(); p.sendMessage("§aStok yenilendi."); }
            if (res.selection === 9) { fiyatDonduruldu = !fiyatDonduruldu; world.sendMessage(`§bFiyatlar ${fiyatDonduruldu ? 'donduruldu' : 'çözüldü'}.`); }
            if (res.selection === 10) { savasDurumlari = {}; ortaklikDurumlari = {}; savasTeklifleri = {}; kralliklar = {}; oyuncuKralliklari = {}; world.sendMessage("§cTemizlendi."); }
            if (res.selection === 11) adminAuctionBaslat(p);
            if (res.selection === 12) adminEventTetkle(p);
            if (res.selection === 13) adminSupheliGoster(p);
            if (res.selection === 14) showIkonDuzenle(p);
        });
}

function adminAddProduct(p) {
    const kategoriler = Object.keys(magazaVerisi);
    new ModalFormData().title("§l➕ ÜRÜN EKLE").dropdown("Kategori:", kategoriler)
        .textField("ID:", "minecraft:ornek").textField("Ad:", "Örnek").textField("Icon:", "textures/items/ornek")
        .textField("Alış:", "100").textField("Satış:", "50").textField("Stok:", "1000")
        .show(p).then(res => {
            if (res.canceled) return;
            const yeniUrun = {
                id: res.formValues[1], name: res.formValues[2], icon: res.formValues[3],
                buy: Math.max(1, +res.formValues[4] || 100), sell: Math.max(0, +res.formValues[5] || 50),
                buyCount: 0, sellCount: 0, stock: Math.max(1, +res.formValues[6] || 1000)
            };
            magazaVerisi[kategoriler[res.formValues[0]]].push(yeniUrun);
            if (!fiyatGecmisi[yeniUrun.id]) fiyatGecmisi[yeniUrun.id] = [yeniUrun.buy];
            p.sendMessage("§aEklendi ve borsa sistemine dahil edildi.");
        });
}

function adminRemoveProduct(p) {
    const urunler = [];
    Object.entries(magazaVerisi).forEach(([k, uArr]) => uArr.forEach((u, i) => urunler.push({...u, kat: k, idx: i})));
    const m = new ActionFormData().title("§lSİL").button("§c←");
    urunler.forEach(u => m.button(`§f${u.name} §8(${u.kat})`, u.icon));
    m.show(p).then(res => {
        if (res.canceled || res.selection === 0) return;
        const u = urunler[res.selection - 1];
        magazaVerisi[u.kat].splice(u.idx, 1);
        delete fiyatGecmisi[u.id];
        delete dinamikEkonomiVerisi[u.id];
        p.sendMessage(`§cSilindi ve borsa kayıtları temizlendi.`);
    });
}

function adminEditPrice(p) {
    const urunler = [];
    Object.entries(magazaVerisi).forEach(([k, uArr]) => uArr.forEach((u, i) => urunler.push({...u, kat: k, idx: i})));
    const m = new ActionFormData().title("§lFİYAT").button("§c←");
    urunler.forEach(u => m.button(`§f${u.name} §8(${u.buy})`, u.icon));
    m.show(p).then(res => {
        if (res.canceled || res.selection === 0) return;
        const u = urunler[res.selection - 1];
        new ModalFormData().title(`§l${u.name}`).textField("Alış:", String(u.buy)).textField("Satış:", String(u.sell)).show(p).then(r => {
            if (r.canceled) return;
            magazaVerisi[u.kat][u.idx].buy = Math.max(1, +r.formValues[0] || 1);
            magazaVerisi[u.kat][u.idx].sell = Math.max(0, +r.formValues[1] || 0);
            p.sendMessage("§aGüncellendi.");
        });
    });
}

function adminAddCategory(p) {
    new ModalFormData().title("§l📂 KATEGORİ").textField("Anahtar:", "yeniKategori").show(p).then(res => {
        if (res.canceled) return;
        if (magazaVerisi[res.formValues[0]]) { p.sendMessage("§cVar!"); return; }
        magazaVerisi[res.formValues[0]] = [];
        p.sendMessage("§aEklendi.");
    });
}

function adminDeleteCategory(p) {
    const katlar = Object.keys(magazaVerisi);
    const m = new ActionFormData().title("§l🗑 KATEGORİ SİL").button("§c←");
    katlar.forEach(k => m.button(`§c${k} §8(${magazaVerisi[k].length})`));
    m.show(p).then(res => {
        if (res.canceled || res.selection === 0) return;
        const k = katlar[res.selection - 1];
        if (magazaVerisi[k].length > 0) { p.sendMessage("§cÖnce ürünleri sil!"); return; }
        delete magazaVerisi[k];
        p.sendMessage(`§cSilindi.`);
    });
}

function adminAuctionBaslat(p) {
    new ModalFormData().title("§l💰 ARTIRMA").textField("Ürün ID:", "minecraft:diamond").textField("Fiyat:", "1000").show(p).then(res => {
        if (res.canceled) return;
        acikArtirmalar.push({ id: Date.now(), urunler: [{ id: res.formValues[0], name: "Özel", miktar: 1 }], baslangicFiyat: +res.formValues[1], mevcutTeklif: +res.formValues[1], teklifVeren: null, teklifSayisi: 0, bitisTick: system.currentTick + 6000, baslatan: "ADMIN" });
        world.sendMessage("§6Admin artırma başlattı!");
    });
}

function adminEventTetkle(p) {
    const menu = new ActionFormData().title("§lEVENT TETİKLE").button("§c←");
    EVENT_TANIMLARI.forEach(e => menu.button(`${e.ad}\n§7${e.aciklama}`));
    menu.show(p).then(r => {
        if (r.canceled || r.selection === 0) return;
        eventBaslat(EVENT_TANIMLARI[r.selection - 1]);
        p.sendMessage("§aTetiklendi.");
    });
}

function adminSupheliGoster(p) {
    let body = "§l§c⚠️ ŞÜPHELİ İŞLEMLER\n§8════════\n\n";
    if (supheliIslemler.length === 0) body += "§aYok.\n";
    else supheliIslemler.slice(0,10).forEach((i, idx) => body += `§c${idx+1}. §f${i.player} §8- §e${i.itemName}\n§7Neden: §c${i.neden}\n§8───\n`);
    new ActionFormData().title("§lŞÜPHELİ").body(body).button("§l§cTEMİZLE").button("§l§aTAMAM").show(p).then(r => {
        if (r.selection === 0) { supheliIslemler = []; p.sendMessage("§aTemizlendi."); }
    });
}

// ==================== İKON DÜZENLEME (TÜM BUTONLAR EKLENDİ) ====================
function showIkonDuzenle(p) {
    const menu = new ActionFormData().title("§l§e🎨 İKON DÜZENLE").button("§l§c← GERİ");
    
    // Ana menü butonları
    const anaButonlar = [
        { id: "market", text: "§l§e🏪 MARKET (Ana Menü)", icon: "textures/ui/icon_money" },
        { id: "askeri_market", text: "§l§4🛡️ ASKERİ MARKET (Ana Menü)", icon: "textures/items/iron_sword" },
        { id: "profil_bildirim", text: "§l§b👤 PROFİLİM & BİLDİRİMLER (Ana Menü)", icon: "textures/ui/icon_steve" },
        { id: "ticaret_loncasi", text: "§l§6🏛️ TİCARET LONCASI (Ana Menü)", icon: "textures/ui/icon_money" },
        { id: "savas_diplomasi", text: "§l§c⚔️ SAVAŞ & DİPLOMASİ (Ana Menü)", icon: "textures/ui/icon_steve" },
        { id: "ekonomi_analiz", text: "§l§d📊 EKONOMİ & ANALİZ (Ana Menü)", icon: "textures/ui/icon_book_writable" },
        { id: "customize", text: "§l§4🛠 CUSTOMIZE (Ana Menü)", icon: "textures/ui/settings_glyph_color_2x" }
    ];
    
    // Alt butonlar (profil, bildirim, dükkan, keşfet, popüler, ucuz, açık artırma, savaş ilan, gelen teklif, barış, ortaklık, savaş durum, krallık, borsa analiz, sıralama, istatistikler, envanter hesapla, market ai)
    const altButonlar = [
        { id: "profilim", text: "§l§b👤 PROFİLİM (Alt Buton)", icon: "textures/ui/icon_steve" },
        { id: "bildirimler", text: "§l§b📬 BİLDİRİMLER (Alt Buton)", icon: "textures/ui/icon_mail" },
        { id: "dukkanim", text: "§l§a🏪 DÜKKANIM (Ticaret Loncası)", icon: "textures/ui/icon_steve" },
        { id: "kesfet", text: "§l§e🔍 DÜKKANLARI KEŞFET (Ticaret)", icon: "textures/ui/magnifyingGlass" },
        { id: "populer", text: "§l§6⭐ EN POPÜLER (Ticaret)", icon: "textures/ui/icon_best3" },
        { id: "ucuz", text: "§l§b💰 EN UCUZ (Ticaret)", icon: "textures/ui/icon_money" },
        { id: "acik_artirma", text: "§l§6📋 AÇIK ARTIRMA (Ticaret)", icon: "textures/ui/icon_money" },
        { id: "savas_ilan", text: "§l§4⚔️ SAVAŞ İLAN ET (Diplomasi)", icon: "textures/ui/icon_steve" },
        { id: "gelen_teklifler", text: "§l§e📨 GELEN TEKLİFLER (Diplomasi)", icon: "textures/ui/icon_steve" },
        { id: "baris", text: "§l§a🕊️ BARIŞ YAP (Diplomasi)", icon: "textures/ui/icon_steve" },
        { id: "ortaklik", text: "§l§b🤝 ORTAKLIK TEKLİF (Diplomasi)", icon: "textures/ui/icon_steve" },
        { id: "savas_durum", text: "§l§7📊 SAVAŞ DURUMUM (Diplomasi)", icon: "textures/ui/icon_steve" },
        { id: "krallik", text: "§l§5🏰 KRALLIK MENÜSÜ (Diplomasi)", icon: "textures/ui/icon_steve" },
        { id: "borsa_analiz", text: "§l§e📊 BORSA ANALİZ (Ekonomi)", icon: "textures/ui/icon_book_writable" },
        { id: "siralama", text: "§l§6🏆 DÜNYA SIRALAMASI (Ekonomi)", icon: "textures/ui/icon_book_writable" },
        { id: "istatistikler", text: "§l§d📈 İSTATİSTİKLER (Ekonomi)", icon: "textures/ui/icon_book_writable" },
        { id: "envanter_hesapla", text: "§l§e📦 ENVANTER HESAPLA (Ekonomi)", icon: "textures/ui/icon_book_writable" },
        { id: "market_ai", text: "§l§d🧠 MARKET AI (Ekonomi)", icon: "textures/ui/icon_book_writable" }
    ];
    
    anaButonlar.forEach(b => {
        const simdikiIcon = getIcon("ana_menu", b.id) || b.icon;
        menu.button(b.text, simdikiIcon);
    });
    
    altButonlar.forEach(b => {
        const simdikiIcon = getIcon("butonlar", b.id) || b.icon;
        menu.button(b.text, simdikiIcon);
    });
    
    // Tüm kategoriler
    Object.keys(magazaVerisi).forEach(kat => {
        const simdikiIcon = resolveIcon(kat, "_kategori_baslik", magazaVerisi[kat][0]?.icon || "textures/ui/icon_money");
        menu.button(`§fKategori: §l${kat}`, simdikiIcon);
    });
    
    menu.show(p).then(res => {
        if (res.canceled || res.selection === 0) return showAdminPanel(p);
        
        const anaBas = 1;
        const anaSon = anaButonlar.length + 1;
        const altBas = anaSon;
        const altSon = altBas + altButonlar.length;
        
        const index = res.selection;
        
        if (index >= anaBas && index < anaSon) {
            const buton = anaButonlar[index - anaBas];
            new ModalFormData().title(`§lAna Menü İkonu: ${buton.id}`)
                .textField("Texture yolu:", getIcon("ana_menu", buton.id) || buton.icon)
                .show(p).then(r => {
                    if (r.canceled) return;
                    setIcon("ana_menu", buton.id, r.formValues[0]);
                    p.sendMessage("§aAna menü ikonu kaydedildi!");
                });
        } else if (index >= altBas && index < altSon) {
            const buton = altButonlar[index - altBas];
            new ModalFormData().title(`§lAlt Buton İkonu: ${buton.id}`)
                .textField("Texture yolu:", getIcon("butonlar", buton.id) || buton.icon)
                .show(p).then(r => {
                    if (r.canceled) return;
                    setIcon("butonlar", buton.id, r.formValues[0]);
                    p.sendMessage("§aAlt buton ikonu kaydedildi!");
                });
        } else {
            const katIndex = index - altSon;
            const katIsmi = Object.keys(magazaVerisi)[katIndex];
            showKategoriIkonDuzenle(p, katIsmi);
        }
    });
}

function showKategoriIkonDuzenle(p, kat) {
    const menu = new ActionFormData().title(`§l${kat} - İKON DÜZENLE`).button("§l§c← GERİ");
    menu.button(`§l§e📂 KATEGORİ: ${kat} (başlık ikonu)`);
    magazaVerisi[kat].forEach(u => {
        const ozelIcon = getIcon(kat, u.name);
        const iconGoster = ozelIcon || u.icon || "textures/ui/icon_money";
        menu.button(`§f${u.name} ${ozelIcon ? '§a(özel)' : '§7(varsayılan)'}`, iconGoster);
    });
    menu.show(p).then(res => {
        if (res.canceled || res.selection === 0) return showIkonDuzenle(p);
        if (res.selection === 1) {
            new ModalFormData().title(`§lKategori İkonu: ${kat}`)
                .textField("Texture yolu:", magazaVerisi[kat][0]?.icon || "textures/ui/")
                .show(p).then(r => {
                    if (r.canceled) return;
                    setIcon(kat, "_kategori_baslik", r.formValues[0]);
                    p.sendMessage("§aKategori ikonu kaydedildi!");
                });
        } else {
            const urun = magazaVerisi[kat][res.selection - 2];
            new ModalFormData().title(`§lİkon: ${urun.name}`)
                .textField("Texture yolu:", getIcon(kat, urun.name) || urun.icon || "textures/ui/")
                .show(p).then(r => {
                    if (r.canceled) return;
                    setIcon(kat, urun.name, r.formValues[0]);
                    if (r.formValues[0] && r.formValues[0].trim()) {
                        urun.icon = r.formValues[0].trim();
                    }
                    p.sendMessage(`§a${urun.name} ikonu kaydedildi!`);
                });
        }
    });
}

// ==================== SİSTEM DÖNGÜSÜ ====================
system.runInterval(() => {
    ensureZmcObjective();
    const simdikiGun = Math.floor(world.getAbsoluteTime() / 24000);
    
    if (sonGuncellemeGunu !== simdikiGun) {
        borsaGuncelle();
        sonGuncellemeGunu = simdikiGun;
        world.sendMessage("§l§e[EKONOMİ] §fYeni gün! Piyasalar güncellendi.");
        world.getAllPlayers().forEach(pl => addNotification(pl, `Yeni gün! ${aktifOlay.ad}, hava: ${havaDurumu}`));
        haberUret();
        
        Object.entries(oyuncuDukkanlari).forEach(([ad, dukkan]) => {
            if (dukkan.urunler.length > 0) {
                const oyuncu = world.getAllPlayers().find(p => p.name === ad);
                if (oyuncu) {
                    let vergi = 550;
                    const krallik = oyuncuKralliklari[ad];
                    if (krallik && kralliklar[krallik]?.avantaj === 'pazar') vergi = Math.floor(vergi * 0.5);
                    const para = getScore(oyuncu, "zmc");
                    setScore(oyuncu, "zmc", Math.max(-500, para - vergi));
                    addNotification(oyuncu, `Dükkan vergisi: ${vergi} ZMC kesildi.`);
                }
            }
        });
        
        Object.entries(kralliklar).forEach(([ad, krallik]) => {
            const lider = world.getAllPlayers().find(p => p.name === krallik.lider);
            if (lider) {
                const vergi = 550;
                const para = getScore(lider, "zmc");
                const gercekKesinti = para - Math.max(-500, para - vergi); // borç limiti nedeniyle eksik kesilmiş olabilir
                setScore(lider, "zmc", Math.max(-500, para - vergi));
                // NOT: Önceden bu vergi liderin cebinden kesilip hiçbir yere
                // eklenmiyordu (hazineye gitmiyordu, parayı sistem siliyordu).
                // Bu yerel/izole krallık objesi gerçek Krallık.Core.Database
                // sistemiyle bağlı değildir (bkz. dosya başındaki not), o yüzden
                // en azından kendi içinde tutarlı olsun diye kesilen miktar
                // kendi hazinesine ekleniyor.
                krallik.hazine = (krallik.hazine || 0) + gercekKesinti;
                addNotification(lider, `Krallık vergisi: ${vergi} ZMC kesildi.`);
            }
        });
    }
    
    if (simdikiGun - sonStokYenilemeGunu >= 7) { tumStoklariYenile(); sonStokYenilemeGunu = simdikiGun; }
    stokDalgalanmaKontrol();
    eventKontrolEt();
    
    acikArtirmalar.forEach((a, i) => { if (system.currentTick > a.bitisTick) acikArtirmalarSonuclandir(i); });
    acikArtirmalar = acikArtirmalar.filter(a => system.currentTick <= a.bitisTick);
    
    Object.entries(savasTeklifleri).forEach(([hedef, teklif]) => {
        if (system.currentTick - teklif.zaman > 12000) { delete savasTeklifleri[hedef]; }
    });
    
    if (Math.random() > 0.85) dedikoduYap();
}, 1200);

world.beforeEvents.worldInitialize.subscribe(ev => {
    loadIcons();
    ev.itemComponentRegistry.registerCustomComponent("zc_invshop:trigger", {
        onUse(arg) { system.run(() => ShopMain(arg.source)); }
    });
});