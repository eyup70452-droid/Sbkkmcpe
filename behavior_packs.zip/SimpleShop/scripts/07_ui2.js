// ============================================================
// MODÜL 07_UI2: UI - Diplomasi, Üyeler, Gelişim, Profil, Liderlik, Haberler, Admin, Sur, Ticaret, Kahraman (EKSİKSİZ)
// ============================================================
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager, ClaimHarita } from "./02_claim.js";
import { Economy, Market, TradeRoute, EkonomiEk } from "./03_economy.js";
import { Systems, AI, Combat, Siege, Formasyon, Devriye, Morale } from "./04_military.js";
import { Diplomacy, Vassal, Hero, KrallikBildirim } from "./05_diplomacy.js";
import { KrallikYonetim, Profile, Leaderboard, News, SavasRaporu, Alarm, LogSistemi, Admin } from "./06_kingdom.js";
import { UI as UI1 } from "./07_ui.js";

export const UI = {
    ...UI1,

    diplomasiMenusu(player) {
        if (!Core.Permission?.requirePermission?.(player, "diplomacy.*")) return this.anaMenu(player);
        new ActionFormData()
            .title("§l🕊️ DİPLOMASİ")
            .button("§l🤝 İTTİFAK").button("§l📜 SALDIRMAZLIK").button("§l💰 TİCARET").button("§l👑 VASAL").button("§l📊 İTİBAR").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 5) return this.anaMenu(player);
                if (r.selection === 0) this.ittifakKur(player);
                if (r.selection === 1) this.saldirmazlikYap(player);
                if (r.selection === 2) this.ticaretAnlasmasi(player);
                if (r.selection === 3) this.vasalSistemi(player);
                if (r.selection === 4) this.itibarGoster(player);
            });
    },

    ittifakKur(player) {
        const d = Core.Database.load();
        const kid = Systems.getPlayerKrallikId(player);
        const diger = Object.entries(d.kralliklar || {}).filter(([id]) => id !== kid && !Diplomacy.isAllied(kid, id) && !Diplomacy.isAtWar(kid, id));
        if (!diger.length) { Systems.sendMessage(player, "§7Uygun krallık yok."); return this.diplomasiMenusu(player); }
        const form = new ActionFormData().title("§l🤝 İTTİFAK").button("§l❌ GERİ");
        diger.forEach(([, k2]) => form.button(`${k2.isim} §7(İtibar: ${k2.reputation || 50})`));
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.diplomasiMenusu(player);
            Diplomacy.formAlliance(kid, diger[r.selection - 1][0]);
            this.diplomasiMenusu(player);
        });
    },

    saldirmazlikYap(player) {
        const d = Core.Database.load();
        const kid = Systems.getPlayerKrallikId(player);
        const diger = Object.entries(d.kralliklar || {}).filter(([id]) => id !== kid && !Diplomacy.isAtWar(kid, id));
        const form = new ActionFormData().title("§l📜 SALDIRMAZLIK").button("§l❌ GERİ");
        diger.forEach(([, k2]) => form.button(k2.isim));
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.diplomasiMenusu(player);
            Diplomacy.nonAggressionPact(kid, diger[r.selection - 1][0]);
            Systems.sendMessage(player, "§a✔ Saldırmazlık paktı kuruldu!");
            this.diplomasiMenusu(player);
        });
    },

    ticaretAnlasmasi(player) {
        const d = Core.Database.load();
        const kid = Systems.getPlayerKrallikId(player);
        const diger = Object.entries(d.kralliklar || {}).filter(([id]) => id !== kid);
        const form = new ActionFormData().title("§l💰 TİCARET").button("§l❌ GERİ");
        diger.forEach(([, k2]) => form.button(k2.isim));
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.diplomasiMenusu(player);
            Diplomacy.tradeAgreement(kid, diger[r.selection - 1][0]);
            Systems.sendMessage(player, "§a✔ Ticaret anlaşması kuruldu!");
            this.diplomasiMenusu(player);
        });
    },

    vasalSistemi(player) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return this.diplomasiMenusu(player);
        const d = Core.Database.load();
        const lordKid = Vassal.getLord(kid);
        const vasallar = Vassal.getVasallar(kid);
        const bekleyenler = Vassal.getBekleyenTeklifler(kid);

        let bodyLines = [];
        if (lordKid) bodyLines.push(`§eEfendin: §f${d.kralliklar[lordKid]?.isim || lordKid}\n§7Haraç oranı: §f%20`);
        else bodyLines.push("§7Henüz bir efendiye bağlı değilsin.");
        if (vasallar.length) bodyLines.push(`\n§aVasalların (${vasallar.length}): ${vasallar.map(v => d.kralliklar[v]?.isim || v).join(", ")}`);
        if (bekleyenler.length) bodyLines.push(`\n§e⏳ ${bekleyenler.length} bekleyen vasal teklifi var.`);

        const form = new ActionFormData().title("§l👑 VASAL SİSTEMİ").body(bodyLines.join("\n"));
        if (!lordKid) form.button("§l🤝 VASAL OL (Teklif Et)");
        else form.button("§l⚡ İSYAN ET");
        if (bekleyenler.length) form.button(`§l✅ TEKLİFLERİ YANITLE (${bekleyenler.length})`);
        if (vasallar.length) form.button("§l👑 VASALİMİ AZAT ET");
        form.button("§l⬅️ GERİ");

        form.show(player).then(r => {
            if (r.canceled) return this.diplomasiMenusu(player);
            let btnIdx = 0;
            const BTN = {};
            if (!lordKid) BTN.vasal = btnIdx++;
            else BTN.isyan = btnIdx++;
            if (bekleyenler.length) BTN.teklifler = btnIdx++;
            if (vasallar.length) BTN.azat = btnIdx++;
            BTN.geri = btnIdx;
            if (r.selection === BTN.geri) return this.diplomasiMenusu(player);
            if (r.selection === BTN.vasal) {
                const uygun = Object.entries(d.kralliklar || {}).filter(([id]) => id !== kid && !Diplomacy.isAtWar(kid, id) && !Vassal.getLord(id));
                if (!uygun.length) { Systems.sendMessage(player, "§7Uygun lord krallığı yok."); return this.vasalSistemi(player); }
                const form2 = new ActionFormData().title("§l🤝 VASAL TEKLİFİ").button("§l❌ GERİ");
                uygun.forEach(([, k]) => form2.button(k.isim));
                form2.show(player).then(r2 => {
                    if (r2.canceled || r2.selection === 0) return this.vasalSistemi(player);
                    const sonuc = Vassal.teklifEt(kid, uygun[r2.selection - 1][0]);
                    Systems.sendMessage(player, sonuc.ok ? `§a${sonuc.msg}` : `§c${sonuc.msg}`);
                    this.vasalSistemi(player);
                });
            }
            if (r.selection === BTN.isyan) {
                new MessageFormData().title("§c⚡ İSYAN").body("§cEfendine isyan edeceksin. Savaş başlar.\nEmin misin?").button1("§cEVET, İSYAN ET").button2("§7İptal")
                    .show(player).then(conf => { if (conf.selection === 0) { const sonuc = Vassal.isyan(kid); Systems.sendMessage(player, sonuc.ok ? `§a${sonuc.msg}` : `§c${sonuc.msg}`); } this.vasalSistemi(player); });
            }
            if (r.selection === BTN.teklifler) {
                const form2 = new ActionFormData().title("§l✅ VASAL TEKLİFLERİ").button("§l❌ GERİ");
                bekleyenler.forEach(b => form2.button(`${d.kralliklar[b.kid]?.isim || b.kid} → Kabul/Ret`));
                form2.show(player).then(r2 => {
                    if (r2.canceled || r2.selection === 0) return this.vasalSistemi(player);
                    const teklif = bekleyenler[r2.selection - 1];
                    new MessageFormData().title("§l👑 VASAL TEKLİFİ").body(`§f${d.kralliklar[teklif.kid]?.isim} §evasal olmak istiyor.\n§7Haraç: %20\nKabul et?`).button1("§aKABUL ET").button2("§cRET")
                        .show(player).then(conf => { if (!conf.canceled) { const sonuc = conf.selection === 0 ? Vassal.kabul(kid, teklif.kid) : Vassal.reddet(kid, teklif.kid); Systems.sendMessage(player, sonuc.ok ? `§a${sonuc.msg}` : `§c${sonuc.msg}`); } this.vasalSistemi(player); });
                });
            }
            if (r.selection === BTN.azat) {
                const form2 = new ActionFormData().title("§l👑 VASAL AZAT ET").button("§l❌ GERİ");
                vasallar.forEach(v => form2.button(d.kralliklar[v]?.isim || v));
                form2.show(player).then(r2 => {
                    if (r2.canceled || r2.selection === 0) return this.vasalSistemi(player);
                    const sonuc = Vassal.azat(kid, vasallar[r2.selection - 1]);
                    Systems.sendMessage(player, sonuc.ok ? `§a${sonuc.msg}` : `§c${sonuc.msg}`);
                    this.vasalSistemi(player);
                });
            }
        });
    },

    itibarGoster(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.diplomasiMenusu(player);
        const d = Core.Database.load();
        const myKid = Systems.getPlayerKrallikId(player);
        const form = new ActionFormData().title(`§l📊 İTİBAR: ${krallik.reputation || 50}`).body("§7Krallık ilişkileri:");
        for (const [id, k2] of Object.entries(d.kralliklar || {})) {
            if (id === myKid) continue;
            const isAllied = krallik.muttefikler?.includes(id);
            const isAtWar = krallik.savaslar?.includes(id);
            let status = "§7Nötr";
            if (isAllied) status = "§aMüttefik";
            if (isAtWar) status = "§cSavaş";
            form.button(`${status} ${k2.isim}`);
        }
        form.button("§l⬅️ GERİ");
        form.show(player).then(() => this.diplomasiMenusu(player));
    },

    uyeMenusu(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.anaMenu(player);
        let b = `§l👤 ÜYELER\n§8────────────────\n`;
        krallik.uyeler?.forEach(u => {
            const rol = krallik.roller?.[u] || "üye";
            const rolDef = Config.ROLLER[rol];
            b += `${rolDef?.icon || "👤"} §f${u} §7(${rol})\n`;
        });
        new ActionFormData().title("§l👤 ÜYELER").body(b).button("§l➕ DAVET").button("§l🎖️ ROL VER").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 2) return this.anaMenu(player);
                if (r.selection === 0) this.uyeDavetEt(player);
                if (r.selection === 1) this.rolAta(player);
            });
    },

    uyeDavetEt(player) {
        if (!Core.Permission?.requirePermission?.(player, "member.invite")) return this.uyeMenusu(player);
        const diger = world.getAllPlayers().filter(pl => pl.name !== player.name && !Systems.getPlayerKrallik(pl));
        if (!diger.length) { Systems.sendMessage(player, "§7Davet edilecek oyuncu yok."); return this.uyeMenusu(player); }
        const form = new ActionFormData().title("§l➕ DAVET").button("§l❌ GERİ");
        diger.forEach(pl => form.button(pl.name));
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.uyeMenusu(player);
            const hedef = diger[r.selection - 1];
            const krallik = Systems.getPlayerKrallik(player);
            new MessageFormData().title("§6📨 DAVET").body(`§f${krallik.isim} §fkatılmak ister misin?`).button1("§a✔ KATIL").button2("§c✖ REDDET")
                .show(hedef).then(r2 => {
                    if (r2.selection === 0) {
                        const kid = Systems.getPlayerKrallikId(player);
                        if (KrallikYonetim.katil(hedef, kid)) Systems.sendMessage(hedef, `§a✔ ${krallik.isim} §fkrallığına katıldın!`);
                    }
                });
        });
    },

    rolAta(player) {
        if (!Core.Permission?.requirePermission?.(player, "member.role")) return this.uyeMenusu(player);
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.uyeMenusu(player);
        const form = new ActionFormData().title("§l🎖️ ROL VER").button("§l❌ GERİ");
        krallik.uyeler?.forEach(u => { const rol = krallik.roller?.[u] || "üye"; form.button(`${u} §7(${rol})`); });
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.uyeMenusu(player);
            const uye = krallik.uyeler[r.selection - 1];
            const rolForm = new ActionFormData().title(`§lRol: ${uye}`).button("👑 Kral").button("⭐ Yardımcı").button("⚔️ Komutan").button("🕊️ Diplomat").button("💰 Ekonomist").button("👤 Üye").button("§l❌ GERİ");
            rolForm.show(player).then(r2 => {
                if (r2.canceled || r2.selection === 6) return this.uyeMenusu(player);
                const roller = ["kral", "yardimci", "komutan", "diplomat", "ekonomist", "uye"];
                const yeniRol = roller[r2.selection];
                if (yeniRol === "kral") {
                    krallik.lider = uye;
                    krallik.roller[player.name] = "yardimci";
                    krallik.roller[uye] = "kral";
                    Core.News?.addNews?.("yonetim", `${uye} §fyeni kral oldu!`);
                } else {
                    if (krallik.roller[uye] === "kral") { Systems.sendMessage(player, "§cKralın rolü değiştirilemez!"); return; }
                    krallik.roller[uye] = yeniRol;
                }
                Core.Database.markDirty("krallik_core");
                Systems.sendMessage(player, `§a✔ ${uye} → ${yeniRol}`);
                this.uyeMenusu(player);
            });
        });
    },

    seviyeAtlaMenusu(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.anaMenu(player);
        const yeni = (krallik.seviye || 1) + 1;
        if (yeni > Config.SEVIYE_GEREKLERI.length) { Systems.sendMessage(player, "§cMaksimum seviye!"); return this.anaMenu(player); }
        const sv = Systems.getSeviyeBilgisi(yeni);
        new MessageFormData().title("§e⬆️ SEVİYE ATLA").body(`§f${krallik.seviye || 1} → §6${yeni}\n§fÜcret: §e${sv.seviyeUcreti.toLocaleString()} ZMC`).button1("§a✔ ATLA").button2("§c✖ VAZGEÇ")
            .show(player).then(r => { if (r.selection === 0) { const result = KrallikYonetim.seviyeAtla(Systems.getPlayerKrallikId(player), player); Systems.sendMessage(player, result ? `§a✔ Seviye ${result}!` : "§cBaşarısız!"); } this.anaMenu(player); });
    },

    marketMenusu(player) {
        new ActionFormData().title("§l🏪 KRALLIK MARKETİ").body("§fSavaş ekipmanları").button("§l🛒 SATIN AL").button("§l📋 GEÇMİŞ").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 2) return this.anaMenu(player);
                if (r.selection === 0) {
                    const form = new ActionFormData().title("§l🛒 SATIN AL").button("§l❌ GERİ");
                    for (const [id, item] of Object.entries(Config.MARKET_ITEMS)) {
                        const price = Market.getPrice(id, Systems.getPlayerKrallikId(player));
                        form.button(`${item.emoji || ""} ${item.name} - §e${price.toLocaleString()} ZMC`);
                    }
                    form.show(player).then(r2 => {
                        if (r2.canceled || r2.selection === 0) return this.marketMenusu(player);
                        if (!Core.RateLimiter.isAllowed(player, "market_al", 5, 2000)) Systems.sendMessage(player, "§cÇok hızlı!");
                        else Market.buyItem(player, Object.keys(Config.MARKET_ITEMS)[r2.selection - 1]);
                        this.marketMenusu(player);
                    });
                }
                if (r.selection === 1) {
                    const kid = Systems.getPlayerKrallikId(player);
                    const history = Market.getMarketHistory(kid, 10);
                    let msg = `§l📋 MARKET GEÇMİŞİ\n§8────────────────\n`;
                    if (history.length === 0) msg += "§7Henüz alışveriş yok\n";
                    else history.forEach(h => msg += `§7${new Date(h.timestamp).toLocaleDateString("tr-TR")} §f${h.player} §ax${h.quantity} ${h.itemName} §7(${h.totalPrice.toLocaleString()} ZMC)\n`);
                    Systems.sendMessage(player, msg);
                    this.marketMenusu(player);
                }
            });
    },

    gelisimMenusu(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.anaMenu(player);
        let b = `§l🌳 GELİŞİM AĞACI\n§8────────────────\n`;
        for (const [key, def] of Object.entries(Config.GELISIM_AGACI)) {
            const lvl = krallik.gelisimAgaci?.[key] || 0;
            b += `${def.emoji || ""} ${def.name}: §eLv${lvl}/${def.maxLevel}\n`;
        }
        new ActionFormData().title("§l🌳 GELİŞİM").body(b).button("§l⬆️ GELİŞTİR").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 1) return this.anaMenu(player);
                const branches = Object.entries(Config.GELISIM_AGACI);
                const form = new ActionFormData().title("§l⬆️ GELİŞTİR").button("§l❌ GERİ");
                branches.forEach(([key, def]) => {
                    const lvl = krallik.gelisimAgaci?.[key] || 0;
                    const cost = def.costs[Math.min(lvl, def.maxLevel - 1)] || 0;
                    form.button(`${def.emoji || ""} ${def.name} Lv${lvl} → ${lvl + 1} §7(${cost.toLocaleString()} ZMC)`);
                });
                form.show(player).then(r2 => {
                    if (r2.canceled || r2.selection === 0) return this.gelisimMenusu(player);
                    if (!Core.RateLimiter.isAllowed(player, "gelisim_atla", 3, 3000)) { Systems.sendMessage(player, "§cÇok hızlı!"); return this.gelisimMenusu(player); }
                    const [key] = branches[r2.selection - 1];
                    const result = Core.GelisimAgaci?.seviyeAtla?.(Systems.getPlayerKrallikId(player), key);
                    Systems.sendMessage(player, result ? "§a✔ Gelişti!" : "§cBaşarısız!");
                    this.gelisimMenusu(player);
                });
            });
    },

    gucMenusu(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.anaMenu(player);
        const power = Core.Power?.formatPower?.(krallik.totalPower) || krallik.totalPower || 0;
        new ActionFormData().title("§l💪 GÜÇ").body(`§fToplam Güç: §d${typeof power === "number" ? power.toLocaleString() : power}`).button("§l🔄 YENİLE").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 1) return this.anaMenu(player);
                Core.Power?.calculateKrallikPower?.(Systems.getPlayerKrallikId(player));
                Systems.sendMessage(player, "§a✔ Güç yenilendi!");
                this.anaMenu(player);
            });
    },

    raporMenusu(player) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return this.anaMenu(player);
        const raporlar = SavasRaporu.getRaporlar(kid, 10);
        let b = `§l📊 SAVAŞ RAPORLARI\n§8────────────────\n`;
        if (raporlar.length === 0) b += "§7Henüz rapor yok\n";
        else raporlar.forEach(r => { b += SavasRaporu.formatRapor(r) + "\n"; });
        new ActionFormData().title("§l📊 RAPOR").body(b).button("§l❌ GERİ").show(player).then(() => this.anaMenu(player));
    },

    profilMenusu(player) {
        const profile = Profile.formatProfileForDisplay(player.name, true);
        let b = `§l📋 PROFİL: ${player.name}\n§8────────────────\n`;
        b += `§fUnvan: §6${profile.unvan}\n`;
        b += `§fKill: §c${profile.kill} §f| Death: §7${profile.death} §f| KD: §e${profile.kd}\n`;
        b += `§fAsker Öldürme: §c${profile.askerOldurme}\n`;
        b += `§fKazanç: §a${profile.kazanc}\n`;
        b += `§fMarket Harcama: §e${profile.marketHarcama}\n`;
        b += `§fOnline Süre: §b${profile.onlineSure}\n`;
        b += `§fGüç: §d${profile.guc}\n`;
        b += `§fBiyografi: §7${profile.biyografi}`;
        new ActionFormData().title("§l📋 PROFİL").body(b).button("§l🔒 GİZLİLİK").button("§l✏️ BİYOGRAFİ").button("§l🎨 RENK TEMASI").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 3) return this.anaMenu(player);
                if (r.selection === 0) this.gizlilikAyarlari(player);
                if (r.selection === 1) this.biyografiDuzenle(player);
                if (r.selection === 2) this.renkTemasi(player);
            });
    },

    gizlilikAyarlari(player) {
        const profile = Profile.getProfile(player.name);
        const ayarlar = profile.gizlilikAyarlari || {};
        const keys = ["kill", "death", "askerOldurme", "kazanc", "marketHarcama", "onlineSure", "guc", "kdOrani", "biyografi"];
        const form = new ActionFormData().title("§l🔒 GİZLİLİK AYARLARI");
        keys.forEach(k => form.button(`${k}: ${ayarlar[k] ? "§a✔" : "§c✖"}`));
        form.button("§l❌ GERİ");
        form.show(player).then(r => {
            if (r.canceled || r.selection === keys.length) return this.profilMenusu(player);
            const key = keys[r.selection];
            ayarlar[key] = !ayarlar[key];
            Profile.updateGizlilik?.(player.name, ayarlar);
            Systems.sendMessage(player, `§a✔ ${key} ${ayarlar[key] ? "görünür" : "gizli"} oldu!`);
            this.gizlilikAyarlari(player);
        });
    },

    biyografiDuzenle(player) {
        const profile = Profile.getProfile(player.name);
        new ModalFormData().title("§l✏️ BİYOGRAFİ").textField("Biyografi:", profile.biyografi || "").show(player).then(r => {
            if (!r.canceled) { Profile.setBiyografi?.(player.name, r.formValues[0]); Systems.sendMessage(player, "§a✔ Biyografi güncellendi!"); }
            this.profilMenusu(player);
        });
    },

    renkTemasi(player) {
        new ActionFormData().title("§l🎨 RENK TEMASI").button("Varsayılan").button("Kırmızı").button("Mavi").button("Yeşil").button("Mor").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 5) return this.profilMenusu(player);
                const temalar = ["default", "red", "blue", "green", "purple"];
                Profile.setRenkTemasi?.(player.name, temalar[r.selection]);
                Systems.sendMessage(player, "§a✔ Tema güncellendi!");
                this.profilMenusu(player);
            });
    },

    leaderboardMenusu(player) {
        const kategoriler = Config.LEADERBOARD_KATEGORILERI;
        const form = new ActionFormData().title("§l🏆 DÜNYA SIRALAMASI").body("§fKategori seçin:");
        kategoriler.forEach(k => form.button(`${k.emoji} ${k.name}`));
        form.button("§l❌ GERİ");
        form.show(player).then(r => {
            if (r.canceled || r.selection === kategoriler.length) return this.anaMenu(player);
            const leaderboard = Leaderboard.formatLeaderboard(kategoriler[r.selection].id);
            Systems.sendMessage(player, leaderboard);
            this.leaderboardMenusu(player);
        });
    },

    haberlerMenusu(player) {
        const haberler = News.formatNewsFeed(15);
        Systems.sendMessage(player, haberler);
        new ActionFormData().title("§l📰 HABERLER").body("§fSon 50 olay kaydediliyor").button("§l🔄 YENİLE").button("§l📋 FİLTRELE").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 2) return this.anaMenu(player);
                if (r.selection === 0) { Systems.sendMessage(player, News.formatNewsFeed(15)); this.haberlerMenusu(player); }
                if (r.selection === 1) {
                    new ActionFormData().title("§l📋 FİLTRELE").button("⚔️ Savaş").button("🏁 Claim").button("🕊️ Diplomasi").button("🏰 Krallık").button("📌 Tümü").button("§l❌ GERİ")
                        .show(player).then(r2 => {
                            if (r2.canceled || r2.selection === 5) return this.haberlerMenusu(player);
                            const cats = ["savas", "claim", "diplomasi", "krallik", null];
                            const news = News.getNews(cats[r2.selection], 15);
                            let msg = `§l📰 HABERLER\n§8────────────────\n`;
                            news.forEach(n => { const time = new Date(n.timestamp).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }); msg += `§7[${time}] §f${n.message}\n`; });
                            Systems.sendMessage(player, msg);
                            this.haberlerMenusu(player);
                        });
                }
            });
    },

    surMenusu(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.anaMenu(player);
        if (!Core.Permission?.hasPermission?.(player, "duvar.*")) { Systems.sendMessage(player, "§cSUR menüsü için yetkiniz yok."); return this.anaMenu(player); }
        new ActionFormData().title("§l🏰 SUR").body("§fClaim sınırlarına sur inşa edebilirsin.\n§7Yetki: Kral/Yardımcı/Komutan").button("§l➕ İNŞA ET").button("§l🧱 MEVCUT SURLAR").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 2) return this.anaMenu(player);
                if (r.selection === 0) this._surInsaa(player);
                if (r.selection === 1) this._surListe(player);
            });
    },

    _surSecClaim(player, next) {
        const kid = Systems.getPlayerKrallikId(player);
        const claims = ClaimManager.getKrallikClaims(kid);
        if (!claims.length) { Systems.sendMessage(player, "§cClaim yok!"); return this.surMenusu(player); }
        const f = new ActionFormData().title("§l🏰 SUR - Claim Seç").body("§fHangi claim?");
        claims.forEach(c => f.button(`🏁 Claim (${c.x}, ${c.z}) Lv${c.level || 1}`));
        f.button("§l❌ GERİ");
        f.show(player).then(r => {
            if (r.canceled || r.selection === claims.length) return this.surMenusu(player);
            next(claims[r.selection]);
        });
    },

    _surInsaa(player) {
        this._surSecClaim(player, (claim) => {
            const auth = Core.Duvar?.canBuild?.(player, claim);
            if (!auth?.ok) { Systems.sendMessage(player, auth?.reason || "§cSur inşa iznin yok!"); return this.surMenusu(player); }
            const blocks = Core.Duvar?.ALLOWED_BLOCKS || [{ id: "minecraft:stone", name: "Taş", mult: 1.0 }];
            new ModalFormData().title("§l🏰 SUR - İnşa")
                .dropdown("Blok türü:", blocks.map(b => `${b.name} (§e${Math.floor(b.mult * 50)} ZMC/blok§f)`), 2)
                .slider("Yükseklik (1-50):", 1, 50, 1, 10).slider("Kalınlık (1-10):", 1, 10, 1, 2)
                .textField("Uzunluk (sayı veya 'claim çevresi'):", "claim çevresi")
                .dropdown("Hangi kenar?", ["Hepsi", "Kuzey", "Güney", "Doğu", "Batı"], 0)
                .show(player).then(r => {
                    if (r.canceled) return this.surMenusu(player);
                    const blockId = blocks[r.formValues[0]].id;
                    const height = r.formValues[1], thickness = r.formValues[2];
                    const lengthStr = r.formValues[3];
                    const sideSel = r.formValues[4];
                    const side = sideSel === 0 ? "ALL" : sideSel === 1 ? "N" : sideSel === 2 ? "S" : sideSel === 3 ? "E" : "W";
                    const res = Core.Duvar?.build?.(player, { claimId: claim.id, blockId, height, thickness, length: lengthStr, side });
                    if (!res?.ok) Systems.sendMessage(player, res?.reason || "§cSur inşası başarısız.");
                    else Systems.sendMessage(player, `§a✔ İnşa başlatıldı. Ücret: ${res.price?.toLocaleString()} ZMC`);
                    this.surMenusu(player);
                });
        });
    },

    _surListe(player) {
        this._surSecClaim(player, (claim) => {
            const walls = Core.Duvar?.getWallsByClaim?.(claim.id) || [];
            if (!walls.length) { Systems.sendMessage(player, "§7Bu claimde sur yok."); return this.surMenusu(player); }
            const f = new ActionFormData().title("§l🧱 Mevcut Surlar").body("§fKaldırmak için birini seç.");
            walls.forEach(w => f.button(`🏰 ${w.side} §7| §f${w.blockId}\n§7${w.height}h x ${w.thickness}t`));
            f.button("§l❌ GERİ");
            f.show(player).then(r => {
                if (r.canceled || r.selection === walls.length) return this.surMenusu(player);
                new MessageFormData().title("§l🧱 Sur Kaldır").body(`§cBu suru kaldırmak istediğinize emin misiniz?`).button1("§c🗑️ KALDIR").button2("§7İptal")
                    .show(player).then(r2 => {
                        if (r2.selection === 0) { const res = Core.Duvar?.removeWall?.(player, walls[r.selection].id); if (!res?.ok) Systems.sendMessage(player, res?.reason || "§cSur kaldırılamadı."); }
                        this.surMenusu(player);
                    });
            });
        });
    },

    ticaretYoluMenusu(player) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return this.anaMenu(player);
        const rotalar = TradeRoute.getRoutes(kid);
        let body = `§7Aktif ticaret yolu: §f${rotalar.length}\n§7Her periyotta güvenlik x seviyeye göre gelir üretir.\n`;
        if (rotalar.length) body += "\n§eMevcut Rotalar:\n" + rotalar.map((r, i) => `§f${i+1}. §7Güvenlik: ${r.guvenlik} | Toplam: ${r.toplamGelir} ZMC`).join("\n");
        const form = new ActionFormData().title("§l🛤️ TİCARET YOLU").body(body);
        form.button("§l➕ YENİ ROTA KUR");
        if (rotalar.length) form.button("§l⬆️ GÜVENLİK YÜKSELT").button("§l🗑️ ROTA SİL");
        form.button("§l⬅️ GERİ");
        form.show(player).then(r => {
            if (r.canceled) return this.anaMenu(player);
            const hasRoutes = rotalar.length > 0;
            const BTN_YENI = 0, BTN_UPGRADE = 1, BTN_SIL = hasRoutes ? 2 : -1, BTN_GERI = hasRoutes ? 3 : 1;
            if (r.selection === BTN_GERI) return this.anaMenu(player);
            if (r.selection === BTN_YENI) {
                const claims = ClaimManager.getKrallikClaims(kid);
                if (claims.length < 2) { Systems.sendMessage(player, "§cEn az 2 claim gerekli!"); return this.ticaretYoluMenusu(player); }
                const form2 = new ActionFormData().title("§l🛤️ BAŞLANGIÇ").button("§l❌ GERİ");
                claims.forEach(c => form2.button(`(${Math.floor(c.x)}, ${Math.floor(c.z)})`));
                form2.show(player).then(r2 => {
                    if (r2.canceled || r2.selection === 0) return this.ticaretYoluMenusu(player);
                    const claimA = claims[r2.selection - 1];
                    const form3 = new ActionFormData().title("§l🛤️ BİTİŞ").button("§l❌ GERİ");
                    claims.filter(c => c.id !== claimA.id).forEach(c => form3.button(`(${Math.floor(c.x)}, ${Math.floor(c.z)})`));
                    form3.show(player).then(r3 => {
                        if (r3.canceled || r3.selection === 0) return this.ticaretYoluMenusu(player);
                        const claimB = claims.filter(c => c.id !== claimA.id)[r3.selection - 1];
                        const sonuc = TradeRoute.createRoute(kid, claimA.id, claimB.id);
                        Systems.sendMessage(player, sonuc.ok ? `§a✔ ${sonuc.msg}` : `§c${sonuc.msg}`);
                        this.ticaretYoluMenusu(player);
                    });
                });
            }
            if (r.selection === BTN_UPGRADE && hasRoutes) {
                const form2 = new ActionFormData().title("§l⬆️ GÜVENLİK YÜKSELT").button("§l❌ GERİ");
                rotalar.forEach(rr => form2.button(`Güvenlik: ${rr.guvenlik} | +5 = ${TradeRoute.UPGRADE_MALIYET} ZMC`));
                form2.show(player).then(r2 => {
                    if (r2.canceled || r2.selection === 0) return this.ticaretYoluMenusu(player);
                    const sonuc = TradeRoute.upgradeSecurity(kid, rotalar[r2.selection - 1].id, 1);
                    Systems.sendMessage(player, sonuc.ok ? `§a✔ ${sonuc.msg}` : `§c${sonuc.msg}`);
                    this.ticaretYoluMenusu(player);
                });
            }
            if (r.selection === BTN_SIL && hasRoutes) {
                const form2 = new ActionFormData().title("§l🗑️ ROTA SİL").button("§l❌ GERİ");
                rotalar.forEach(rr => form2.button(`Rota ${rr.id.slice(-6)}`));
                form2.show(player).then(r2 => {
                    if (r2.canceled || r2.selection === 0) return this.ticaretYoluMenusu(player);
                    TradeRoute.deleteRoute(kid, rotalar[r2.selection - 1].id);
                    Systems.sendMessage(player, "§a✔ Rota silindi.");
                    this.ticaretYoluMenusu(player);
                });
            }
        });
    },

    kahramanMenusu(player) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return this.anaMenu(player);
        const hero = Hero.getHero(kid);
        const tipDef = hero ? Hero.TIPLER[hero.tip] : null;
        const krallik = Core.Database.getKrallik(kid);
        const isKral = krallik?.lider === player.name;
        let body = hero ? `§eKahramanın: §f${tipDef?.emoji || ""} ${tipDef?.name || hero.tip}\n§7Durum: ${hero.alive ? "§aCanlı" : "§cÖlü"}\n§7${tipDef?.desc || ""}` : `§7Aktif kahraman yok.\n§7Maliyet: §f${Hero.MALIYET.toLocaleString()} ZMC`;
        const form = new ActionFormData().title("§l🦸 KAHRAMAN").body(body);
        if (!hero || !hero.alive) {
            if (isKral) Object.values(Hero.TIPLER).forEach(t => form.button(`${t.emoji} ${t.name}\n§7${t.desc}`));
            else form.button("§7Kahraman satın almak için kral gerekli");
        } else form.button("§7Kahraman zaten aktif");
        form.button("§l⬅️ GERİ");
        form.show(player).then(r => {
            if (r.canceled) return this.anaMenu(player);
            const tipler = Object.keys(Hero.TIPLER);
            if (r.selection === tipler.length || !isKral || (hero?.alive)) return this.anaMenu(player);
            const sonuc = Hero.buyHero(player, tipler[r.selection]);
            Systems.sendMessage(player, sonuc.ok ? `§a✔ ${sonuc.msg}` : `§c${sonuc.msg}`);
            this.kahramanMenusu(player);
        });
    },

    adminMenu(player) {
        if (!Systems.isAdmin(player)) { Systems.sendMessage(player, "§cBu menü sadece adminlere özel!"); return; }
        new ActionFormData().title("§4🔱 ADMIN PANELİ")
            .button("§l💰 EKONOMİ").button("§l⚔️ SAVAŞ").button("§l📦 MARKET").button("§l🏁 CLAIM")
            .button("§l👥 ASKER").button("§l🔨 OYUNCU").button("§l📊 GENEL").button("§l❌ KAPAT")
            .show(player).then(r => {
                if (r.canceled || r.selection === 7) return;
                const actions = ["adminEkonomi", "adminSavas", "adminMarket", "adminClaim", "adminAsker", "adminOyuncu", "adminGenel"];
                this[actions[r.selection]]?.(player);
            });
    },

    adminEkonomi(player) {
        const d = Core.Database.load();
        const kralliklar = Object.entries(d.kralliklar || {});
        if (!kralliklar.length) { Systems.sendMessage(player, "§7Hiç krallık yok."); return this.adminMenu(player); }
        new ModalFormData().title("§4💰 ADMİN EKONOMİ")
            .dropdown("Krallık:", kralliklar.map(([, k]) => `${k.isim} (${Math.floor(k.hazine || 0)} ZMC)`), 0)
            .textField("Para Miktarı:", "1000").toggle("Krallık hazinesine ekle", true).textField("Oyuncu adı:", "")
            .show(player).then(r => {
                if (r.canceled) return this.adminMenu(player);
                const [kidIdx, miktarStr, hazineMi, oyuncuAdi] = r.formValues;
                const miktar = parseInt(miktarStr) || 0;
                const [kid, k] = kralliklar[kidIdx];
                if (hazineMi) { k.hazine = (k.hazine || 0) + miktar; Core.Database.markDirty("krallik_core"); Systems.sendMessage(player, `§a✔ ${k.isim} hazinesine ${miktar > 0 ? "+" : ""}${miktar} ZMC`); }
                else if (oyuncuAdi) { if (miktar > 0) Admin.paraVer(oyuncuAdi, Math.abs(miktar)); else Admin.paraAl(oyuncuAdi, Math.abs(miktar)); Systems.sendMessage(player, `§a✔ ${oyuncuAdi} hesabına ${miktar > 0 ? "+" : ""}${miktar} ZMC`); }
                this.adminMenu(player);
            });
    },

    adminSavas(player) {
        const d = Core.Database.load();
        const kralliklar = Object.entries(d.kralliklar || {});
        if (kralliklar.length < 2) { Systems.sendMessage(player, "§7En az 2 krallık gerekli."); return this.adminMenu(player); }
        const isimler = kralliklar.map(([, k]) => k.isim);
        new ModalFormData().title("§4⚔️ ADMİN SAVAş").dropdown("Saldıran:", isimler, 0).dropdown("Savunan:", isimler, 1)
            .dropdown("İşlem:", ["Savaş Başlat", "Savaşı Bitir", "Savaşı Bitir (Kazanan Saldıran)"], 0)
            .show(player).then(r => {
                if (r.canceled) return this.adminMenu(player);
                const [aIdx, dIdx, islem] = r.formValues;
                if (aIdx === dIdx) { Systems.sendMessage(player, "§cAynı krallığı seçemezsin!"); return this.adminMenu(player); }
                const [aKid] = kralliklar[aIdx], [dKid] = kralliklar[dIdx];
                if (islem === 0) Diplomacy.declareWar(aKid, dKid);
                else { const kazanan = islem === 2 ? aKid : null; Diplomacy.endWar(aKid, dKid, kazanan); }
                Systems.sendMessage(player, `§a✔ İşlem tamamlandı.`);
                this.adminMenu(player);
            });
    },

    adminMarket(player) {
        const items = Object.entries(Config.MARKET_ITEMS);
        if (!items.length) { Systems.sendMessage(player, "§7Market item yok."); return this.adminMenu(player); }
        const form = new ActionFormData().title("§4📦 ADMİN MARKET");
        items.forEach(([, item]) => form.button(`${item.emoji || ""} ${item.name} §7(${item.basePrice} ZMC)`));
        form.button("§l❌ GERİ");
        form.show(player).then(r => {
            if (r.canceled || r.selection === items.length) return this.adminMenu(player);
            const [itemId, item] = items[r.selection];
            new ModalFormData().title(`§4📦 ${item.name} DÜZENLE`).textField("Yeni Fiyat:", String(item.basePrice)).textField("Stok Limiti:", String(item.stockLimit)).toggle("Aktif", !item.disabled)
                .show(player).then(r2 => {
                    if (!r2.canceled) { item.basePrice = Math.max(1, parseInt(r2.formValues[0]) || item.basePrice); item.stockLimit = Math.max(1, parseInt(r2.formValues[1]) || item.stockLimit); item.disabled = !r2.formValues[2]; Systems.sendMessage(player, `§a✔ ${item.name} güncellendi!`); }
                    this.adminMenu(player);
                });
        });
    },

    adminClaim(player) {
        const d = Core.Database.load();
        const claims = Object.entries(d.claimler || {});
        if (!claims.length) { Systems.sendMessage(player, "§7Hiç claim yok."); return this.adminMenu(player); }
        const form = new ActionFormData().title("§4🏁 ADMİN CLAIM");
        claims.slice(0, 30).forEach(([cid, c]) => { const kIsim = d.kralliklar?.[c.krallik]?.isim || c.krallik; form.button(`§f${kIsim} §7(${Math.floor(c.x)},${Math.floor(c.z)})`); });
        form.button("§l❌ GERİ");
        form.show(player).then(r => {
            if (r.canceled || r.selection >= claims.slice(0, 30).length) return this.adminMenu(player);
            const [cid, claim] = claims[r.selection];
            new ActionFormData().title("§4🏁 CLAIM İŞLEM").button("§c🗑️ SİL").button("§e🔄 TRANSFER").button("§a❤️ ONAR").button("§l⬅️ GERİ")
                .show(player).then(r2 => {
                    if (r2.canceled || r2.selection === 3) return this.adminClaim(player);
                    if (r2.selection === 0) { Admin.claimSil(cid); Systems.sendMessage(player, "§a✔ Claim silindi."); return this.adminMenu(player); }
                    if (r2.selection === 1) {
                        const hedefler = Object.entries(d.kralliklar || {}).filter(([id]) => id !== claim.krallik);
                        const form3 = new ActionFormData().title("§4🔄 TRANSFER").button("§l❌ GERİ");
                        hedefler.forEach(([, k]) => form3.button(k.isim));
                        form3.show(player).then(r3 => {
                            if (r3.canceled || r3.selection === 0) return this.adminClaim(player);
                            const [yeniKid] = hedefler[r3.selection - 1];
                            claim.krallik = yeniKid;
                            Core.Database.markDirty("krallik_claims");
                            Systems.sendMessage(player, "§a✔ Claim transfer edildi.");
                            this.adminMenu(player);
                        });
                    }
                    if (r2.selection === 2) { claim.health = claim.maxHealth || 100; claim.contested = false; Core.Database.markDirty("krallik_claims"); Systems.sendMessage(player, "§a✔ Claim sağlığı onarıldı."); this.adminClaim(player); }
                });
        });
    },

    adminAsker(player) {
        const d = Core.Database.load();
        const kralliklar = Object.entries(d.kralliklar || {});
        const askerTipler = Object.entries(Config.ASKERLER);
        new ModalFormData().title("§4👥 ADMİN ASKER")
            .dropdown("Krallık:", kralliklar.map(([, k]) => k.isim), 0)
            .dropdown("Asker Türü:", askerTipler.map(([, a]) => `${a.emoji || ""} ${a.name}`), 0)
            .textField("Adet:", "1").toggle("Sil (spawn değil)", false)
            .show(player).then(r => {
                if (r.canceled) return this.adminMenu(player);
                const [kidIdx, tipIdx, adetStr, silMi] = r.formValues;
                const adet = Math.max(1, Math.min(20, parseInt(adetStr) || 1));
                const [kid] = kralliklar[kidIdx];
                const [askerId, askerDef] = askerTipler[tipIdx];
                if (silMi) {
                    let silinen = 0;
                    for (const e of Core.Cache?.getKrallikEntities?.(kid) || []) {
                        if (!Core.Cache?.isValidEntity?.(e)) continue;
                        if ((e.getTags?.() || []).includes(`asker_${askerId}`)) { try { e.kill(); silinen++; } catch {} if (silinen >= adet) break; }
                    }
                    Systems.sendMessage(player, `§a✔ ${silinen} ${askerDef.name} silindi.`);
                } else {
                    const claims = ClaimManager.getKrallikClaims(kid);
                    const spawnLoc = claims.length ? { x: claims[0].x, y: 64, z: claims[0].z } : player.location;
                    let spawned = 0;
                    for (let i = 0; i < adet; i++) {
                        try {
                            const loc = { x: spawnLoc.x + (Math.random()*10-5), y: spawnLoc.y, z: spawnLoc.z + (Math.random()*10-5) };
                            let e = player.dimension.spawnEntity(askerDef.fallbackEntity, loc);
                            Systems.addTag(e, `krallik_${kid}`);
                            Systems.addTag(e, `asker_${askerId}`);
                            Systems.addTag(e, "rank_acemi");
                            Systems.addTag(e, "savun");
                            const ddb = Core.Database.load();
                            if (!ddb.askerKayit) ddb.askerKayit = {};
                            ddb.askerKayit[e.id] = { kill: 0, krallik: kid, type: askerId, level: 1 };
                            AI.initSoldier(e, kid);
                            spawned++;
                        } catch {}
                    }
                    Core.Database.markDirty("krallik_army");
                    Systems.sendMessage(player, `§a✔ ${spawned} ${askerDef.name} spawn edildi.`);
                }
                this.adminMenu(player);
            });
    },

    adminOyuncu(player) {
        new ModalFormData().title("§4🔨 ADMİN OYUNCU")
            .textField("Oyuncu Adı:", "").dropdown("İşlem:", ["Ban", "Unban", "Kick", "Para Ver", "Para Al", "Item Ver"], 0)
            .textField("Miktar / Item ID:", "1000").textField("Sebep / Adet:", "admin")
            .show(player).then(r => {
                if (r.canceled) return this.adminMenu(player);
                const [oyuncu, islemIdx, deger, sebep] = r.formValues;
                if (!oyuncu?.trim()) { Systems.sendMessage(player, "§cOyuncu adı boş!"); return this.adminMenu(player); }
                try {
                    if (islemIdx === 0) Admin.ban(oyuncu, sebep);
                    else if (islemIdx === 1) Admin.unban(oyuncu);
                    else if (islemIdx === 2) Admin.kick(oyuncu, sebep);
                    else if (islemIdx === 3) Admin.paraVer(oyuncu, parseInt(deger) || 0);
                    else if (islemIdx === 4) Admin.paraAl(oyuncu, parseInt(deger) || 0);
                    else if (islemIdx === 5) Admin.itemVer(oyuncu, deger, parseInt(sebep) || 1);
                    Systems.sendMessage(player, `§a✔ İşlem tamamlandı.`);
                } catch(e) { Systems.sendMessage(player, `§cHata: ${e?.message}`); }
                this.adminMenu(player);
            });
    },

    adminGenel(player) {
        new ActionFormData().title("§4📊 ADMİN GENEL")
            .button("§l🔄 LİDERLİK SIFIRLA").button("§l💾 YEDEK YÜKLE").button("§l🌍 EVENT BAŞLAT")
            .button("§l🗑️ TÜM KRALLIKLARI SİL").button("§l🔑 CUSTOMİZE ŞİFRESİ").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 5) return this.adminMenu(player);
                if (r.selection === 0) { Admin.liderlikSifirla(); Systems.sendMessage(player, "§a✔ Leaderboard sıfırlandı."); return this.adminMenu(player); }
                if (r.selection === 1) {
                    const backups = Core.Backup?.listBackups?.() || [];
                    if (!backups.length) { Systems.sendMessage(player, "§7Kayıtlı yedek yok."); return this.adminMenu(player); }
                    const form2 = new ActionFormData().title("§4💾 YEDEK").button("§l❌ GERİ");
                    backups.slice(-10).forEach(b => form2.button(`${b.label || b.id}`));
                    form2.show(player).then(r2 => {
                        if (r2.canceled || r2.selection === 0) return this.adminMenu(player);
                        Core.Backup?.restore?.(backups.slice(-10)[r2.selection - 1]?.id);
                        Systems.sendMessage(player, "§a✔ Yedek geri yüklendi.");
                        this.adminMenu(player);
                    });
                }
                if (r.selection === 2) {
                    new ModalFormData().title("§4🌍 EVENT BAŞLAT").textField("Başlık:", "Admin Event").textField("Süre (dakika):", "10")
                        .show(player).then(r2 => {
                            if (r2.canceled) return this.adminMenu(player);
                            Admin.eventBaslat(r2.formValues[0] || "Admin Event", (parseInt(r2.formValues[1]) || 10) * 60000);
                            Systems.sendMessage(player, `§a✔ Event başlatıldı.`);
                            this.adminMenu(player);
                        });
                }
                if (r.selection === 3) {
                    new MessageFormData().title("§4⚠️ DİKKAT").body("§cTüm krallıklar KALICI olarak silinecek!\nEmin misin?").button1("§cEVET SİL").button2("§7İptal")
                        .show(player).then(conf => {
                            if (conf.selection === 0) {
                                const d = Core.Database.load();
                                const kids = Object.keys(d.kralliklar || {});
                                for (const kid of kids) KrallikYonetim.dagil(kid, "admin_wipe");
                                Systems.sendMessage(player, `§c☠ ${kids.length} krallık silindi.`);
                            }
                            this.adminMenu(player);
                        });
                }
                if (r.selection === 4) {
                    new ModalFormData().title("§4🔑 CUSTOMİZE ŞİFRESİ").textField("Yeni Şifre:", "").textField("Tekrar:", "")
                        .show(player).then(r2 => {
                            if (!r2.canceled && r2.formValues[0] && r2.formValues[0] === r2.formValues[1]) {
                                try { world.setDynamicProperty("krallik_customize_password", r2.formValues[0]); Systems.sendMessage(player, "§a✔ Şifre güncellendi."); } catch(e) { Systems.sendMessage(player, `§cHata: ${e?.message}`); }
                            } else Systems.sendMessage(player, "§cŞifreler eşleşmiyor veya boş!");
                            this.adminMenu(player);
                        });
                }
            });
    }
};