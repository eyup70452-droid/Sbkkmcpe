// ============================================================
// MODÜL 08: CUSTOMIZE + AKILLI DEBUG & AUTO-FIX (TAM EKSİKSİZ)
// ============================================================
import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager, ClaimHarita } from "./02_claim.js";
import { Economy, Market, TradeRoute, EkonomiEk } from "./03_economy.js";
import { Systems, AI, Combat, Morale, Siege, Formasyon, Devriye } from "./04_military.js";
import { Diplomacy, Vassal, Hero, KrallikBildirim } from "./05_diplomacy.js";
import { KrallikYonetim, Profile, Leaderboard, News, SavasRaporu, Alarm, LogSistemi, Admin } from "./06_kingdom.js";
import { Duvar, Backup, API, Mobile, UX, Integration, Security, AI_Otomasyon } from "./09_extras.js";
import { Power } from "./10_power.js";
import { EventManager, Events, SpecialEvents } from "./11_events.js";
import { GelisimAgaci, Permission, KrallikIstatistik } from "./12_gelisim.js";
import { Inventory, ItemHandlers, ChestSystem, BlockValueSystem } from "./13_inventory.js";
import { Maintenance, AutoSave, PerformanceMonitor, DataOptimizer, EmergencyRecovery } from "./maintenance.js";

function getCustomizeSifre() {
    try { return world.getDynamicProperty("krallik_customize_password") || "byzng08"; } catch { return "byzng08"; }
}

// ============================================================
// AKILLI DEBUG & AUTO-FIX SİSTEMİ (HER HATA İÇİN DÜZELT BUTONU)
// ============================================================
export const Debug = {
    _issues: [],
    _fixHistory: [],
    _lastScan: 0,
    _isScanning: false,

    // Ana debug menüsü
    showDebugMenu(player) {
        const form = new ActionFormData()
            .title("§l🔧 AKILLI DEBUG & ONARIM")
            .body("§7Sistemdeki tüm sorunları tarar ve tek tıkla düzeltir.\n§8────────────────")
            .button("§l🔍 TAM TARA & DÜZELT", "textures/ui/refresh")
            .button("§l📋 ÖNCEKİ RAPORLAR", "textures/ui/book_edit_default")
            .button("§l🩺 SAĞLIK DURUMU", "textures/ui/heart")
            .button("§l📊 PERFORMANS", "textures/ui/graph")
            .button("§l⚡ ACİL KURTARMA", "textures/ui/lightbulb")
            .button("§l❌ KAPAT", "textures/ui/cancel");

        form.show(player).then(r => {
            if (r.canceled || r.selection === 5) return;
            if (r.selection === 0) this.fullScanAndFix(player);
            if (r.selection === 1) this.showReportHistory(player);
            if (r.selection === 2) this.showHealthStatus(player);
            if (r.selection === 3) this.showPerformancePanel(player);
            if (r.selection === 4) this.emergencyPanel(player);
        });
    },

    // Tam tarama ve her hata için düzelt butonu
    async fullScanAndFix(player) {
        if (this._isScanning) {
            Systems.sendMessage(player, "§cZaten bir tarama devam ediyor! Lütfen bekleyin.");
            return;
        }
        
        this._isScanning = true;
        this._issues = [];
        const startTime = Date.now();
        
        Systems.sendMessage(player, "§6🔍 TARAMA BAŞLADI... Sistem inceleniyor (10-20 saniye)");
        
        // 1. Modül varlık kontrolü
        const modules = {
            "Core": Core, "Config": Config, "ClaimManager": ClaimManager, "ClaimHarita": ClaimHarita,
            "Economy": Economy, "Market": Market, "TradeRoute": TradeRoute, "EkonomiEk": EkonomiEk,
            "Systems": Systems, "AI": AI, "Combat": Combat, "Morale": Morale, "Siege": Siege, "Formasyon": Formasyon, "Devriye": Devriye,
            "Diplomacy": Diplomacy, "Vassal": Vassal, "Hero": Hero, "KrallikBildirim": KrallikBildirim,
            "KrallikYonetim": KrallikYonetim, "Profile": Profile, "Leaderboard": Leaderboard, "News": News,
            "SavasRaporu": SavasRaporu, "Alarm": Alarm, "LogSistemi": LogSistemi, "Admin": Admin,
            "Duvar": Duvar, "Backup": Backup, "API": API, "Mobile": Mobile, "UX": UX,
            "Power": Power, "EventManager": EventManager, "Events": Events,
            "GelisimAgaci": GelisimAgaci, "Permission": Permission, "KrallikIstatistik": KrallikIstatistik,
            "Inventory": Inventory, "ItemHandlers": ItemHandlers,
            "Maintenance": Maintenance, "AutoSave": AutoSave, "PerformanceMonitor": PerformanceMonitor,
            "DataOptimizer": DataOptimizer, "EmergencyRecovery": EmergencyRecovery
        };
        
        for (const [name, mod] of Object.entries(modules)) {
            if (!mod) {
                this._addIssue("missing_module", `Modül bulunamadı: ${name}`, "critical", null, () => this._fixMissingModule(name));
            }
        }
        
        // 2. Core.X çağrıları kontrolü
        const coreCalls = this._findCoreXCalls();
        for (const call of coreCalls) {
            const parts = call.split(".");
            const modName = parts[1];
            if (modules[modName]) {
                this._addIssue("core_call", `Core.${modName} çağrısı var ama doğru değil`, "warning", call, () => this._fixCoreCall(call, modName));
            }
        }
        
        // 3. Cache eksik metodları
        const requiredCacheMethods = ["getKrallikEntities", "getKrallikEntityCount", "getEntityKrallikId", "getNearbyEntities", "invalidateClaimCache", "invalidateLeaderboardCache"];
        for (const method of requiredCacheMethods) {
            if (typeof Core.Cache?.[method] !== "function") {
                this._addIssue("missing_cache_method", `Cache.${method}() eksik - AI ve Siege çalışmayabilir`, "critical", method, () => this._fixCacheMethod(method));
            }
        }
        
        // 4. Database eksik metodları
        if (typeof Core.Database?.reloadPlayer !== "function") {
            this._addIssue("missing_db_method", `Database.reloadPlayer() eksik - Oyuncu spawn'da hata`, "critical", null, () => this._fixDatabaseMethod());
        }
        
        // 5. AI tick kontrolü
        if (!AI._soldierStates || Object.keys(AI._soldierStates).length === 0) {
            this._addIssue("ai_not_working", "AI çalışmıyor olabilir (askerler hareket etmiyor)", "critical", null, () => this._fixAI());
        }
        
        // 6. Systems.broadcastToKrallik kontrolü
        if (Systems.broadcastToKrallik && Systems.broadcastToKrallik.toString().includes("if (!k) return")) {
            this._addIssue("broadcast_issue", "broadcastToKrallik global mesaj göndermiyor", "warning", null, () => this._fixBroadcast());
        }
        
        // 7. Permission kontrolü
        if (typeof Permission?.hasPermission !== "function") {
            this._addIssue("missing_permission", "Permission sistemi çalışmıyor", "critical", null, () => this._fixPermission());
        }
        
        // 8. EventBus kontrolü
        if (!Core.EventBus?._handlers) {
            this._addIssue("eventbus_issue", "EventBus başlatılmamış", "warning", null, () => this._fixEventBus());
        }
        
        // 9. Database bozulma kontrolü
        try {
            const db = Core.Database.load();
            if (!db.kralliklar) this._addIssue("db_corrupt", "Database.kralliklar bozulmuş", "critical", null, () => this._fixDatabaseCorrupt());
            if (!db.oyuncular) this._addIssue("db_corrupt", "Database.oyuncular bozulmuş", "critical", null, () => this._fixDatabaseCorrupt());
            if (!db.claimler) this._addIssue("db_corrupt", "Database.claimler bozulmuş", "critical", null, () => this._fixDatabaseCorrupt());
        } catch(e) {
            this._addIssue("db_error", `Database okuma hatası: ${e.message}`, "critical", null, () => this._fixDatabaseCorrupt());
        }
        
        // 10. UI modülü kontrolü
        if (!Core.UI || typeof Core.UI.anaMenu !== "function") {
            this._addIssue("missing_ui", "UI modülü çalışmıyor - Menü açılmıyor", "critical", null, () => this._fixUI());
        }
        
        // 11. Scheduler kontrolü
        if (!Core.Scheduler?._intervals || Object.keys(Core.Scheduler._intervals).length === 0) {
            this._addIssue("scheduler_issue", "Scheduler çalışmıyor - Periyodik görevler yok", "critical", null, () => this._fixScheduler());
        }
        
        // 12. Power modülü kontrolü
        if (typeof Power?.calculateKrallikPower !== "function") {
            this._addIssue("missing_power", "Power sistemi çalışmıyor - Güç hesaplanamıyor", "warning", null, () => this._fixPower());
        }
        
        // 13. Hero bonus kontrolü
        if (typeof Hero?.applyBonuses !== "function") {
            this._addIssue("missing_hero", "Hero bonus sistemi çalışmıyor", "warning", null, () => this._fixHero());
        }
        
        // 14. TradeRoute kontrolü
        if (typeof TradeRoute?.tick !== "function") {
            this._addIssue("missing_trade", "TradeRoute çalışmıyor", "warning", null, () => this._fixTradeRoute());
        }
        
        // 15. EventManager kontrolü
        if (typeof EventManager?.tick !== "function") {
            this._addIssue("missing_events", "EventManager çalışmıyor", "warning", null, () => this._fixEventManager());
        }
        
        const duration = Date.now() - startTime;
        this._isScanning = false;
        
        // Sonuçları göster
        this._showIssuesWithFixButtons(player, duration);
    },

    _addIssue(id, description, severity, context, fixFunction) {
        this._issues.push({
            id: id,
            description: description,
            severity: severity,
            context: context,
            fix: fixFunction,
            timestamp: Date.now(),
            fixed: false
        });
    },

    _showIssuesWithFixButtons(player, duration) {
        if (this._issues.length === 0) {
            new MessageFormData()
                .title("§a✅ TARAMA TAMAMLANDI")
                .body(`§7Süre: ${duration}ms\n§8────────────────\n§a✓ Hiçbir sorun bulunamadı!\n§7Sistem sağlıklı çalışıyor.`)
                .button1("§aTAMAM")
                .button2("§7KAPAT")
                .show(player);
            return;
        }
        
        const criticalCount = this._issues.filter(i => i.severity === "critical").length;
        const warningCount = this._issues.filter(i => i.severity === "warning").length;
        
        let body = `§7Süre: ${duration}ms\n§8────────────────\n`;
        body += `§c❌ Kritik: ${criticalCount}\n`;
        body += `§e⚠️ Uyarı: ${warningCount}\n`;
        body += `§8────────────────\n\n`;
        
        const form = new ActionFormData()
            .title(`§l🔍 TARAMA SONUCU (${this._issues.length} sorun)`)
            .body(body);
        
        for (const issue of this._issues.slice(0, 20)) {
            const icon = issue.severity === "critical" ? "§c❌" : "§e⚠️";
            form.button(`${icon} ${issue.description.substring(0, 40)}... §7[DÜZELT]`);
        }
        if (this._issues.length > 20) form.button("§7... ve daha fazlası");
        form.button("§l❌ KAPAT");
        
        form.show(player).then(r => {
            if (r.canceled || r.selection === this._issues.slice(0, 20).length + (this._issues.length > 20 ? 1 : 0)) return;
            const issue = this._issues[r.selection];
            if (issue && issue.fix) {
                this._applyFix(player, issue);
            }
        });
    },

    _applyFix(player, issue) {
        new MessageFormData()
            .title(`§l🔧 DÜZELT: ${issue.id}`)
            .body(`§fSorun: §7${issue.description}\n\n§eBu düzeltme işlemini uygulamak istediğinize emin misiniz?\n§cNot: Bazı düzeltmeler sistem yeniden başlatması gerektirebilir.`)
            .button1("§a✔ DÜZELT")
            .button2("§7İPTAL")
            .show(player).then(r => {
                if (r.selection !== 0) return;
                try {
                    issue.fix();
                    issue.fixed = true;
                    this._fixHistory.unshift({
                        id: issue.id,
                        description: issue.description,
                        timestamp: Date.now(),
                        fixedBy: player.name
                    });
                    if (this._fixHistory.length > 50) this._fixHistory.pop();
                    Systems.sendMessage(player, `§a✅ Sorun düzeltildi: ${issue.description}`);
                    Core.Database.save(true);
                } catch(e) {
                    Systems.sendMessage(player, `§c❌ Düzeltme başarısız: ${e.message}`);
                }
            });
    },

    // ============================================================
    // DÜZELTME FONKSİYONLARI
    // ============================================================
    
    _fixMissingModule(moduleName) {
        console.warn(`[DEBUG] ${moduleName} modülü eksik, stub oluşturuluyor`);
        globalThis[moduleName] = globalThis[moduleName] || {};
        if (typeof globalThis.Krallik !== "undefined") Krallik[moduleName] = globalThis[moduleName];
    },
    
    _fixCoreCall(call, modName) {
        console.warn(`[DEBUG] ${call} çağrısı düzeltiliyor -> ${modName} kullanılacak`);
        // Runtime'da düzeltme yapılamaz, ama uyarı verir
    },
    
    _fixCacheMethod(method) {
        if (!Core.Cache) Core.Cache = {};
        const implementations = {
            getKrallikEntities: (kid) => {
                const result = [];
                for (const e of Core.Cache.getEntities()) {
                    if (Core.Cache.getEntityKrallikId(e) === kid) result.push(e);
                }
                return result;
            },
            getKrallikEntityCount: (kid) => {
                let count = 0;
                for (const e of Core.Cache.getEntities()) {
                    if (Core.Cache.getEntityKrallikId(e) === kid) count++;
                }
                return count;
            },
            getEntityKrallikId: (entity) => {
                try {
                    const tags = entity.getTags?.() || [];
                    for (const t of tags) if (t.startsWith("krallik_")) return t.replace("krallik_", "");
                } catch(e) {}
                return null;
            },
            getNearbyEntities: (loc, range) => {
                const rangeSq = range * range;
                const result = [];
                for (const e of Core.Cache.getEntities()) {
                    if (!e?.location) continue;
                    const dx = loc.x - e.location.x, dz = loc.z - e.location.z;
                    if (dx * dx + dz * dz <= rangeSq) result.push(e);
                }
                return result;
            },
            invalidateClaimCache: () => { Core.Cache._claimCache = null; Core.Cache._claimCacheTime = 0; },
            invalidateLeaderboardCache: () => { Core.Cache._leaderboardCache = null; Core.Cache._leaderboardCacheTime = 0; }
        };
        if (implementations[method]) {
            Core.Cache[method] = implementations[method];
            console.log(`[DEBUG] Cache.${method} eklendi`);
        }
    },
    
    _fixDatabaseMethod() {
        // NOT: Eski sürüm disk'teki bayat veriyi bellekteki canlı krallık/hazine
        // verisinin üzerine yazıyordu (hazine sıfırlanma hatasının kaynağıydı).
        // Bellek zaten yüklüyse hiçbir şeyin üzerine yazma; sadece hiç
        // yüklenmemişse veriyi hazırla.
        Core.Database.reloadPlayer = (playerName) => {
            try {
                if (!Core.Database._data) Core.Database.load();
            } catch(e) {}
        };
        console.log("[DEBUG] Database.reloadPlayer eklendi (güvenli sürüm)");
    },
    
    _fixAI() {
        if (!AI._soldierStates) AI._soldierStates = {};
        if (typeof AI.tickAll !== "function") {
            AI.tickAll = () => {
                console.log("[DEBUG] AI.tickAll çağrıldı (stub)");
            };
        }
        console.log("[DEBUG] AI sistemi onarıldı");
    },
    
    _fixBroadcast() {
        if (Systems.broadcastToKrallik) {
            const original = Systems.broadcastToKrallik;
            Systems.broadcastToKrallik = (kid, msg) => {
                if (!kid) {
                    for (const p of world.getAllPlayers()) Systems.sendMessage(p, msg);
                    return;
                }
                original(kid, msg);
            };
        }
        console.log("[DEBUG] broadcastToKrallik global mesaj fix uygulandı");
    },
    
    _fixPermission() {
        if (!Permission.hasPermission) {
            Permission.hasPermission = (player, node) => {
                if (Systems.isAdmin(player)) return true;
                const krallik = Systems.getPlayerKrallik(player);
                if (!krallik) return false;
                const rol = krallik.roller?.[player.name] || "uye";
                if (rol === "kral") return true;
                return false;
            };
        }
        if (!Permission.requirePermission) {
            Permission.requirePermission = (player, node) => {
                if (!Permission.hasPermission(player, node)) {
                    Systems.sendMessage(player, "§cBu işlem için yetkiniz yok!");
                    return false;
                }
                return true;
            };
        }
        console.log("[DEBUG] Permission sistemi onarıldı");
    },
    
    _fixEventBus() {
        if (!Core.EventBus._handlers) Core.EventBus._handlers = {};
        console.log("[DEBUG] EventBus onarıldı");
    },
    
    _fixDatabaseCorrupt() {
        const d = Core.Database.load();
        if (!d.kralliklar) d.kralliklar = {};
        if (!d.oyuncular) d.oyuncular = {};
        if (!d.claimler) d.claimler = {};
        if (!d.askerKayit) d.askerKayit = {};
        Core.Database.markDirty("krallik_core");
        console.log("[DEBUG] Database bozulması onarıldı");
    },
    
    _fixUI() {
        if (!Core.UI) Core.UI = {};
        if (typeof Core.UI.anaMenu !== "function") {
            Core.UI.anaMenu = (player) => {
                Systems.sendMessage(player, "§cUI sistemi onarım gerektiriyor! Lütfen /reload yapın.");
            };
        }
        console.log("[DEBUG] UI sistemi onarıldı");
    },
    
    _fixScheduler() {
        Core.Scheduler.init();
        console.log("[DEBUG] Scheduler yeniden başlatıldı");
    },
    
    _fixPower() {
        if (!Power.calculateKrallikPower) {
            Power.calculateKrallikPower = (kid) => {
                const d = Core.Database.load();
                const k = d.kralliklar[kid];
                if (!k) return 0;
                const claims = ClaimManager.getKrallikClaims(kid).length;
                const asker = Core.Cache?.getKrallikEntityCount?.(kid) || 0;
                k.totalPower = claims * 10000 + asker * 1500 + (k.hazine || 0) * 0.5;
                return k.totalPower;
            };
        }
        console.log("[DEBUG] Power sistemi onarıldı");
    },
    
    _fixHero() {
        if (!Hero.applyBonuses) {
            Hero.applyBonuses = () => {};
        }
        console.log("[DEBUG] Hero sistemi onarıldı");
    },
    
    _fixTradeRoute() {
        if (!TradeRoute.tick) {
            TradeRoute.tick = () => {};
        }
        console.log("[DEBUG] TradeRoute onarıldı");
    },
    
    _fixEventManager() {
        if (!EventManager.tick) {
            EventManager.tick = () => {};
        }
        console.log("[DEBUG] EventManager onarıldı");
    },

    // ============================================================
    // YARDIMCI PANELLER
    // ============================================================
    
    showReportHistory(player) {
        if (this._fixHistory.length === 0) {
            Systems.sendMessage(player, "§7Henüz hiç düzeltme yapılmamış.");
            return;
        }
        let msg = `§l📋 DÜZELTME GEÇMİŞİ\n§8────────────────\n`;
        this._fixHistory.slice(0, 15).forEach(f => {
            const time = new Date(f.timestamp).toLocaleString("tr-TR");
            msg += `§7[${time}] §a✓ ${f.description}\n  §7(${f.fixedBy})\n`;
        });
        Systems.sendMessage(player, msg);
    },
    
    showHealthStatus(player) {
        const health = EmergencyRecovery.healthCheck();
        let msg = `§l🩺 SİSTEM SAĞLIĞI\n§8────────────────\n`;
        msg += `§7Durum: ${health.healthy ? "§aSAĞLIKLI" : "§cSORUN VAR"}\n`;
        msg += `§7TPS: §e${PerformanceMonitor.getStats().tps}\n`;
        msg += `§7Cache Boyutu: §e${Core.MemoryCache?._map?.size || 0}\n`;
        msg += `§7Aktif Event: §e${EventManager.getActiveEvents().length}\n`;
        if (health.issues.length > 0) {
            msg += `\n§c❌ Sorunlar:\n`;
            health.issues.forEach(i => msg += `  §7- §f${i}\n`);
        }
        if (health.warnings.length > 0) {
            msg += `\n§e⚠️ Uyarılar:\n`;
            health.warnings.forEach(w => msg += `  §7- §f${w}\n`);
        }
        Systems.sendMessage(player, msg);
    },
    
    showPerformancePanel(player) {
        const stats = PerformanceMonitor.getStats();
        const detailed = PerformanceMonitor.getDetailedStats();
        let msg = `§l📊 PERFORMANS\n§8────────────────\n`;
        msg += `§7TPS: §e${stats.tps}/20\n`;
        msg += `§7Ort. Tick Süresi: §e${stats.avgTickTime}ms\n`;
        msg += `§7Entity Sayısı: §e${detailed.entityCount}\n`;
        msg += `§7Krallık Sayısı: §e${detailed.krallikCount}\n`;
        msg += `§7Claim Sayısı: §e${detailed.claimCount}\n`;
        msg += `§7Asker Sayısı: §e${detailed.askerCount}\n`;
        msg += `§7Aktif Uyarı: §e${stats.alertCount}\n`;
        msg += `§8────────────────\n`;
        msg += `§e💡 Öneri: TPS < 15 ise AI tick aralığını artırın.`;
        Systems.sendMessage(player, msg);
        
        new ActionFormData()
            .title("§l📊 PERFORMANS")
            .body(msg)
            .button("§l🔄 ÖNBellek TEMİZLE")
            .button("§l📈 DETAYLI RAPOR")
            .button("§l❌ KAPAT")
            .show(player).then(r => {
                if (r.selection === 0) {
                    DataOptimizer.clearCache();
                    Systems.sendMessage(player, "§a✔ Önbellekler temizlendi!");
                    this.showPerformancePanel(player);
                }
                if (r.selection === 1) {
                    const detailedReport = PerformanceMonitor.getDetailedStats();
                    let detailMsg = `§l📈 DETAYLI PERFORMANS\n§8────────────────\n`;
                    detailMsg += `§7TPS: §e${detailedReport.tps}/20\n`;
                    detailMsg += `§7Ort. Tick: §e${detailedReport.avgTickTime}ms\n`;
                    detailMsg += `§7Entity: §e${detailedReport.entityCount}\n`;
                    detailMsg += `§7Krallık: §e${detailedReport.krallikCount}\n`;
                    detailMsg += `§7Claim: §e${detailedReport.claimCount}\n`;
                    detailMsg += `§7Asker: §e${detailedReport.askerCount}\n`;
                    detailMsg += `§7Alert: §e${detailedReport.alertCount}\n`;
                    Systems.sendMessage(player, detailMsg);
                }
            });
    },
    
    emergencyPanel(player) {
        new ActionFormData()
            .title("§l⚡ ACİL KURTARMA")
            .body("§cBu işlemler geri alınamaz!\n§7Yedekten geri yükleme veya acil restart yapabilirsiniz.")
            .button("§l💾 SON YEDEKTEN GERİ YÜKLE")
            .button("§l🔄 ACİL RESTART")
            .button("§l🔧 VERİ KURTARMA")
            .button("§l❌ KAPAT")
            .show(player).then(r => {
                if (r.canceled || r.selection === 3) return;
                if (r.selection === 0) {
                    if (EmergencyRecovery.restoreLatestBackup()) {
                        Systems.sendMessage(player, "§a✔ Son yedekten geri yüklendi! Sistemi yeniden başlatın.");
                    } else {
                        Systems.sendMessage(player, "§cYedek bulunamadı!");
                    }
                }
                if (r.selection === 1) {
                    EmergencyRecovery.emergencyRestart();
                    Systems.sendMessage(player, "§a✔ Acil restart tamamlandı!");
                }
                if (r.selection === 2) {
                    if (EmergencyRecovery.recoverFromCorruption()) {
                        Systems.sendMessage(player, "§a✔ Veri kurtarma tamamlandı!");
                    } else {
                        Systems.sendMessage(player, "§7Kurtarma gerektiren bir sorun yok.");
                    }
                }
            });
    },

    _findCoreXCalls() {
        // Bu fonksiyon dosya taraması yapamadığı için boş döner
        // Gerçek tespit runtime'da yapılmalı
        return [];
    }
};

// ============================================================
// CUSTOMIZE ANA SINIF
// ============================================================
export const Customize = {
    _authenticatedPlayers: {},

    authenticate(player) {
        const d = Core.Database.load();
        if (!d.customizeMenus) d.customizeMenus = {};
        if (!d.customizeMenus._global) d.customizeMenus._global = { menus: [], categories: [] };

        new ModalFormData()
            .title("§6🔧 CUSTOMIZE PANELİ")
            .textField("§fŞifre:", "")
            .show(player).then(r => {
                if (r.canceled) return;
                const sifre = r.formValues[0];

                if (!Core.RateLimiter.isAllowed(player, "customize_auth", 3, 30000)) {
                    Systems.sendMessage(player, "§cÇok fazla başarısız deneme! Lütfen bekle.");
                    return;
                }

                if (sifre === getCustomizeSifre()) {
                    this._authenticatedPlayers[player.name] = Date.now();
                    Core.LogSistemi?.log?.("customize", `${player.name} customize paneline giriş yaptı`);
                    Systems.sendMessage(player, "§a✔ Giriş başarılı!");
                    this._showMainPanel(player);
                } else {
                    Core.LogSistemi?.log?.("customize", `${player.name} yanlış şifre denemesi`, { sifre });
                    Systems.sendMessage(player, "§c✖ Yanlış şifre! Erişim engellendi.");
                }
            });
    },

    isAuthenticated(player) {
        const auth = this._authenticatedPlayers[player.name];
        if (!auth) return false;
        if (Date.now() - auth > 300000) { delete this._authenticatedPlayers[player.name]; return false; }
        return true;
    },

    _getGlobalMenus() {
        const d = Core.Database.load();
        if (!d.customizeMenus) d.customizeMenus = {};
        if (!d.customizeMenus._global) d.customizeMenus._global = { menus: [], categories: [] };
        return d.customizeMenus._global;
    },

    _getGlobalConfig() {
        const d = Core.Database.load();
        if (!d.customizeMenus) d.customizeMenus = {};
        if (!d.customizeMenus._config) d.customizeMenus._config = { anaMenuButtons: null, marketItems: null, askerler: null };
        return d.customizeMenus._config;
    },

    _saveGlobalConfig(cfg) {
        const d = Core.Database.load();
        if (!d.customizeMenus) d.customizeMenus = {};
        d.customizeMenus._config = cfg;
        Core.Database.markDirty("krallik_customize");
    },

    _saveMenus(globalMenus) {
        const d = Core.Database.load();
        d.customizeMenus._global = globalMenus;
        Core.Database.markDirty("krallik_customize");
    },

    applyConfigOverrides() {
        try {
            const cfg = this._getGlobalConfig();
            if (cfg.anaMenuButtons && Array.isArray(cfg.anaMenuButtons)) Config.ANA_MENU.buttons = cfg.anaMenuButtons;
            if (cfg.marketItems && typeof cfg.marketItems === "object") Config.MARKET_ITEMS = cfg.marketItems;
            if (cfg.askerler && typeof cfg.askerler === "object") Config.ASKERLER = cfg.askerler;
        } catch(e) {}
    },

    _showMainPanel(player) {
        if (!this.isAuthenticated(player)) return this.authenticate(player);

        const global = this._getGlobalMenus();
        let body = `§l🔧 CUSTOMIZE PANELİ\n§8────────────────\n`;
        body += `§fToplam Menü: §e${global.menus.length}\n`;
        body += `§fKategori: §e${global.categories.length}\n\n§7Menüler:\n`;
        global.menus.slice(0, 10).forEach(m => body += `${m.icon || "📋"} §f${m.name} §7(Sıra: ${m.order}, ${m.visible ? "§aGörünür" : "§cGizli"})\n`);
        if (global.menus.length > 10) body += `§7...ve ${global.menus.length - 10} menü daha\n`;

        const form = new ActionFormData()
            .title("§l🔧 CUSTOMIZE PANELİ")
            .body(body)
            .button("§l➕ MENÜ EKLE")
            .button("§l📋 MENÜLERİ YÖNET")
            .button("§l📦 KATEGORİLER")
            .button("§l🧩 SİSTEM BUTONLARI")
            .button("§l🛒 MARKET ÜRÜNLERİ")
            .button("§l💰 ZMC PANELİ")
            .button("§l🔧 AKILLI DEBUG & ONARIM")
            .button("§l🔄 VARSAYILANA DÖN")
            .button("§l💾 KAYDET")
            .button("§l❌ ÇIKIŞ");

        form.show(player).then(r => {
            if (r.canceled || r.selection === 9) { delete this._authenticatedPlayers[player.name]; return; }
            switch (r.selection) {
                case 0: this._addMenuForm(player); break;
                case 1: this._manageMenus(player); break;
                case 2: this._manageCategories(player); break;
                case 3: this._editAnaMenuButtons(player); break;
                case 4: this._editMarketItems(player); break;
                case 5: this._zmcPanel(player); break;
                case 6: Debug.showDebugMenu(player); break;
                case 7: this._resetToDefault(player); break;
                case 8: this._forceSave(player); break;
            }
        });
    },

    _zmcPanel(player) {
        if (!this.isAuthenticated(player)) return this.authenticate(player);
        const players = world.getAllPlayers().map(p => p.name);
        new ActionFormData().title("§l💰 ZMC PANELİ").body("§7Buradan oyunculara ZMC ekleyip/çıkarabilirsin.")
            .button("§l➕ ZMC VER").button("§l➖ ZMC AL").button("§l⬅️ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 2) return this._showMainPanel(player);
                if (players.length === 0) { Systems.sendMessage(player, "§cOyuncu yok."); return this._showMainPanel(player); }
                new ModalFormData().title(r.selection === 0 ? "ZMC VER" : "ZMC AL").dropdown("Oyuncu:", players, 0).textField("Miktar:", "1000")
                    .show(player).then(r2 => {
                        if (r2.canceled) return this._zmcPanel(player);
                        const target = players[r2.formValues[0]];
                        const amount = Math.max(0, parseInt(r2.formValues[1] || "0"));
                        if (!amount || amount < 1) { Systems.sendMessage(player, "§cGeçersiz miktar."); return this._zmcPanel(player); }
                        const targetPlayer = world.getAllPlayers().find(p => p.name === target);
                        const before = targetPlayer ? Systems.getZMC(targetPlayer) : null;
                        if (r.selection === 0) Admin.paraVer(target, amount);
                        else Admin.paraAl(target, amount);
                        const after = targetPlayer ? Systems.getZMC(targetPlayer) : null;
                        if (targetPlayer && after !== before) {
                            Systems.sendMessage(player, `§a✔ İşlem yapıldı. ${target} bakiyesi: §e${before} §f→ §a${after} ZMC`);
                        } else {
                            Systems.sendMessage(player, "§c✘ İşlem uygulanamadı (oyuncu bulunamadı veya bakiye değişmedi).");
                        }
                        this._zmcPanel(player);
                    });
            });
    },

    _editAnaMenuButtons(player) {
        if (!this.isAuthenticated(player)) return this.authenticate(player);
        const cfg = this._getGlobalConfig();
        if (!cfg.anaMenuButtons) cfg.anaMenuButtons = JSON.parse(JSON.stringify(Config.ANA_MENU.buttons || []));
        const buttons = cfg.anaMenuButtons;
        const form = new ActionFormData().title("§l🧩 SİSTEM BUTONLARI").body("§7Krallık ana menüsündeki butonları düzenle.").button("§l➕ BUTON EKLE");
        buttons.forEach(b => form.button(`${b.visible ? "§a" : "§c"}${b.emoji || ""} ${b.name} §7(${b.id})`));
        form.button("§l⬅️ GERİ");
        form.show(player).then(r => {
            if (r.canceled || r.selection === buttons.length + 1) return this._showMainPanel(player);
            if (r.selection === 0) return this._addAnaMenuButton(player);
            this._editAnaMenuButton(player, buttons[r.selection - 1]);
        });
    },

    _addAnaMenuButton(player) {
        const cfg = this._getGlobalConfig();
        const buttons = cfg.anaMenuButtons || (cfg.anaMenuButtons = JSON.parse(JSON.stringify(Config.ANA_MENU.buttons || [])));
        new ModalFormData().title("§l➕ BUTON EKLE")
            .textField("ID:", "custom_id").textField("İsim:", "Yeni Buton").textField("Emoji:", "✨")
            .toggle("Görünür:", true).textField("Permission:", "")
            .show(player).then(r => {
                if (r.canceled) return this._editAnaMenuButtons(player);
                const id = String(r.formValues[0] || "").trim();
                if (!id) { Systems.sendMessage(player, "§cID boş olamaz."); return this._editAnaMenuButtons(player); }
                buttons.push({ id, name: r.formValues[1] || "Yeni Buton", emoji: r.formValues[2] || "✨", permission: (r.formValues[4] || "").trim() || null, order: buttons.length, visible: !!r.formValues[3] });
                cfg.anaMenuButtons = buttons;
                this._saveGlobalConfig(cfg);
                this.applyConfigOverrides();
                this._editAnaMenuButtons(player);
            });
    },

    _editAnaMenuButton(player, btn) {
        const cfg = this._getGlobalConfig();
        const buttons = cfg.anaMenuButtons || [];
        const idx = buttons.findIndex(b => b.id === btn.id);
        if (idx < 0) return this._editAnaMenuButtons(player);
        new ActionFormData().title(`§lDüzenle: ${btn.name}`)
            .body(`§7ID: ${btn.id}\n§7Emoji: ${btn.emoji || ""}\n§7Görünür: ${btn.visible ? "Evet" : "Hayır"}\n§7Permission: ${btn.permission || "Yok"}\n§7Sıra: ${btn.order ?? idx}`)
            .button("§l✏️ İsim").button("§l😀 Emoji").button("§l👁️ Göster/Gizle")
            .button("§l🔑 Permission").button("§l🗑️ Sil").button("§l⬅️ Geri")
            .show(player).then(r => {
                if (r.canceled || r.selection === 5) return this._editAnaMenuButtons(player);
                if (r.selection === 2) {
                    buttons[idx].visible = !buttons[idx].visible;
                    cfg.anaMenuButtons = buttons; this._saveGlobalConfig(cfg); this.applyConfigOverrides();
                    return this._editAnaMenuButton(player, buttons[idx]);
                }
                if (r.selection === 4) {
                    buttons.splice(idx, 1);
                    cfg.anaMenuButtons = buttons; this._saveGlobalConfig(cfg); this.applyConfigOverrides();
                    return this._editAnaMenuButtons(player);
                }
                const title = r.selection === 0 ? "İsim" : r.selection === 1 ? "Emoji" : "Permission";
                const current = r.selection === 0 ? (buttons[idx].name || "") : r.selection === 1 ? (buttons[idx].emoji || "") : (buttons[idx].permission || "");
                new ModalFormData().title(`§l${title} Değiştir`).textField(title + ":", current).show(player).then(r2 => {
                    if (r2.canceled) return this._editAnaMenuButton(player, buttons[idx]);
                    if (r.selection === 0) buttons[idx].name = r2.formValues[0] || "Buton";
                    if (r.selection === 1) buttons[idx].emoji = r2.formValues[0] || "✨";
                    if (r.selection === 3) buttons[idx].permission = (r2.formValues[0] || "").trim() || null;
                    cfg.anaMenuButtons = buttons; this._saveGlobalConfig(cfg); this.applyConfigOverrides();
                    this._editAnaMenuButton(player, buttons[idx]);
                });
            });
    },

    _editMarketItems(player) {
        if (!this.isAuthenticated(player)) return this.authenticate(player);
        const cfg = this._getGlobalConfig();
        if (!cfg.marketItems) cfg.marketItems = JSON.parse(JSON.stringify(Config.MARKET_ITEMS || {}));
        const items = cfg.marketItems;
        const keys = Object.keys(items);
        const form = new ActionFormData().title("§l🛒 MARKET ÜRÜNLERİ").body("§7Ürün ekle/sil/fiyat değiştir.").button("§l➕ ÜRÜN EKLE");
        keys.forEach(id => { const it = items[id]; form.button(`${it.emoji || "📦"} ${it.name} §7(${it.basePrice} ZMC)`); });
        form.button("§l⬅️ GERİ");
        form.show(player).then(r => {
            if (r.canceled || r.selection === keys.length + 1) return this._showMainPanel(player);
            if (r.selection === 0) return this._addMarketItem(player);
            this._editMarketItem(player, keys[r.selection - 1]);
        });
    },

    _addMarketItem(player) {
        const cfg = this._getGlobalConfig();
        const items = cfg.marketItems || (cfg.marketItems = JSON.parse(JSON.stringify(Config.MARKET_ITEMS || {})));
        new ModalFormData().title("§l➕ MARKET ÜRÜN EKLE")
            .textField("ID:", "yeni_item").textField("İsim:", "Yeni Ürün").textField("Emoji:", "📦")
            .textField("Kategori:", "misc").textField("Fiyat:", "1000").textField("Stok Limiti:", "10")
            .show(player).then(r => {
                if (r.canceled) return this._editMarketItems(player);
                const id = String(r.formValues[0] || "").trim();
                if (!id) { Systems.sendMessage(player, "§cID boş olamaz."); return this._editMarketItems(player); }
                items[id] = { id, name: r.formValues[1] || "Yeni Ürün", emoji: r.formValues[2] || "📦", category: r.formValues[3] || "misc", basePrice: Math.max(0, parseInt(r.formValues[4] || "0")), stockLimit: Math.max(1, parseInt(r.formValues[5] || "1")), warMultiplier: 1.5 };
                cfg.marketItems = items; this._saveGlobalConfig(cfg); this.applyConfigOverrides();
                this._editMarketItems(player);
            });
    },

    _editMarketItem(player, itemId) {
        const cfg = this._getGlobalConfig();
        const items = cfg.marketItems || {};
        const it = items[itemId];
        if (!it) return this._editMarketItems(player);
        new ActionFormData().title(`§lDüzenle: ${it.name}`)
            .body(`§7ID: ${it.id}\n§7Fiyat: ${it.basePrice}\n§7Stok: ${it.stockLimit}\n§7Kategori: ${it.category || ""}\n§7Emoji: ${it.emoji || ""}`)
            .button("§l✏️ İsim").button("§l😀 Emoji").button("§l💵 Fiyat")
            .button("§l📦 Stok").button("§l🗂️ Kategori").button("§l🗑️ Sil").button("§l⬅️ Geri")
            .show(player).then(r => {
                if (r.canceled || r.selection === 6) return this._editMarketItems(player);
                if (r.selection === 5) {
                    delete items[itemId];
                    cfg.marketItems = items; this._saveGlobalConfig(cfg); this.applyConfigOverrides();
                    return this._editMarketItems(player);
                }
                const field = r.selection === 0 ? "name" : r.selection === 1 ? "emoji" : r.selection === 2 ? "basePrice" : r.selection === 3 ? "stockLimit" : "category";
                const current = String(it[field] ?? "");
                new ModalFormData().title("§lDüzenle").textField(field + ":", current).show(player).then(r2 => {
                    if (r2.canceled) return this._editMarketItem(player, itemId);
                    let v = r2.formValues[0];
                    if (field === "basePrice" || field === "stockLimit") v = Math.max(field === "stockLimit" ? 1 : 0, parseInt(v || "0"));
                    it[field] = v;
                    cfg.marketItems = items; this._saveGlobalConfig(cfg); this.applyConfigOverrides();
                    this._editMarketItem(player, itemId);
                });
            });
    },

    _addMenuForm(player) {
        new ModalFormData()
            .title("§l➕ MENÜ EKLE")
            .textField("§fMenü Adı:", "Yeni Menü").textField("§fİkon:", "📋").textField("§fAçıklama:", "")
            .textField("§fRenk Kodu:", "§f").dropdown("§fGörünürlük:", ["Herkes", "Sadece Kral", "Sadece Admin", "Sadece Üye", "Savaş Zamanı"], 0)
            .toggle("§fGörünür:", true)
            .show(player).then(r => {
                if (r.canceled) return this._showMainPanel(player);
                const visibilityMap = ["all", "kral", "admin", "uye", "savas"];
                const global = this._getGlobalMenus();
                const newMenu = {
                    id: "menu_" + Date.now(), name: r.formValues[0] || "Yeni Menü", icon: r.formValues[1] || "📋",
                    description: r.formValues[2] || "", color: r.formValues[3] || "§f",
                    visibility: visibilityMap[r.formValues[4]] || "all", visible: !!r.formValues[5],
                    order: global.menus.length, buttons: []
                };
                global.menus.push(newMenu);
                this._saveMenus(global);
                Systems.sendMessage(player, `§a✔ "${newMenu.name}" menüsü eklendi!`);
                this._showMainPanel(player);
            });
    },

    _manageMenus(player) {
        const global = this._getGlobalMenus();
        if (global.menus.length === 0) { Systems.sendMessage(player, "§7Henüz özel menü yok."); return this._showMainPanel(player); }
        const form = new ActionFormData().title("§l📋 MENÜ YÖNETİMİ").body(`§f${global.menus.length} menü bulundu.`);
        global.menus.forEach(m => form.button(`${m.icon || "📋"} ${m.name} §7(Sıra: ${m.order})`));
        form.button("§l❌ GERİ");
        form.show(player).then(r => {
            if (r.canceled || r.selection === global.menus.length) return this._showMainPanel(player);
            this._editMenu(player, global.menus[r.selection]);
        });
    },

    _editMenu(player, menu) {
        new ActionFormData()
            .title(`§lDüzenle: ${menu.name}`)
            .body(`§fİkon: ${menu.icon || "Yok"}\n§fAçıklama: ${menu.description || "Yok"}\n§fRenk: ${menu.color || "Varsayılan"}\n§fGörünürlük: ${menu.visibility || "all"}\n§fGörünür: ${menu.visible ? "§aEvet" : "§cHayır"}\n§fButon Sayısı: ${(menu.buttons || []).length}`)
            .button("✏️ ADI").button("🎨 İKON").button("📝 AÇIKLAMA").button("🌈 RENK")
            .button("👁️ GÖRÜNÜRLÜK").button("👁️ GÖSTER/GİZLE").button("⬆️⬇️ SIRA")
            .button("🔘 BUTONLAR").button("🗑️ SİL").button("❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 9) return this._manageMenus(player);
                switch (r.selection) {
                    case 0: this._editMenuName(player, menu); break;
                    case 1: this._editMenuIcon(player, menu); break;
                    case 2: this._editMenuDescription(player, menu); break;
                    case 3: this._editMenuColor(player, menu); break;
                    case 4: this._editMenuVisibility(player, menu); break;
                    case 5: this._toggleMenuVisibility(player, menu); break;
                    case 6: this._editMenuOrder(player, menu); break;
                    case 7: this._manageButtons(player, menu); break;
                    case 8: this._deleteMenu(player, menu); break;
                }
            });
    },

    _editMenuName(player, menu) {
        new ModalFormData().title("✏️ MENÜ ADI").textField("Yeni Ad:", menu.name).show(player).then(r => {
            if (r.canceled) return this._editMenu(player, menu);
            menu.name = r.formValues[0] || menu.name;
            this._saveMenus(this._getGlobalMenus());
            Systems.sendMessage(player, "§a✔ Menü adı güncellendi!");
            this._editMenu(player, menu);
        });
    },

    _editMenuIcon(player, menu) {
        new ModalFormData().title("🎨 İKON").textField("Yeni İkon:", menu.icon || "📋").show(player).then(r => {
            if (r.canceled) return this._editMenu(player, menu);
            menu.icon = r.formValues[0] || "📋";
            this._saveMenus(this._getGlobalMenus());
            Systems.sendMessage(player, "§a✔ İkon güncellendi!");
            this._editMenu(player, menu);
        });
    },

    _editMenuDescription(player, menu) {
        new ModalFormData().title("📝 AÇIKLAMA").textField("Açıklama:", menu.description || "").show(player).then(r => {
            if (r.canceled) return this._editMenu(player, menu);
            menu.description = r.formValues[0] || "";
            this._saveMenus(this._getGlobalMenus());
            Systems.sendMessage(player, "§a✔ Açıklama güncellendi!");
            this._editMenu(player, menu);
        });
    },

    _editMenuColor(player, menu) {
        new ModalFormData().title("🌈 RENK").textField("Renk Kodu:", menu.color || "§f").show(player).then(r => {
            if (r.canceled) return this._editMenu(player, menu);
            menu.color = r.formValues[0] || "§f";
            this._saveMenus(this._getGlobalMenus());
            Systems.sendMessage(player, "§a✔ Renk güncellendi!");
            this._editMenu(player, menu);
        });
    },

    _editMenuVisibility(player, menu) {
        new ActionFormData().title("👁️ GÖRÜNÜRLÜK").body(`§fMevcut: §e${menu.visibility || "all"}`)
            .button("Herkes").button("Sadece Kral").button("Sadece Admin").button("Sadece Üye").button("Savaş Zamanı").button("❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 5) return this._editMenu(player, menu);
                const map = ["all", "kral", "admin", "uye", "savas"];
                menu.visibility = map[r.selection];
                this._saveMenus(this._getGlobalMenus());
                Systems.sendMessage(player, `§a✔ Görünürlük: ${menu.visibility}`);
                this._editMenu(player, menu);
            });
    },

    _toggleMenuVisibility(player, menu) {
        menu.visible = !menu.visible;
        this._saveMenus(this._getGlobalMenus());
        Systems.sendMessage(player, `§a✔ Menü ${menu.visible ? "görünür" : "gizli"} oldu!`);
        this._editMenu(player, menu);
    },

    _editMenuOrder(player, menu) {
        const global = this._getGlobalMenus();
        new ModalFormData().title("⬆️⬇️ SIRA").slider("Yeni Sıra:", 0, Math.max(0, global.menus.length - 1), 1, menu.order || 0)
            .show(player).then(r => {
                if (r.canceled) return this._editMenu(player, menu);
                const newOrder = r.formValues[0];
                global.menus.splice(global.menus.indexOf(menu), 1);
                global.menus.splice(newOrder, 0, menu);
                global.menus.forEach((m, i) => m.order = i);
                this._saveMenus(global);
                Systems.sendMessage(player, `§a✔ Sıra güncellendi: ${newOrder}`);
                this._manageMenus(player);
            });
    },

    _manageButtons(player, menu) {
        const buttons = menu.buttons || [];
        const form = new ActionFormData().title(`🔘 Butonlar: ${menu.name}`).body(`§f${buttons.length} buton`);
        buttons.forEach((b, i) => form.button(`${b.icon || "▶️"} ${b.label || "Buton " + (i + 1)} §7(${b.type || "command"})`));
        form.button("➕ BUTON EKLE").button("❌ GERİ");
        form.show(player).then(r => {
            if (r.canceled) return this._editMenu(player, menu);
            if (r.selection === buttons.length) this._addButton(player, menu);
            else if (r.selection === buttons.length + 1) this._editMenu(player, menu);
            else if (r.selection < buttons.length) this._editButton(player, menu, buttons[r.selection], r.selection);
        });
    },

    _addButton(player, menu) {
        new ModalFormData()
            .title("➕ BUTON EKLE")
            .textField("Buton Adı:", "Yeni Buton").textField("İkon:", "▶️").textField("Komut/Event:", "")
            .dropdown("Tip:", ["command", "event", "asker_cagir", "market", "claim", "savas"], 0)
            .textField("Permission:", "").textField("Fiyat:", "0").textField("Cooldown (saniye):", "0")
            .show(player).then(r => {
                if (r.canceled) return this._manageButtons(player, menu);
                if (!menu.buttons) menu.buttons = [];
                const types = ["command", "event", "asker_cagir", "market", "claim", "savas"];
                menu.buttons.push({
                    id: "btn_" + Date.now(), label: r.formValues[0] || "Yeni Buton", icon: r.formValues[1] || "▶️",
                    action: r.formValues[2] || "", type: types[r.formValues[3]] || "command",
                    permission: r.formValues[4] || null, price: parseInt(r.formValues[5]) || 0,
                    cooldown: parseInt(r.formValues[6]) || 0
                });
                this._saveMenus(this._getGlobalMenus());
                Systems.sendMessage(player, `§a✔ Buton eklendi!`);
                this._manageButtons(player, menu);
            });
    },

    _editButton(player, menu, button, index) {
        const handleText = (field, label, updater) => {
            new ModalFormData().title(`§l${label}`).textField(`${label}:`, String(button[field] ?? "")).show(player).then(r2 => {
                if (r2.canceled) return;
                updater(r2.formValues[0]);
                this._saveMenus(this._getGlobalMenus());
                Systems.sendMessage(player, `§a✔ ${label} güncellendi!`);
                this._editButton(player, menu, button, index);
            });
        };
        const handleNumber = (field, label, min, max, updater) => {
            new ModalFormData().title(`§l${label}`).textField(`${label}:`, String(button[field] ?? "0")).show(player).then(r2 => {
                if (r2.canceled) return;
                let v = parseInt(r2.formValues[0]) || 0;
                if (min !== undefined) v = Math.max(min, v);
                if (max !== undefined) v = Math.min(max, v);
                updater(v);
                this._saveMenus(this._getGlobalMenus());
                Systems.sendMessage(player, `§a✔ ${label} güncellendi!`);
                this._editButton(player, menu, button, index);
            });
        };
        new ActionFormData()
            .title(`§lDüzenle: ${button.label}`)
            .body(`§fTip: ${button.type}\n§fKomut: ${button.action || "Yok"}\n§fPermission: ${button.permission || "Herkes"}\n§fFiyat: ${button.price || 0}\n§fCooldown: ${button.cooldown || 0}s`)
            .button("✏️ ADI").button("⚡ KOMUT").button("🔒 PERMİSSİON").button("💰 FİYAT")
            .button("⏱️ COOLDOWN").button("🎨 İKON").button("⬆️ YUKARI").button("⬇️ AŞAĞI").button("🗑️ SİL").button("❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 9) return this._manageButtons(player, menu);
                switch (r.selection) {
                    case 0: handleText("label", "Buton Adı", v => button.label = v); break;
                    case 1: handleText("action", "Komut/Event", v => button.action = v); break;
                    case 2: handleText("permission", "Permission", v => button.permission = v || null); break;
                    case 3: handleNumber("price", "Fiyat", 0, null, v => button.price = v); break;
                    case 4: handleNumber("cooldown", "Cooldown", 0, null, v => button.cooldown = v); break;
                    case 5: handleText("icon", "İkon", v => button.icon = v || "▶️"); break;
                    case 6: if (index > 0) { [menu.buttons[index], menu.buttons[index-1]] = [menu.buttons[index-1], menu.buttons[index]]; this._saveMenus(this._getGlobalMenus()); Systems.sendMessage(player, "§a✔ Buton yukarı taşındı!"); } this._manageButtons(player, menu); break;
                    case 7: if (index < menu.buttons.length-1) { [menu.buttons[index], menu.buttons[index+1]] = [menu.buttons[index+1], menu.buttons[index]]; this._saveMenus(this._getGlobalMenus()); Systems.sendMessage(player, "§a✔ Buton aşağı taşındı!"); } this._manageButtons(player, menu); break;
                    case 8: menu.buttons.splice(index, 1); this._saveMenus(this._getGlobalMenus()); Systems.sendMessage(player, "§cButon silindi!"); this._manageButtons(player, menu); break;
                }
            });
    },

    _manageCategories(player) {
        const global = this._getGlobalMenus();
        let body = `§l📦 KATEGORİLER\n§8────────────────\n`;
        global.categories.forEach(c => body += `${c.icon || "📁"} §f${c.name}\n`);
        if (global.categories.length === 0) body += "§7Henüz kategori yok\n";
        new ActionFormData().title("§l📦 KATEGORİLER").body(body)
            .button("§l➕ KATEGORİ EKLE").button("§l🗑️ KATEGORİ SİL").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 2) return this._showMainPanel(player);
                if (r.selection === 0) {
                    new ModalFormData().title("➕ KATEGORİ EKLE").textField("Kategori Adı:", "Yeni Kategori").textField("İkon:", "📁")
                        .show(player).then(r2 => {
                            if (r2.canceled) return this._manageCategories(player);
                            global.categories.push({ id: "cat_" + Date.now(), name: r2.formValues[0] || "Kategori", icon: r2.formValues[1] || "📁" });
                            this._saveMenus(global);
                            Systems.sendMessage(player, "§a✔ Kategori eklendi!");
                            this._manageCategories(player);
                        });
                }
                if (r.selection === 1 && global.categories.length > 0) {
                    const form = new ActionFormData().title("🗑️ SİL").button("❌ GERİ");
                    global.categories.forEach(c => form.button(c.name));
                    form.show(player).then(r2 => {
                        if (r2.canceled || r2.selection === 0) return this._manageCategories(player);
                        global.categories.splice(r2.selection - 1, 1);
                        this._saveMenus(global);
                        Systems.sendMessage(player, "§cKategori silindi!");
                        this._manageCategories(player);
                    });
                }
            });
    },

    _deleteMenu(player, menu) {
        new MessageFormData().title("§c🗑️ MENÜYÜ SİL")
            .body(`§f"${menu.name}" menüsünü silmek istediğinize emin misiniz?\n\n§cBu işlem geri alınamaz!`)
            .button1("§c✔ SİL").button2("§7VAZGEÇ")
            .show(player).then(r => {
                if (r.selection === 0) {
                    const global = this._getGlobalMenus();
                    const index = global.menus.indexOf(menu);
                    if (index > -1) {
                        global.menus.splice(index, 1);
                        global.menus.forEach((m, i) => m.order = i);
                        this._saveMenus(global);
                        Systems.sendMessage(player, "§cMenü silindi!");
                    }
                }
                this._manageMenus(player);
            });
    },

    _resetToDefault(player) {
        new MessageFormData().title("§c🔄 VARSAYILANA DÖN")
            .body("§fTüm özel menüler silinecek ve varsayılan menülere dönülecek.\n\n§cBu işlem geri alınamaz!")
            .button1("§c✔ SIFIRLA").button2("§7VAZGEÇ")
            .show(player).then(r => {
                if (r.selection === 0) {
                    const global = this._getGlobalMenus();
                    global.menus = []; global.categories = [];
                    this._saveMenus(global);
                    const cfg = this._getGlobalConfig();
                    cfg.anaMenuButtons = null; cfg.marketItems = null; cfg.askerler = null;
                    this._saveGlobalConfig(cfg);
                    this.applyConfigOverrides();
                    Systems.sendMessage(player, "§a✔ Varsayılan menülere dönüldü!");
                }
                this._showMainPanel(player);
            });
    },

    _forceSave(player) {
        Core.Database.save(true);
        Systems.sendMessage(player, "§a✔ Tüm veriler kaydedildi!");
        this._showMainPanel(player);
    },

    buildDynamicMenu(player, menuData) {
        const form = new ActionFormData().title(`${menuData.color || "§f"}${menuData.icon || ""} ${menuData.name}`);
        if (menuData.description) form.body(menuData.description);
        for (const btn of (menuData.buttons || [])) form.button(`${btn.icon || ""} ${btn.label}${btn.price ? ` §7(${btn.price} ZMC)` : ""}`);
        return form;
    },

    executeButtonAction(player, button) {
        if (!button) return;
        if (button.permission && !Permission.hasPermission(player, button.permission)) {
            Systems.sendMessage(player, "§cBu buton için yetkiniz yok!"); return;
        }
        if (button.price && button.price > 0) {
            const zmc = Systems.getZMC(player);
            if (zmc < button.price) { Systems.sendMessage(player, `§cYetersiz ZMC! Gereken: ${button.price}`); return; }
            Systems.removeZMC(player, button.price);
        }
        switch (button.type) {
            case "command": if (button.action) Systems.runCommand(player, button.action); break;
            case "event": Core.ModuleRegistry?.executeHook?.(button.action, player); break;
            case "market": Core.UI?.marketMenusu?.(player); break;
            case "claim": Core.UI?.claimMenusu?.(player); break;
            case "savas": Core.UI?.savasMenusu?.(player); break;
            case "asker_cagir": Core.UI?.askerMenusu?.(player); break;
        }
    }
};