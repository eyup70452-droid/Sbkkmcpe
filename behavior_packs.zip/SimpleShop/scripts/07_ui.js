// ============================================================
// MODÜL 07_UI1: UI - Ana Menü, Krallık Kurma, Asker, Claim, Ekonomi, Savaş (EKSİKSİZ)
// ============================================================
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager, ClaimHarita } from "./02_claim.js";
import { Economy, Market, TradeRoute, EkonomiEk } from "./03_economy.js";
import { Systems, AI, Combat, Siege, Formasyon, Devriye, Morale } from "./04_military.js";
import { Diplomacy, Vassal, Hero, KrallikBildirim } from "./05_diplomacy.js";
import { KrallikYonetim, Profile, Leaderboard, News, SavasRaporu, Alarm, LogSistemi, Admin } from "./06_kingdom.js";
import { Power } from "./10_power.js";
import { Permission } from "./12_gelisim.js";

export const UI = {
    anaMenu(player) {
        const kid = Systems.getPlayerKrallikId(player);
        const krallik = Core.Database.getKrallik(kid);
        
        if (!krallik) {
            new ActionFormData()
                .title("§6🏰 KRALLIK KUR")
                .body(`§fKrallık kur?\n\n§eÜcret: §6500 ZMC\n§fBakiye: §a${Systems.getZMC(player)} ZMC`)
                .button("§a✔ KUR")
                .button("§c✖ VAZGEÇ")
                .button("§4🔱 ADMIN")
                .show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection === 0 && Systems.getZMC(player) >= 500) this.kurmaFormu(player);
                    if (r.selection === 2 && Systems.isAdmin(player)) this.adminMenu(player);
                });
            return;
        }

        const claims = ClaimManager.getKrallikClaims(kid).length;
        const asker = Core.Cache?.getKrallikEntityCount?.(kid) || 0;
        const sv = Systems.getSeviyeBilgisi(krallik.seviye || 1);
        const power = Power?.formatPower?.(krallik.totalPower) || krallik.totalPower || 0;
        const statusEmoji = krallik.status === "savas" ? "⚔️" : krallik.status === "kusatma" ? "🏰" : krallik.status === "alarm" ? "⚠️" : "☮️";

        let body = `§l§6🏰 ${krallik.isim}\n§8────────────────\n`;
        body += `§fLider: §6👑 ${krallik.lider}\n`;
        body += `§fSeviye: §e${krallik.seviye || 1} | Durum: ${statusEmoji}\n`;
        body += `§fAsker: §a${asker}/${sv.askerLimiti}\n`;
        body += `§fToprak: §b${claims}/${sv.maxToprak}\n`;
        body += `§fHazine: §a${(krallik.hazine || 0).toLocaleString()} ZMC\n`;
        body += `§fMoral: §e${krallik.moral || 60}%\n`;
        body += `§fGüç: §d${typeof power === "number" ? power.toLocaleString() : power}`;

        const menu = new ActionFormData().title(`§l§6🏰 ${krallik.isim}`).body(body);

        const buttons = [
            { id: "ordu", name: "Ordu", emoji: "👥", action: () => this.askerMenusu(player) },
            { id: "claim", name: "Claim", emoji: "🏁", action: () => this.claimMenusu(player) },
            { id: "toprak", name: "Toprak", emoji: "🗺️", action: () => this.topraklarim(player) },
            { id: "ekonomi", name: "Ekonomi", emoji: "💰", action: () => this.ekonomiMenusu(player) },
            { id: "savas", name: "Savaş", emoji: "⚔️", action: () => this.savasMenusu(player) },
            { id: "diplomasi", name: "Diplomasi", emoji: "🤝", action: () => this.diplomasiMenusu(player) },
            { id: "uyeler", name: "Üyeler", emoji: "👤", action: () => this.uyeMenusu(player) },
            { id: "gelisim", name: "Gelişim", emoji: "🌱", action: () => this.gelisimMenusu(player) },
            { id: "guc", name: "Güç", emoji: "💪", action: () => this.gucMenusu(player) },
            { id: "rapor", name: "Raporlar", emoji: "📊", action: () => this.raporMenusu(player) },
            { id: "profil", name: "Profil", emoji: "🪪", action: () => this.profilMenusu(player) },
            { id: "liderlik", name: "Liderlik", emoji: "🏆", action: () => this.leaderboardMenusu(player) },
            { id: "haberler", name: "Haberler", emoji: "📰", action: () => this.haberlerMenusu(player) },
            { id: "sur", name: "Sur", emoji: "🧱", action: () => this.surMenusu(player) },
            { id: "ticaretyolu", name: "Ticaret Yolu", emoji: "🛒", action: () => this.ticaretYoluMenusu(player) },
            { id: "kahraman", name: "Kahraman", emoji: "🦸", action: () => this.kahramanMenusu(player) },
            { id: "market", name: "Market", emoji: "🛍️", action: () => this.marketMenusu(player) },
            { id: "customize", name: "Özelleştir", emoji: "🎨", action: () => globalThis.Krallik?.Customize?.authenticate?.(player) }
        ];

        if (Systems.isAdmin?.(player)) {
            buttons.push({ id: "admin", name: "Admin", emoji: "🔱", action: () => this.adminMenu(player) });
        }

        for (const btn of buttons) menu.button(`${btn.emoji} ${btn.name}`);
        menu.button("§l❌ KAPAT");

        menu.show(player).then(r => {
            if (r.canceled || r.selection === buttons.length) return;
            buttons[r.selection].action();
        });
    },

    kurmaFormu(player) {
        new ModalFormData()
            .title("§6🏰 KRALLIK KURULUŞ")
            .textField("§fKrallık Adı:", "İmparatorluk")
            .textField("§fAçıklama:", "Güçlü krallık...")
            .dropdown("§fRenk:", ["§cKırmızı", "§9Mavi", "§aYeşil", "§eSarı", "§5Mor", "§6Turuncu", "§fBeyaz", "§8Siyah"], 0)
            .dropdown("§fÜlke:", Object.values(Config.ULKELER).map(u => u.emoji + " " + u.name), 0)
            .show(player).then(r => {
                if (!r.canceled) KrallikYonetim.kur(player, r.formValues[0], r.formValues[1], r.formValues[2], r.formValues[3]);
            });
    },

    askerMenusu(player) {
        const kid = Systems.getPlayerKrallikId(player);
        const krallik = Core.Database.getKrallik(kid);
        if (!krallik) return this.anaMenu(player);

        new ActionFormData()
            .title("§l👥 ORDU")
            .body(`§fAsker: §a${Core.Cache?.getKrallikEntityCount?.(kid) || 0}/${Systems.getSeviyeBilgisi(krallik.seviye || 1).askerLimiti}\n§fBakiye: §a${Systems.getZMC(player).toLocaleString()} ZMC`)
            .button("§l➕ ASKER AL")
            .button("§l🎯 KOMUTLAR")
            .button("§l📐 FORMASYONLAR")
            .button("§l⭐ RANKLAR")
            .button("§l⬆️ ASKER GELİŞTİR")
            .button("§l🚶 DEVRİYE ATA")
            .button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 6) return this.anaMenu(player);
                if (r.selection === 0) this.askerAlMenusu(player);
                if (r.selection === 1) this.orduKomutlari(player);
                if (r.selection === 2) this.formasyonlar(player);
                if (r.selection === 3) this.rankMenusu(player);
                if (r.selection === 4) this.askerGelistir(player);
                if (r.selection === 5) this.devriyeAta(player);
            });
    },

    askerAlMenusu(player) {
        const kid = Systems.getPlayerKrallikId(player);
        const krallik = Core.Database.getKrallik(kid);
        if (!krallik) return this.askerMenusu(player);
        
        const sv = Systems.getSeviyeBilgisi(krallik.seviye || 1);
        const currentCount = Core.Cache?.getKrallikEntityCount?.(kid) || 0;
        if (currentCount >= sv.askerLimiti) {
            Systems.sendMessage(player, "§cLimit dolu!");
            return this.askerMenusu(player);
        }

        const claims = ClaimManager.getKrallikClaims(kid);
        if (!claims.length) { Systems.sendMessage(player, "§cToprağın yok!"); return this.askerMenusu(player); }

        const form = new ActionFormData().title("§l➕ ASKER AL").body(`§fBakiye: §a${Systems.getZMC(player).toLocaleString()} ZMC\n§fLimit: §e${currentCount}/${sv.askerLimiti}`);
        for (const [askerId, askerDef] of Object.entries(Config.ASKERLER)) {
            form.button(`${askerDef.emoji || ""} ${askerDef.name} - §e${askerDef.fiyat.toLocaleString()} ZMC`);
        }
        form.button("§l❌ GERİ");

        form.show(player).then(r => {
            const askerKeys = Object.keys(Config.ASKERLER);
            if (r.canceled || r.selection >= askerKeys.length) return this.askerMenusu(player);

            const askerId = askerKeys[r.selection];
            const askerDef = Config.ASKERLER[askerId];
            if (Systems.getZMC(player) < askerDef.fiyat) {
                Systems.sendMessage(player, "§cYetersiz!");
                return this.askerAlMenusu(player);
            }
            if (!Core.RateLimiter.isAllowed(player, "asker_al", 3, 2000)) {
                Systems.sendMessage(player, "§cÇok hızlı! Lütfen bekle.");
                return this.askerAlMenusu(player);
            }
            const claim = claims[Math.floor(Math.random() * claims.length)];
            const spawnLoc = { x: player.location.x + Math.random() * 4 - 2, y: player.location.y, z: player.location.z + Math.random() * 4 - 2 };

            let entity = null;
            try {
                const ulkeTipi = krallik.ulkeTipi;
                const entityId = Config.ASKER_ENTITY_MAP?.[ulkeTipi]?.[askerId] || askerDef.fallbackEntity;
                entity = player.dimension.spawnEntity(entityId, spawnLoc);
                // NapoleonicMergedBp birimi ise: vahşi canavar-saldırı davranışını kapat,
                // sadece Krallık komutlarıyla (SALDIR/SAVUN/vb.) hareket eden "sahipli" moda al.
                if (entityId !== askerDef.fallbackEntity) {
                    try { entity.triggerEvent(Config.ASKER_RECRUIT_EVENT); } catch(_e) {}
                }
                Systems.addTag(entity, `krallik_${kid}`);
                Systems.addTag(entity, `asker_${askerId}`);
                Systems.addTag(entity, "rank_acemi");
                Systems.addTag(entity, "savun");
                
                // Spawn başarılı olduktan sonra ZMC düş (güvenli sıra)
                Systems.removeZMC(player, askerDef.fiyat);

                const d = Core.Database.load();
                if (!d.askerKayit) d.askerKayit = {};
                d.askerKayit[entity.id] = { kill: 0, rank: "acemi", krallik: kid, type: askerId, level: 1 };
                Core.Database.markDirty("krallik_army");
                AI.initSoldier(entity, kid);
                Systems.sendMessage(player, `§a✔ ${askerDef.emoji || ""} ${askerDef.name} alındı!`);
            } catch(err) {
                // Spawn başarısız - ZMC düşülmediği için iade gerekmez
                Systems.sendMessage(player, `§cHata! Asker spawn edilemedi.`);
            }
            this.askerAlMenusu(player);
        });
    },

    orduKomutlari(player) {
        const komutlar = ["saldir", "savun", "kolacan", "geri_cekil", "krali_koru", "acil_toplan", "bayragi_savun", "devriye", "mevzi_kur", "serbest"];
        new ActionFormData()
            .title("§l🎯 KOMUTLAR")
            .button("§l⚔️ SALDIR").button("§l🛡️ SAVUN").button("§l🔍 KOLAÇAN")
            .button("§l🏃 GERİ ÇEKİL").button("§l👑 KRALI KORU").button("§l🚨 ACİL TOPLAN")
            .button("§l🏁 BAYRAĞI SAVUN").button("§l🚶 DEVRIYE").button("§l📐 MEVZİ KUR")
            .button("§l🆓 SERBEST").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 10) return this.askerMenusu(player);
                const komut = komutlar[r.selection];
                const kid = Systems.getPlayerKrallikId(player);
                if (!kid) return;

                const allTags = ["saldir", "savun", "kolacan", "geri_cekil", "krali_koru", "acil_toplan", "bayragi_savun", "devriye", "mevzi_kur", "formasyon_aktif", "serbest"];
                Core.Cache?.getEntities?.(true);
                const hedefEntities = Core.Cache?.getKrallikEntities?.(kid) || [];
                let komutUygulanan = 0;

                for (const e of hedefEntities) {
                    if (!Core.Cache?.isValidEntity?.(e)) continue;
                    if (!(e.getTags?.() || []).some(t => t.startsWith("asker_"))) continue;
                    allTags.forEach(t => { try { e.removeTag(t); } catch {} });
                    if (komut === "serbest") {
                        try {
                            let st = AI._soldierStates?.[e.id];
                            if (st) { st.holdPoint = null; st.formationOffsetX = null; st.formationOffsetZ = null; st.aiCooldown = 0; }
                        } catch {}
                        komutUygulanan++;
                        continue;
                    }
                    try { e.addTag(komut); komutUygulanan++; } catch {}
                    if (komut === "mevzi_kur") {
                        try {
                            let st = AI._soldierStates?.[e.id];
                            if (!st) st = AI.initSoldier(e, kid);
                            st.holdPoint = { x: e.location.x, z: e.location.z };
                        } catch {}
                    }
                }
                Systems.sendMessage(player, `§e${komutUygulanan} askere "§f${komut}§e" emri verildi!`);
                this.askerMenusu(player);
            });
    },

    formasyonlar(player) {
        new ActionFormData()
            .title("§l📐 FORMASYONLAR")
            .button("§l🛡️ SAVUNMA").button("§l⚔️ SALDIRI").button("§l➖ ÇİZGİ")
            .button("§l⬜ KARE").button("§l⭕ ÇEMBER").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 5) return this.askerMenusu(player);
                Formasyon.uygula(player, ["savunma", "saldiri", "cizgi", "kare", "cember"][r.selection]);
                this.askerMenusu(player);
            });
    },

    rankMenusu(player) {
        let b = `§l⭐ RANKLAR\n§8────────────────\n`;
        for (const r of Config.ASKER_RANKLARI) b += `${r.emoji} ${r.rank}: ${r.min} kill | Bonus: x${r.bonus}\n`;
        new ActionFormData().title("§l⭐ RANKLAR").body(b).button("§l❌ GERİ").show(player).then(() => this.askerMenusu(player));
    },

    askerGelistir(player) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return;
        const d = Core.Database.load();
        const entities = Core.Cache?.getKrallikEntities?.(kid)?.filter(e => Core.Cache?.isValidEntity?.(e)) || [];
        let b = `§l⬆️ ASKER GELİŞTİR\n§8────────────────\n§fMaksimum seviye: §e${Config.MAX_SOLDIER_LEVEL}\n\n`;
        const tipCounts = {};
        for (const e of entities) {
            const tip = AI._getSoldierType(e);
            const lvl = d.askerKayit?.[e.id]?.level || 1;
            if (!tipCounts[tip]) tipCounts[tip] = { count: 0, minLevel: 99 };
            tipCounts[tip].count++;
            tipCounts[tip].minLevel = Math.min(tipCounts[tip].minLevel, lvl);
        }
        for (const [tip, data] of Object.entries(tipCounts)) {
            const askerConfig = Config.ASKERLER[tip];
            b += `${askerConfig?.emoji || ""} ${askerConfig?.name || tip}: §a${data.count} §7(Min Lv: ${data.minLevel})\n`;
        }
        new ActionFormData().title("§l⬆️ ASKER GELİŞTİR").body(b).button("§l⬆️ GELİŞTİR").button("§l❌ GERİ")
            .show(player).then(r => { if (r.selection === 0) this.askerGelistirForm(player); else this.askerMenusu(player); });
    },

    askerGelistirForm(player) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return;
        new ModalFormData().title("§l⬆️ ASKER GELİŞTİR")
            .dropdown("§fAsker Türü:", Object.values(Config.ASKERLER).map(d => d.name), 0)
            .slider("§fMiktar:", 1, 50, 1, 1).show(player).then(r => {
                if (r.canceled) return this.askerMenusu(player);
                const askerKeys = Object.keys(Config.ASKERLER);
                const tip = askerKeys[r.formValues[0]];
                const miktar = r.formValues[1];
                const entities = (Core.Cache?.getKrallikEntities?.(kid) || []).filter(e => Core.Cache?.isValidEntity?.(e) && AI._getSoldierType(e) === tip).slice(0, miktar);
                let totalCost = 0;
                const d = Core.Database.load();
                const upgradeList = [];
                const askerConfig = Config.ASKERLER[tip];
                for (const e of entities) {
                    const currentLevel = d.askerKayit?.[e.id]?.level || 1;
                    if (currentLevel >= Config.MAX_SOLDIER_LEVEL) continue;
                    const cost = Math.floor(askerConfig.fiyat * Math.pow(Config.SOLDIER_LEVEL_COST_MULTIPLIER, currentLevel));
                    totalCost += cost;
                    upgradeList.push({ entity: e, cost, newLevel: currentLevel + 1 });
                }
                if ((d.kralliklar[kid]?.hazine || 0) < totalCost) {
                    Systems.sendMessage(player, `§cYetersiz hazine! Gereken: ${totalCost.toLocaleString()} ZMC`);
                    return this.askerMenusu(player);
                }
                d.kralliklar[kid].hazine -= totalCost;
                for (const up of upgradeList) {
                    if (!d.askerKayit) d.askerKayit = {};
                    if (!d.askerKayit[up.entity.id]) d.askerKayit[up.entity.id] = { kill: 0, krallik: kid, type: tip, level: 1 };
                    d.askerKayit[up.entity.id].level = up.newLevel;
                }
                Core.Database.markDirty("krallik_army");
                Core.Database.markDirty("krallik_core");
                Systems.sendMessage(player, `§a✔ ${upgradeList.length} asker geliştirildi! (${totalCost.toLocaleString()} ZMC)`);
                this.askerMenusu(player);
            });
    },

    devriyeAta(player) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return;
        const claims = ClaimManager.getKrallikClaims(kid);
        if (!claims.length) { Systems.sendMessage(player, "§cToprağın yok!"); return this.askerMenusu(player); }
        const form = new ActionFormData().title("§l🚶 DEVRİYE ATA").button("§l❌ GERİ");
        claims.forEach(c => form.button(`Claim (${c.x}, ${c.z}) Lv${c.level || 1}`));
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.askerMenusu(player);
            Devriye.devriyeAta(kid, claims[r.selection - 1].id);
            Systems.sendMessage(player, "§a✔ Devriye rotası oluşturuldu!");
            this.askerMenusu(player);
        });
    },


    claimMenusu(player) {
        ClaimManager.showMenu(player);
    },

    topraklarim(player) {
        ClaimManager.showMenu(player);
    },

    ekonomiMenusu(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.anaMenu(player);
        new ActionFormData().title("§l💰 EKONOMİ").body(`§fHazine: §a${(krallik.hazine || 0).toLocaleString()} ZMC\n§fGelir: §a${(krallik.gelir || 0).toLocaleString()} ZMC`)
            .button("§l💰 YATIR").button("§l💸 ÇEK").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 2) return this.anaMenu(player);
                if (r.selection === 0) {
                    new ModalFormData().title("§l💰 YATIR").textField("Miktar:", "100").show(player).then(r2 => {
                        if (r2.canceled) return this.ekonomiMenusu(player);
                        const m = parseInt(r2.formValues[0]);
                        if (!m || m < 1 || Systems.getZMC(player) < m) { Systems.sendMessage(player, "§cGeçersiz!"); return; }
                        Systems.removeZMC(player, m);
                        krallik.hazine = (krallik.hazine || 0) + m;
                        Core.Database.markDirty("krallik_core");
                        Systems.sendMessage(player, `§a✔ ${m.toLocaleString()} ZMC yatırıldı`);
                        this.ekonomiMenusu(player);
                    });
                }
                if (r.selection === 1) {
                    if (!Permission?.requirePermission?.(player, "economy.*")) return this.ekonomiMenusu(player);
                    new ModalFormData().title("§l💸 ÇEK").textField("Miktar:", "100").show(player).then(r2 => {
                        if (r2.canceled) return this.ekonomiMenusu(player);
                        const m = parseInt(r2.formValues[0]);
                        if (!m || m < 1 || (krallik.hazine || 0) < m) { Systems.sendMessage(player, "§cGeçersiz!"); return; }
                        krallik.hazine -= m;
                        Systems.addZMC(player, m);
                        Core.Database.markDirty("krallik_core");
                        Systems.sendMessage(player, `§a✔ ${m.toLocaleString()} ZMC çekildi`);
                        this.ekonomiMenusu(player);
                    });
                }
            });
    },

    savasMenusu(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return this.anaMenu(player);
        new ActionFormData().title("§l⚔️ SAVAŞ").body(`§fSavaş: §c${(krallik.savaslar || []).length}\n§fMüttefik: §a${(krallik.muttefikler || []).length}`)
            .button("§l⚔️ İLAN ET").button("§l🕊️ BARIŞ").button("§l🏰 KUŞATMA").button("§l📋 DURUM").button("§l❌ GERİ")
            .show(player).then(r => {
                if (r.canceled || r.selection === 4) return this.anaMenu(player);
                if (r.selection === 0) this.savasIlanEt(player);
                if (r.selection === 1) this.barisYap(player);
                if (r.selection === 2) this.kusatmaBaslat(player);
                if (r.selection === 3) this.savasDurumu(player);
            });
    },

    savasIlanEt(player) {
        if (!Permission?.requirePermission?.(player, "diplomacy.*")) return this.savasMenusu(player);
        const d = Core.Database.load();
        const kid = Systems.getPlayerKrallikId(player);
        const diger = Object.entries(d.kralliklar || {}).filter(([id]) => id !== kid && !Diplomacy.isAtWar(kid, id));
        if (!diger.length) { Systems.sendMessage(player, "§7Rakip yok."); return this.savasMenusu(player); }
        const form = new ActionFormData().title("§l⚔️ SAVAŞ İLANI").button("§l❌ GERİ");
        diger.forEach(([, k2]) => form.button(k2.isim));
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.savasMenusu(player);
            const hedefKid = diger[r.selection - 1][0];
            if (!Vassal.savasIzniVarMi(kid, hedefKid)) {
                Systems.sendMessage(player, "§cVasal olarak bağımsız savaş ilan edemezsin!");
                return this.savasMenusu(player);
            }
            Diplomacy.declareWar(kid, hedefKid);
            this.savasMenusu(player);
        });
    },

    barisYap(player) {
        const d = Core.Database.load();
        const kid = Systems.getPlayerKrallikId(player);
        const wars = [];
        for (const [key, w] of Object.entries(d.diplomacy?.wars || {})) {
            if (!w || w.endTime) continue;
            const [a, b] = key.split("|");
            if (a === kid) wars.push(b);
            else if (b === kid) wars.push(a);
        }
        if (!wars.length) { Systems.sendMessage(player, "§7Savaşta değilsin."); return this.savasMenusu(player); }
        const form = new ActionFormData().title("§l🕊️ BARIŞ").button("§l❌ GERİ");
        wars.forEach(s => { const k2 = d.kralliklar[s]; if (k2) form.button(k2.isim); });
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.savasMenusu(player);
            Diplomacy.makePeace(kid, wars[r.selection - 1]);
            this.savasMenusu(player);
        });
    },

    kusatmaBaslat(player) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return this.savasMenusu(player);
        const d = Core.Database.load();
        const enemyClaims = [];
        for (const [cid, claim] of Object.entries(d.claimler || {})) {
            if (claim.krallik === kid || !Diplomacy.isAtWar(kid, claim.krallik)) continue;
            const distSq = Core.Performance.distanceSq(player.location, { x: claim.x, z: claim.z });
            if (distSq < 10000) enemyClaims.push({ id: cid, dist: Math.sqrt(distSq) });
        }
        if (!enemyClaims.length) { Systems.sendMessage(player, "§7Yakında düşman toprağı yok."); return this.savasMenusu(player); }
        enemyClaims.sort((a, b) => a.dist - b.dist);
        const form = new ActionFormData().title("§l🏰 KUŞATMA").button("§l❌ GERİ");
        enemyClaims.forEach(c => { const k2 = d.kralliklar[d.claimler[c.id]?.krallik]; form.button(`${k2?.isim || "?"} (${Math.floor(c.dist)}m)`); });
        form.show(player).then(r => {
            if (r.canceled || r.selection === 0) return this.savasMenusu(player);
            Siege.start(kid, enemyClaims[r.selection - 1].id);
            this.savasMenusu(player);
        });
    },

    savasDurumu(player) {
        const d = Core.Database.load();
        const kid = Systems.getPlayerKrallikId(player);
        const wars = [];
        for (const [key, w] of Object.entries(d.diplomacy?.wars || {})) {
            if (!w || w.endTime) continue;
            const [a, b] = key.split("|");
            if (a === kid) wars.push(b);
            else if (b === kid) wars.push(a);
        }
        const allies = Diplomacy.getMutualAllies(kid);
        const form = new ActionFormData().title("§l📋 SAVAŞ DURUMU").body((wars.length ? "§7Savaştaki krallıklar:\n" : "§aŞu an savaş yok.\n") + (allies.length ? `\n§7Müttefikler: §a${allies.length}` : "\n§7Müttefik yok."));
        if (wars.length) wars.forEach(wid => { const k2 = d.kralliklar[wid]; if (k2) form.button(k2.isim); });
        form.button("§l⬅️ GERİ");
        form.show(player).then(() => this.savasMenusu(player));
    }
};