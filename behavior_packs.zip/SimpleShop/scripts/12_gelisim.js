// ============================================================
// MODÜL 12: GELİŞİM - Gelişim Ağacı, Permission ve İstatistikler (EKSİKSİZ)
// ============================================================
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager } from "./02_claim.js";
import { Systems, AI } from "./04_military.js";

// ============================================================
// GELİŞİM AĞACI
// ============================================================
export const GelisimAgaci = {
    seviyeAtla(kid, dal) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return false;
        const def = Config.GELISIM_AGACI[dal];
        if (!def) return false;
        const mevcut = k.gelisimAgaci?.[dal] || 0;
        if (mevcut >= def.maxLevel) return false;
        const maliyet = def.costs[mevcut] || 0;
        if ((k.hazine || 0) < maliyet) return false;
        k.hazine -= maliyet;
        if (!k.gelisimAgaci) k.gelisimAgaci = {};
        k.gelisimAgaci[dal] = mevcut + 1;
        
        // Anlık bonus uygulamaları
        if (dal === "askeri") {
            k.askerLimiti = Math.floor((k.askerLimiti || 70) * 1.05);
            // Mevcut askerlere bonus uygula
            const entities = Core.Cache?.getKrallikEntities?.(kid) || [];
            for (const e of entities) {
                const st = AI._soldierStates?.[e.id];
                if (st) st.aggression = Math.min(150, (st.aggression || 50) + 2);
            }
        }
        if (dal === "ekonomi") {
            k.gelir = Math.floor((k.gelir || 0) * 1.03);
            // Vergi indirimi
            k.vergiIndirim = Math.min(0.8, (k.vergiIndirim || 0) + 0.02);
        }
        if (dal === "savunma") {
            for (const claim of Core.Database.getClaimler(kid)) {
                claim.maxHealth = 100 + (claim.level || 1) * 50 + (mevcut + 1) * 10;
                if (claim.health) claim.health = Math.min(claim.maxHealth, claim.health + 10);
                Core.Database.markDirty("krallik_claims");
            }
        }
        if (dal === "diplomasi") {
            k.diplomaticPower = (k.diplomaticPower || 0) + 5;
            const bonusSlots = Math.floor((mevcut + 1) / 2);
            k.ekMuttefikSlot = bonusSlots;
        }
        
        Core.Database.markDirty("krallik_core");
        Core.LogSistemi?.log?.("gelisim", `${k.isim} ${dal} dalında seviye ${mevcut + 1} oldu`, { krallik: kid });
        return true;
    },

    getBonus(kid, dal) {
        const k = Core.Database.load().kralliklar[kid];
        if (!k) return 0;
        const seviye = k.gelisimAgaci?.[dal] || 0;
        const def = Config.GELISIM_AGACI[dal];
        if (!def) return 0;
        return seviye * (def.bonusPerLevel?.value || 0.05);
    },

    getDetailedBonus(kid, dal) {
        const k = Core.Database.load().kralliklar[kid];
        if (!k) return null;
        const seviye = k.gelisimAgaci?.[dal] || 0;
        const def = Config.GELISIM_AGACI[dal];
        if (!def) return null;
        
        const bonuses = {};
        for (const [key, value] of Object.entries(def.bonusPerLevel || {})) {
            bonuses[key] = seviye * value;
        }
        
        return {
            dal: dal,
            name: def.name,
            level: seviye,
            maxLevel: def.maxLevel,
            bonuses: bonuses,
            nextLevelCost: seviye < def.maxLevel ? def.costs[seviye] : null,
            isMax: seviye >= def.maxLevel
        };
    },

    getCostForNextLevel(kid, dal) {
        const k = Core.Database.load().kralliklar[kid];
        if (!k) return Infinity;
        const def = Config.GELISIM_AGACI[dal];
        if (!def) return Infinity;
        const mevcut = k.gelisimAgaci?.[dal] || 0;
        if (mevcut >= def.maxLevel) return Infinity;
        return def.costs[mevcut] || 0;
    },

    getAllBonuses(kid) {
        const k = Core.Database.load().kralliklar[kid];
        if (!k) return {};
        const bonuses = {};
        for (const [dal, def] of Object.entries(Config.GELISIM_AGACI)) {
            const seviye = k.gelisimAgaci?.[dal] || 0;
            bonuses[dal] = {
                level: seviye,
                maxLevel: def.maxLevel,
                name: def.name,
                emoji: def.emoji,
                bonuses: {}
            };
            for (const [bonusKey, bonusValue] of Object.entries(def.bonusPerLevel || {})) {
                bonuses[dal].bonuses[bonusKey] = (seviye * bonusValue * 100).toFixed(1) + "%";
            }
        }
        return bonuses;
    },

    formatGelisimDurumu(kid) {
        const k = Core.Database.load().kralliklar[kid];
        if (!k) return "§cKrallık bulunamadı!";
        
        let msg = `§l🌳 GELİŞİM DURUMU - ${k.isim}\n§8────────────────\n`;
        for (const [dal, def] of Object.entries(Config.GELISIM_AGACI)) {
            const seviye = k.gelisimAgaci?.[dal] || 0;
            const nextCost = this.getCostForNextLevel(kid, dal);
            const isMax = seviye >= def.maxLevel;
            msg += `\n${def.emoji || "📈"} §6${def.name} §7Lv.${seviye}/${def.maxLevel}\n`;
            msg += `  §7Bonus: `;
            const bonuses = [];
            for (const [bonusKey, bonusValue] of Object.entries(def.bonusPerLevel || {})) {
                bonuses.push(`${bonusKey} +${(seviye * bonusValue * 100).toFixed(0)}%`);
            }
            msg += (bonuses.length ? bonuses.join(", ") : "Yok") + "\n";
            if (!isMax) msg += `  §7Sonraki seviye: §e${nextCost.toLocaleString()} ZMC\n`;
            else msg += `  §a✓ MAKSİMUM SEVİYE\n`;
        }
        return msg;
    },

    // Tüm krallıkların gelişim seviyelerini karşılaştır
    getGlobalGelisimRanking(dal = "askeri", limit = 10) {
        const d = Core.Database.load();
        const rankings = [];
        for (const [kid, k] of Object.entries(d.kralliklar || {})) {
            const level = k.gelisimAgaci?.[dal] || 0;
            rankings.push({
                kid: kid,
                name: k.isim,
                level: level,
                maxLevel: Config.GELISIM_AGACI[dal]?.maxLevel || 10,
                progress: (level / (Config.GELISIM_AGACI[dal]?.maxLevel || 10)) * 100
            });
        }
        rankings.sort((a, b) => b.level - a.level);
        return rankings.slice(0, limit);
    }
};

// ============================================================
// PERMISSION - Yetki Sistemi
// ============================================================
export const Permission = {
    hasPermission(player, node) {
        if (Systems.isAdmin(player)) return true;
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return false;
        const rol = krallik.roller?.[player.name] || "uye";
        if (rol === "kral") return true;
        const rolDef = Config.ROLLER[rol];
        if (!rolDef) return false;
        for (const perm of rolDef.permissions) {
            if (perm === "*") return true;
            if (perm.endsWith(".*") && node.startsWith(perm.replace(".*", "."))) return true;
            if (perm === node) return true;
        }
        return false;
    },

    requirePermission(player, node) {
        if (!this.hasPermission(player, node)) {
            Systems.sendMessage(player, "§cBu işlem için yetkiniz yok!");
            return false;
        }
        return true;
    },

    getRolePermissions(rolId) {
        const rolDef = Config.ROLLER[rolId];
        if (!rolDef) return [];
        return rolDef.permissions;
    },

    getPlayerRole(player) {
        const krallik = Systems.getPlayerKrallik(player);
        if (!krallik) return null;
        return krallik.roller?.[player.name] || "uye";
    },

    getAllRoles() {
        return Object.entries(Config.ROLLER).map(([id, def]) => ({
            id: id,
            name: id,
            permissions: def.permissions,
            maxCount: def.maxCount,
            color: def.color,
            icon: def.icon
        }));
    },

    addRole(kid, roleId, roleData) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return false;
        Config.ROLLER[roleId] = {
            id: roleId,
            permissions: roleData.permissions || [],
            maxCount: roleData.maxCount || Infinity,
            color: roleData.color || "§7",
            icon: roleData.icon || "👤"
        };
        Core.Database.markDirty("krallik_core");
        Core.LogSistemi?.log?.("yonetim", `Yeni rol eklendi: ${roleId}`, { krallik: kid });
        return true;
    },

    removeRole(roleId) {
        if (roleId === "kral" || roleId === "uye") return false;
        if (Config.ROLLER[roleId]) {
            delete Config.ROLLER[roleId];
            Core.Database.markDirty("krallik_core");
            return true;
        }
        return false;
    },

    updateRolePermissions(roleId, permissions) {
        if (!Config.ROLLER[roleId]) return false;
        Config.ROLLER[roleId].permissions = permissions;
        Core.Database.markDirty("krallik_core");
        return true;
    },

    assignRole(kid, playerName, roleId) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return false;
        const rolDef = Config.ROLLER[roleId];
        if (!rolDef) return false;
        
        const currentCount = Object.values(k.roller || {}).filter(r => r === roleId).length;
        if (currentCount >= rolDef.maxCount && roleId !== "kral") return false;
        
        k.roller[playerName] = roleId;
        Core.Database.markDirty("krallik_core");
        Core.LogSistemi?.log?.("yonetim", `${playerName} → ${roleId} rolü atandı`, { krallik: kid });
        return true;
    },

    removeRoleFromPlayer(kid, playerName) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return false;
        if (k.roller?.[playerName] === "kral") return false;
        if (k.roller?.[playerName]) {
            delete k.roller[playerName];
            k.roller[playerName] = "uye";
            Core.Database.markDirty("krallik_core");
            return true;
        }
        return false;
    },

    getPlayersWithRole(kid, roleId) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return [];
        const players = [];
        for (const [name, role] of Object.entries(k.roller || {})) {
            if (role === roleId) players.push(name);
        }
        return players;
    }
};

// ============================================================
// KRALLIK İSTATİSTİKLERİ
// ============================================================
export const KrallikIstatistik = {
    getStats(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return null;
        
        const claims = Core.Database.getClaimler(kid);
        const askerler = Core.Cache?.getKrallikEntities?.(kid) || [];
        const askerTipleri = {};
        let totalAskerLevel = 0;
        let maxAskerLevel = 0;
        
        for (const a of askerler) {
            const tip = AI._getSoldierType?.(a) || "bilinmiyor";
            askerTipleri[tip] = (askerTipleri[tip] || 0) + 1;
            const level = d.askerKayit?.[a.id]?.level || 1;
            totalAskerLevel += level;
            if (level > maxAskerLevel) maxAskerLevel = level;
        }
        
        const toplamHasar = d.combatLogs?.filter(l => l.attackerKid === kid).reduce((sum, l) => sum + (l.totalDamage || 0), 0) || 0;
        const toplamOlum = d.combatLogs?.filter(l => l.victimKid === kid).length || 0;
        
        // Aktiflik skoru (son 7 gün)
        let activityScore = 0;
        const oneWeekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
        const recentLogs = (d.logs || []).filter(l => l.actor === kid && l.timestamp > oneWeekAgo);
        activityScore = recentLogs.length;
        
        return {
            isim: k.isim,
            lider: k.lider,
            seviye: k.seviye || 1,
            moral: k.moral || 60,
            hazine: k.hazine || 0,
            gelir: k.gelir || 0,
            totalPower: k.totalPower || 0,
            claimSayisi: claims.length,
            askerSayisi: askerler.length,
            askerTipleri: askerTipleri,
            ortalamaAskerSeviye: askerler.length ? (totalAskerLevel / askerler.length).toFixed(1) : 0,
            maxAskerSeviye: maxAskerLevel,
            savasSayisi: (k.savaslar || []).length,
            muttefikSayisi: (k.muttefikler || []).length,
            toplamKill: k.toplamKill || 0,
            warScore: k.warScore || 0,
            zaferSayisi: k.zaferCount || 0,
            maglubiyetSayisi: k.maglubiyetCount || 0,
            kusatmaSayisi: k.kusatmaCount || 0,
            toplamHasar: toplamHasar,
            toplamOlum: toplamOlum,
            kurulusTarihi: k.createdAt || "Bilinmiyor",
            sonAktivite: k.lastActive || "Bilinmiyor",
            activityScore: activityScore,
            gelisimAgaci: k.gelisimAgaci || { askeri: 0, ekonomi: 0, savunma: 0, diplomasi: 0 },
            diplomaticPower: k.diplomaticPower || 0,
            reputation: k.reputation || 50
        };
    },
    
    getActivityRanking(limit = 10) {
        const d = Core.Database.load();
        const activities = [];
        for (const [kid, k] of Object.entries(d.kralliklar || {})) {
            const claims = Core.Database.getClaimler(kid).length;
            const askerler = Core.Cache?.getKrallikEntities?.(kid) || [];
            const score = (k.warScore || 0) + (k.toplamKill || 0) + claims * 10 + askerler.length * 2;
            const dailyActivity = (k.gelir || 0) / 100 + (k.savaslar || []).length * 5;
            activities.push({
                id: kid,
                name: k.isim,
                score: score,
                dailyActivity: dailyActivity,
                warScore: k.warScore || 0,
                kills: k.toplamKill || 0,
                claims: claims,
                askers: askerler.length,
                level: k.seviye || 1
            });
        }
        activities.sort((a, b) => b.score - a.score);
        return activities.slice(0, limit);
    },

    getCombatStats(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return null;
        
        const recentWins = (d.savasRaporlari || []).filter(r => r.attackerKid === kid && r.sonuc === "zafer" && Date.now() - r.timestamp < 7 * 24 * 60 * 60 * 1000).length;
        const recentLosses = (d.savasRaporlari || []).filter(r => r.attackerKid === kid && r.sonuc === "yenilgi" && Date.now() - r.timestamp < 7 * 24 * 60 * 60 * 1000).length;
        
        return {
            totalWars: (k.savaslar || []).length,
            totalSieges: k.kusatmaCount || 0,
            victories: k.zaferCount || 0,
            defeats: k.maglubiyetCount || 0,
            killDeathRatio: k.toplamKill && toplamOlum ? (k.toplamKill / toplamOlum).toFixed(2) : k.toplamKill || 0,
            recentWins: recentWins,
            recentLosses: recentLosses,
            winRate: (k.zaferCount + k.maglubiyetCount) ? ((k.zaferCount / (k.zaferCount + k.maglubiyetCount)) * 100).toFixed(1) + "%" : "0%"
        };
    },

    getEconomyStats(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return null;
        
        const gelirKaynaklari = {
            vergi: (k.vergiGeliri || 0),
            ticaret: (k.ticaretGeliri || 0),
            claim: (Core.Database.getClaimler(kid).length * 30),
            asker: (Core.Cache?.getKrallikEntityCount?.(kid) || 0) * 5,
            diger: Math.max(0, (k.gelir || 0) - ((Core.Database.getClaimler(kid).length * 30) + (Core.Cache?.getKrallikEntityCount?.(kid) || 0) * 5))
        };
        
        const giderler = {
            bakim: (k.bakimGideri || 0),
            maas: (k.maasGideri || 0),
            claimBakim: (k.claimBakimGideri || 0),
            diger: Math.max(0, (k.gelir || 0) - (k.hazineDegisim || 0) - (k.gelir || 0))
        };
        
        return {
            hazine: k.hazine || 0,
            gelir: k.gelir || 0,
            netGelir: (k.gelir || 0) - (k.bakimGideri || 0) - (k.maasGideri || 0) - (k.claimBakimGideri || 0),
            gelirKaynaklari: gelirKaynaklari,
            giderler: giderler,
            marketSales: k.marketSales || 0,
            taxRate: k.VERGI_ORAN || Config.VERGI_ORAN,
            hazineDegisim: k.hazineDegisim || 0
        };
    }
};