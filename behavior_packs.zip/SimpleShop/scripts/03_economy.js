// ============================================================
// MODÜL 03: EKONOMİ - Gelir, Market, Ticaret Yolu (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager } from "./02_claim.js";

export const Economy = {
    tick() {
        const d = Core.Database.load();
        for (const [id, k] of Object.entries(d.kralliklar || {})) {
            const claims = ClaimManager.getKrallikClaims(id).length;
            const asker = Core.Cache?.getKrallikEntityCount?.(id) || 0;

            let gelir = claims * 30 + asker * 5;

            if (d.treaties?.[id]) {
                for (const [, treaty] of Object.entries(d.treaties[id])) {
                    if (treaty?.type === "trade") gelir += 5;
                }
            }

            try {
                for (const [key, agreement] of Object.entries(d.diplomacy?.tradeAgreements || {})) {
                    const [kA, kB] = key.split("|");
                    if ((kA === id || kB === id) && agreement) {
                        const partnerId = kA === id ? kB : kA;
                        const alreadyCounted = d.treaties?.[id]?.[partnerId];
                        if (!alreadyCounted) gelir += 5;
                    }
                }
            } catch(e) {}

            if (k.harac) {
                for (const [, amount] of Object.entries(k.harac)) gelir += amount;
            }

            const ekonomiGelisim = k.gelisimAgaci?.ekonomi || 0;
            const gelisimConfig = Config.GELISIM_AGACI["ekonomi"];
            if (gelisimConfig) gelir *= (1 + ekonomiGelisim * (gelisimConfig.bonusPerLevel.gelir || 0.05));

            const events = d.krallikEventleri?.[id] || {};
            if (events.ekonomikKriz?.active) gelir *= (events.ekonomikKriz.gelirMultiplier || 0.5);

            try {
                const evEffect = Core.EventManager?.getActiveEffect?.(id);
                if (evEffect?.gelirMultiplier && evEffect.gelirMultiplier !== 1) gelir *= evEffect.gelirMultiplier;
            } catch(e) {}

            let bakim = 0;
            const entities = Core.Cache?.getKrallikEntities?.(id) || [];
            for (const e of entities) {
                const tip = Core.AI?._getSoldierType?.(e) || "soldier";
                const askerConfig = Config.ASKERLER[tip];
                let b = askerConfig?.bakim || 10;
                const level = d.askerKayit?.[e.id]?.level || 1;
                b *= (1 + (level - 1) * 0.3);
                if (k.status === "savas" || k.status === "kusatma") b *= 1.5;
                bakim += b;
            }

            k.gelir = Math.floor(gelir);
            k.hazine = (k.hazine || 0) + gelir - bakim;

            for (const u of k.uyeler || []) {
                const oyuncu = world.getAllPlayers().find(pl => pl.name === u);
                if (oyuncu) {
                    const vergiAzaltma = (k.gelisimAgaci?.ekonomi || 0) * 0.02;
                    const efektifVergiYuzde = Math.max(1, Config.VERGI_ORAN - vergiAzaltma * 100);
                    const zmc = Core.Systems?.getZMC?.(oyuncu) || 0;
                    const v = Math.floor(zmc * efektifVergiYuzde / 100);
                    if (v > 0) {
                        Core.Systems?.removeZMC?.(oyuncu, Math.min(v, zmc));
                        k.hazine += Math.min(v, zmc);
                    }
                }
            }

            for (const claim of ClaimManager.getKrallikClaims(id)) {
                const lvl = Math.min(Math.max((claim.level || 1) - 1, 0), 4);
                const maint = (ClaimManager.CONFIG?.MAINTENANCE_PER_LEVEL?.[lvl]) ?? (Config.CLAIM_MAINTENANCE_PER_LEVEL?.[lvl]) ?? 10;
                const interval = (ClaimManager.CONFIG?.MAINTENANCE_INTERVAL) ?? Config.CLAIM_MAINTENANCE_INTERVAL ?? 72000;
                k.hazine -= maint / (interval / (Config.GELIR_ARALIK * 20) || 1);
                if (claim.shield > 0 && d.claimler?.[claim.id]) {
                    d.claimler[claim.id].shield = Math.max(0, claim.shield - 1);
                }
            }

            k.hazine = Math.max(-5000, k.hazine || 0);

            try { Core.Vassal?.haracTick?.(); } catch(e) {}
            try { Core.TradeRoute?.tick?.(); } catch(e) {}
            try {
                Core.Leaderboard?.recordKingdomStat?.(id, "gelir", k.gelir || 0);
                Core.Leaderboard?.recordKingdomStat?.(id, "marketSales", k.marketSales || 0);
            } catch(e) {}
        }
        Core.Database.markDirty("krallik_core");
    }
};

export const Market = {
    getPrice(itemId, krallikId) {
        const item = Config.MARKET_ITEMS[itemId];
        if (!item) return 0;

        let price = item.basePrice;
        const d = Core.Database.load();

        if (d.borsa && d.borsa[itemId]) {
            price = d.borsa[itemId];
        }

        const k = d.kralliklar?.[krallikId];
        const isAtWar = (k?.status === "savas" || k?.status === "kusatma") ||
            (typeof Core.Diplomacy?.isAtWar === "function" && Object.keys(d.kralliklar || {}).some(tid => tid !== krallikId && Core.Diplomacy?.isAtWar?.(krallikId, tid)));
        if (k && isAtWar) {
            price *= item.warMultiplier || 1.5;
        }

        const events = d.krallikEventleri?.[krallikId] || {};
        if (events.kitlik?.active) price *= (events.kitlik.marketPriceMultiplier || 1.5);
        if (events.indirim?.active) price *= (events.indirim.marketDiscount || 0.7);

        return Math.max(1, Math.floor(price));
    },

    buyItem(player, itemId, quantity = 1) {
        const kid = Core.Database.getOyuncuKrallikId(player.name);
        if (!kid) { Core.Systems?.sendMessage?.(player, "§cKrallığınız yok!"); return; }

        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        const item = Config.MARKET_ITEMS[itemId];
        if (!item) return;

        if (!d.marketStock) d.marketStock = {};
        if (!d.marketStock[kid]) d.marketStock[kid] = {};
        const currentStock = d.marketStock[kid][itemId] ?? item.stockLimit;
        if (currentStock < quantity) {
            Core.Systems?.sendMessage?.(player, `§cYetersiz stok! Mevcut: ${currentStock}`);
            return;
        }

        const price = this.getPrice(itemId, kid) * quantity;
        if ((k?.hazine || 0) < price) {
            Core.Systems?.sendMessage?.(player, "§cHazine yetersiz!");
            return;
        }

        k.hazine -= price;
        k.marketSales = (k.marketSales || 0) + quantity;
        d.marketStock[kid][itemId] = currentStock - quantity;

        if (!d.marketHistory) d.marketHistory = {};
        if (!d.marketHistory[kid]) d.marketHistory[kid] = [];
        d.marketHistory[kid].unshift({
            timestamp: Date.now(),
            player: player.name,
            itemId,
            itemName: item.name,
            quantity,
            price: this.getPrice(itemId, kid),
            totalPrice: price
        });
        if (d.marketHistory[kid].length > 100) d.marketHistory[kid].length = 100;

        Core.LogSistemi?.log?.("market", `${player.name} ${quantity}x ${item.name} satın aldı`, { price, krallik: kid });
        Core.Systems?.sendMessage?.(player, `§a✔ ${quantity}x ${item.emoji || ""} ${item.name} satın alındı (${price.toLocaleString()} ZMC)`);
        Core.Database.markDirty("krallik_core");
        Core.Database.markDirty("krallik_market");
        Core.Database.markDirty("krallik_economy");
    },

    getMarketHistory(kid, limit = 20) {
        const d = Core.Database.load();
        return (d.marketHistory?.[kid] || []).slice(0, limit);
    },

    addItem(itemId, itemData) {
        const validation = Core.DataRegistry?.validate?.(itemData, "marketItem");
        if (validation && !validation.valid) return { success: false, error: validation.error };
        Config.MARKET_ITEMS[itemId] = { id: itemId, ...itemData };
        Core.LogSistemi?.log?.("market", `Yeni market itemi eklendi: ${itemData.name}`);
        return { success: true };
    },

    removeItem(itemId) {
        if (Config.MARKET_ITEMS[itemId]) {
            delete Config.MARKET_ITEMS[itemId];
            Core.LogSistemi?.log?.("market", `Market itemi silindi: ${itemId}`);
            return { success: true };
        }
        return { success: false, error: "Item bulunamadı" };
    },

    updateItem(itemId, updates) {
        if (Config.MARKET_ITEMS[itemId]) {
            Object.assign(Config.MARKET_ITEMS[itemId], updates);
            Core.LogSistemi?.log?.("market", `Market itemi güncellendi: ${itemId}`);
            return { success: true };
        }
        return { success: false, error: "Item bulunamadı" };
    }
};

export const TradeRoute = {
    TICK_INTERVAL: 3600,
    BASE_GELIR: 10,
    SOYGUN_ESIGI: 30,
    UPGRADE_MALIYET: 1000,

    _data() {
        const d = Core.Database.load();
        if (!d.ticaretYollari) d.ticaretYollari = {};
        return d.ticaretYollari;
    },

    createRoute(kid, claimIdA, claimIdB) {
        const d = Core.Database.load();
        const cA = d.claimler?.[claimIdA], cB = d.claimler?.[claimIdB];
        if (!cA || !cB) return { ok: false, msg: "Claim bulunamadı." };
        if (cA.krallik !== kid || cB.krallik !== kid) return { ok: false, msg: "Her iki claim de senin krallığına ait olmalı." };
        const routes = this._data();
        const id = `tr_${kid}_${Date.now()}`;
        routes[id] = { id, kid, claimIdA, claimIdB, guvenlik: 50, aktif: true, olusturulma: Date.now(), toplamGelir: 0 };
        Core.Database.markDirty("krallik_economy");
        return { ok: true, msg: "Ticaret yolu kuruldu!", routeId: id };
    },

    getRoutes(kid) {
        return Object.values(this._data()).filter(r => r.kid === kid);
    },

    upgradeSecurity(kid, routeId, amount = 1) {
        const d = Core.Database.load();
        const route = this._data()[routeId];
        if (!route || route.kid !== kid) return { ok: false, msg: "Rota bulunamadı." };
        const k = d.kralliklar?.[kid];
        const maliyet = this.UPGRADE_MALIYET * amount;
        if (!k || (k.hazine || 0) < maliyet) return { ok: false, msg: `Yetersiz hazine. Gerekli: ${maliyet} ZMC` };
        k.hazine -= maliyet;
        route.guvenlik = Math.min(100, (route.guvenlik || 50) + amount * 5);
        Core.Database.markDirty("krallik_economy");
        return { ok: true, msg: `Güvenlik ${route.guvenlik}'e yükseltildi.` };
    },

    deleteRoute(kid, routeId) {
        const routes = this._data();
        if (!routes[routeId] || routes[routeId].kid !== kid) return false;
        delete routes[routeId];
        Core.Database.markDirty("krallik_economy");
        return true;
    },

    tick() {
        const routes = this._data();
        const d = Core.Database.load();
        let dirty = false;
        const now = Date.now();
        for (const [id, route] of Object.entries(routes)) {
            if (!route.aktif) continue;
            if ((now - (route.sonTick || 0)) < this.TICK_INTERVAL * 50) continue;
            route.sonTick = now;
            const cA = d.claimler?.[route.claimIdA];
            const cB = d.claimler?.[route.claimIdB];
            if (!cA || !cB) { delete routes[id]; dirty = true; continue; }
            const k = d.kralliklar?.[route.kid];
            if (!k) { delete routes[id]; dirty = true; continue; }
            if ((route.guvenlik || 50) < this.SOYGUN_ESIGI && Math.random() < 0.3) {
                Core.KrallikBildirim?.gonder?.(route.kid, `§c🗡️ Ticaret yolu soyuldu! (Güvenlik: ${route.guvenlik})`);
                dirty = true;
                continue;
            }
            const ortSeviye = ((cA.level || 1) + (cB.level || 1)) / 2;
            const gelir = Math.floor(this.BASE_GELIR * (route.guvenlik / 100) * ortSeviye);
            k.hazine = (k.hazine || 0) + gelir;
            route.toplamGelir = (route.toplamGelir || 0) + gelir;
            dirty = true;
        }
        if (dirty) Core.Database.markDirty("krallik_economy");
    }
};

export const EkonomiEk = {
    enflasyonKatsayi() {
        const d = Core.Database.load();
        let total = 0;
        for (const k of Object.values(d.kralliklar || {})) total += (k.hazine || 0);
        if (total < 50000) return 1.0;
        if (total < 250000) return 1.1;
        if (total < 1000000) return 1.25;
        return 1.5;
    },

    krediCek(kid, miktar, faizOran = 0.05, vadeGun = 7) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return null;
        k.krediler = k.krediler || [];
        const kredi = { id: "cr_" + Date.now(), miktar, faizOran, vade: Date.now() + vadeGun * 86400000, odendi: 0 };
        k.krediler.push(kredi);
        k.hazine = (k.hazine || 0) + miktar;
        Core.Database.markDirty("krallik_core");
        return kredi.id;
    },

    krediOde(kid, krediId, miktar) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k?.krediler) return false;
        const cr = k.krediler.find(x => x.id === krediId);
        if (!cr) return false;
        const m = Math.max(0, miktar || 0);
        if ((k.hazine || 0) < m) return false;
        k.hazine -= m;
        cr.odendi = (cr.odendi || 0) + m;
        Core.Database.markDirty("krallik_core");
        return true;
    },

    borsaTick() {
        const d = Core.Database.load();
        d.borsa = d.borsa || {};
        const enflasyon = this.enflasyonKatsayi();
        for (const [itemId, item] of Object.entries(Config.MARKET_ITEMS || {})) {
            const basePrice = item.basePrice;
            const vol = 0.08;
            const rnd = (Math.random() * 2 - 1) * vol;
            let newPrice = basePrice * (1 + rnd) * enflasyon;
            newPrice = Math.max(basePrice * 0.5, Math.min(basePrice * 3, newPrice));
            d.borsa[itemId] = Math.max(1, Math.floor(newPrice));
        }
        Core.Database.markDirty("krallik_economy");
    },

    sirketKur(kid, isim) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return false;
        k.sirketler = k.sirketler || [];
        k.sirketler.push({ id: "co_" + Date.now(), isim, t: Date.now(), seviye: 1 });
        Core.Database.markDirty("krallik_core");
        return true;
    },

    uretimBinasiEkle(claimId, tip, seviye = 1) {
        const d = Core.Database.load();
        const c = d.claimler?.[claimId];
        if (!c) return false;
        c.uretim = c.uretim || [];
        c.uretim.push({ tip, seviye, t: Date.now() });
        Core.Database.markDirty("krallik_claims");
        return true;
    },

    ticaretIslemi(kidA, kidB, itemId, miktar, tip) {
        const d = Core.Database.load();
        d.tradeHistory = d.tradeHistory || [];
        d.tradeHistory.unshift({ t: Date.now(), a: kidA, b: kidB, itemId, miktar, tip });
        if (d.tradeHistory.length > 200) d.tradeHistory.length = 200;
        Core.Database.markDirty("krallik_economy");
        return true;
    },

    gumrukVergisiHesapla(kidA, kidB, tutar) {
        const d = Core.Database.load();
        const oran = d.adminAyarlari?.gumrukOran ?? 0.05;
        const amb = d.ambargolar?.[kidA + "->" + kidB]?.aktif;
        return Math.floor(tutar * (amb ? oran * 3 : oran));
    },

    askerMaasiOde(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return false;
        const askerCount = Core.Cache?.getKrallikEntityCount?.(kid) || 0;
        const tutar = askerCount * (Config.ASKER_MAAS || 50);
        k.hazine = (k.hazine || 0) - tutar;
        Core.Database.markDirty("krallik_core");
        Core.LogSistemi?.log?.("ekonomi", `Asker maaşı ödendi: -${tutar} (asker:${askerCount})`, { target: kid });
        return tutar;
    },

    butceAyarla(kid, gelirHedef, giderLimit, notlar = "") {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        k.butce = { gelirHedef: gelirHedef || 0, giderLimit: giderLimit || 0, notlar };
        Core.Database.markDirty("krallik_core");
        return true;
    },

    krizKontrol(kid) {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return;
        if ((k.hazine || 0) < -5000) {
            k.ekonomikKriz = { t: Date.now(), durum: "borc", onlem: "vergi_artir" };
            k.VERGI_ORAN = (k.VERGI_ORAN || Config.VERGI_ORAN) + 2;
            Core.Database.markDirty("krallik_core");
        }
    }
};