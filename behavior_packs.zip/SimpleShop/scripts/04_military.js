// ============================================================
// MODÜL 04: ASKERİ - Systems, AI, Combat, Morale, Siege, Formasyon, Devriye (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager } from "./02_claim.js";

export const Systems = {
    _getZmcObjective() {
        // Önce Patch'in objective'i hazırladığından emin ol
        try { globalThis.Krallik?.Patch?.init?.(); } catch (_) {}
        return world.scoreboard.getObjective("zmc") || null;
    },

    getZMC(player) {
        try {
            const obj = this._getZmcObjective();
            if (!obj) return 0;
            return obj.getScore(player.scoreboardIdentity) ?? 0;
        } catch(e) { return 0; }
    },

    addZMC(player, amount) {
        try {
            const obj = this._getZmcObjective();
            if (!obj) return false;
            const cur = obj.getScore(player.scoreboardIdentity) ?? 0;
            obj.setScore(player.scoreboardIdentity, cur + amount);
            return true;
        } catch(e) { return false; }
    },

    removeZMC(player, amount) {
        try {
            const obj = this._getZmcObjective();
            if (!obj) return false;
            const cur = obj.getScore(player.scoreboardIdentity) ?? 0;
            obj.setScore(player.scoreboardIdentity, Math.max(0, cur - amount));
            return true;
        } catch(e) { return false; }
    },

    setZMC(player, amount) {
        try {
            const obj = this._getZmcObjective();
            if (!obj) return false;
            obj.setScore(player.scoreboardIdentity, Math.max(0, amount));
            return true;
        } catch(e) { return false; }
    },

    runCommand(entity, cmd) {
        try { entity?.runCommandAsync(cmd); } catch(e) {}
    },

    distanceSq(loc1, loc2) { return Core.Performance.distanceSq(loc1, loc2); },
    distance(loc1, loc2) { return Math.sqrt(Core.Performance.distanceSq(loc1, loc2)); },

    getPlayerKrallik(player) {
        const d = Core.Database.load();
        const kid = d.oyuncular[player?.name];
        return kid ? d.kralliklar[kid] : null;
    },

    getPlayerKrallikId(player) { return Core.Database.load().oyuncular[player?.name] || null; },

    getSeviyeBilgisi(seviye) {
        return Config.SEVIYE_GEREKLERI[Math.min((seviye || 1) - 1, Config.SEVIYE_GEREKLERI.length - 1)];
    },

    getAskerRank(kill) {
        let r = Config.ASKER_RANKLARI[0];
        for (const x of Config.ASKER_RANKLARI) { if (kill >= x.min) r = x; else break; }
        return r;
    },

    getAskerConfig(askerId) { return Config.ASKERLER[askerId] || null; },
    getUlkeConfig(ulkeId) { return Config.ULKELER[ulkeId] || null; },
    getMarketItem(itemId) { return Config.MARKET_ITEMS[itemId] || null; },
    getGelisimConfig(dalId) { return Config.GELISIM_AGACI[dalId] || null; },

    addTag(entity, tag) { try { entity?.isValid?.() && entity.addTag(tag); } catch(e) {} },
    removeTag(entity, tag) { try { entity?.isValid?.() && entity.removeTag(tag); } catch(e) {} },

    moveEntity(entity, targetLoc, speed = 1.0) {
        try {
            if (!entity?.isValid?.() || !targetLoc) return false;
            const nav = entity.navigation;
            if (nav && typeof nav.moveToLocation === "function") {
                const ty = (typeof targetLoc.y === "number") ? targetLoc.y : entity.location.y;
                nav.moveToLocation({ x: targetLoc.x, y: ty, z: targetLoc.z }, speed);
                return true;
            }
        } catch(e) {}
        // FALLBACK YOK - TELEPORT YOK - SADECE YÜRÜME
        return false;
    },

    teleport(entity, x, y, z, facingLoc = null) { return false; },

    sendMessage(player, msg) { try { player?.sendMessage(msg); } catch(e) {} },

    broadcastToKrallik(kid, msg) {
        if (!kid) {
            for (const player of world.getAllPlayers()) { this.sendMessage(player, msg); }
            return;
        }
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (k) {
            for (const u of k.uyeler || []) {
                const p = world.getAllPlayers().find(pl => pl.name === u);
                if (p) this.sendMessage(p, msg);
            }
        }
    },

    showActionBar(player, msg) { try { player?.onScreenDisplay?.setActionBar(msg); } catch(e) {} },

    isAdmin(player) {
        try {
            if (!player) return false;
            if (player.getTags?.().includes("admin")) return true;
            if (player.isOp?.()) return true;
            return false;
        } catch(e) { return false; }
    }
};

export const AI = {
    _soldierStates: {},
    _groupDecisions: {},

    initSoldier(entity, krallikId) {
        const state = {
            id: entity.id, krallikId,
            currentTarget: null, combatState: "idle",
            lastAttack: 0, lastSeenEnemy: null,
            aiCooldown: 0, morale: 60, aggression: 50,
            formationSlot: null, commander: null,
            targetMemory: null, targetMemoryExpiry: 0,
            patrolPoint: null, patrolIndex: 0,
            reloadCooldown: 0, isReloading: false,
            siperPosition: null, wave: 0, retreatCooldown: 0,
            holdPoint: null,
            formationOffsetX: null,
            formationOffsetZ: null,
            formationTip: null,
            markedTargetId: null
        };
        this._soldierStates[entity.id] = state;
        return state;
    },

    _getSoldierType(entity) {
        try {
            const tags = entity.getTags?.() || [];
            for (const tip of Object.keys(Config.ASKERLER)) {
                if (tags.includes(`asker_${tip}`)) return tip;
            }
            return "soldier";
        } catch(e) { return "soldier"; }
    },

    _getSoldierConfig(tip) { return Config.ASKERLER[tip] || Config.ASKERLER.soldier; },

    tickAll() {
        const allKrallikEntities = [];
        for (const kid of Object.keys(Core.Cache?._krallikEntityMap || {})) {
            for (const e of Core.Cache?.getKrallikEntities?.(kid) || []) {
                allKrallikEntities.push(e);
            }
        }
        const entities = allKrallikEntities.length > 0 ? allKrallikEntities : Core.Cache?.getEntities?.() || [];
        const tickCount = Core.Scheduler?._tickCount || 0;
        const players = world.getAllPlayers();
        const playerLocations = players.map(p => p.location).filter(Boolean);
        let processed = 0;

        const playerCount = players.length;
        const maxPerTick = playerCount <= 0 ? 0 :
                           playerCount <= 5 ? 20 :
                           playerCount <= 10 ? 30 :
                           playerCount <= 20 ? 45 : 60;
        if (maxPerTick === 0) return;

        this._updateGroupDecisions();

        for (const entity of entities) {
            if (!Core.Cache?.isValidEntity?.(entity)) continue;
            const krallikId = Core.Cache?.getEntityKrallikId?.(entity);
            if (!krallikId) continue;
            const tags = entity.getTags?.() || [];
            if (!tags.some(t => t.startsWith("asker_"))) continue;

            const entityMod = entity.id?.length > 4 ? parseInt(entity.id.slice(-2), 16) || 0 : 0;
            if ((tickCount + entityMod) % Config.AI_TICK_SPREAD !== 0) continue;

            let nearPlayer = false;
            for (const pLoc of playerLocations) {
                if (Core.Performance.distanceSq(entity.location, pLoc) <= Config.AI_SLEEP_DISTANCE * Config.AI_SLEEP_DISTANCE) {
                    nearPlayer = true; break;
                }
            }
            if (!nearPlayer) continue;
            if (processed >= maxPerTick) break;

            let state = this._soldierStates[entity.id];
            if (!state) state = this.initSoldier(entity, krallikId);

            this._processSoldier(entity, state);
            processed++;
        }

        const validIds = new Set(entities.filter(e => e?.isValid?.()).map(e => e.id));
        for (const id of Object.keys(this._soldierStates)) {
            if (!validIds.has(id)) {
                this._clearMark(this._soldierStates[id]);
                delete this._soldierStates[id];
            }
        }
    },

    _updateGroupDecisions() {
        this._groupDecisions = {};
        const d = Core.Database.load();
        for (const [kid, entities] of Object.entries(Core.Cache?._krallikEntityMap || {})) {
            const k = d.kralliklar[kid];
            if (!k) continue;
            const soldiers = entities.filter(e => Core.Cache?.isValidEntity?.(e));
            if (soldiers.length < 3) continue;

            let cx = 0, cz = 0;
            for (const s of soldiers) { cx += s.location.x; cz += s.location.z; }
            cx /= soldiers.length; cz /= soldiers.length;

            this._groupDecisions[kid] = {
                center: { x: cx, z: cz },
                count: soldiers.length,
                status: k.status || "baris",
                moral: k.moral || 60,
                intikamModu: k.intikamModu || false
            };
        }
    },

    _processSoldier(entity, state) {
        if (!entity?.isValid?.() || !entity.location) return;
        if (state.aiCooldown > 0) { state.aiCooldown--; return; }
        if (state.retreatCooldown > 0) { state.retreatCooldown--; }

        const tags = entity.getTags?.() || [];
        const d = Core.Database.load();
        const krallik = d.kralliklar[state.krallikId];
        if (!krallik) return;

        state.morale = krallik.moral || 60;
        state.aggression = krallik.status === "savas" || krallik.status === "kusatma" ? 100 :
                          krallik.status === "alarm" ? 75 : krallik.intikamModu ? 120 : 50;

        if (state.isReloading) {
            state.reloadCooldown--;
            if (state.reloadCooldown <= 0) state.isReloading = false;
        }

        const kralOnline = world.getAllPlayers().some(p => p.name === krallik.lider);
        if (!kralOnline && !tags.includes("savun") && !tags.includes("geri_cekil")) {
            Systems.addTag(entity, "savun");
        }

        if (tags.includes("krali_koru")) { this._behaviorGuard(entity, state); return; }
        if (tags.includes("mevzi_kur")) { this._behaviorHold(entity, state); return; }
        if (tags.includes("savun") || tags.includes("bayragi_savun")) { this._behaviorDefend(entity, state); return; }
        if (tags.includes("geri_cekil")) { this._behaviorRetreat(entity, state); return; }
        if (tags.includes("acil_toplan")) { this._behaviorRally(entity, state); return; }
        if (tags.includes("kolacan") || tags.includes("devriye")) { this._behaviorPatrol(entity, state); return; }
        if (tags.includes("saldir")) { this._behaviorAggressive(entity, state); return; }
        if (tags.includes("serbest")) { }

        if (state.morale < Config.AI_MORALE_RETREAT) { this._behaviorRetreat(entity, state); return; }

        try {
            const hp = entity.getComponent("health")?.currentValue;
            const maxHp = entity.getComponent("health")?.defaultValue;
            if (hp !== undefined && maxHp && hp / maxHp < Config.AI_RETREAT_HP) {
                state.retreatCooldown = 100;
                this._behaviorRetreat(entity, state); return;
            }
        } catch(e) {}

        const target = this._findTarget(entity, state);
        if (target) {
            state.currentTarget = target.id;
            state.combatState = "aggressive";
            state.targetMemory = target.location;
            state.targetMemoryExpiry = Date.now() + Config.AI_TARGET_MEMORY * 50;
            this._attackTarget(entity, state, target);
        } else if (state.targetMemory && Date.now() < state.targetMemoryExpiry) {
            this._moveTo(entity, state.targetMemory);
        } else {
            state.combatState = "idle";
            state.currentTarget = null;
            state.targetMemory = null;
            this._clearMark(state);
        }
    },

    _findTarget(entity, state) {
        const d = Core.Database.load();
        const krallik = d.kralliklar[state.krallikId];
        if (!krallik) return null;

        const askerTipi = this._getSoldierType(entity);
        const askerConfig = this._getSoldierConfig(askerTipi);
        let searchRange = state.aggression > 80 ? Config.AI_VIEW_RANGE : Config.AI_AGGRO_RANGE;

        const rankData = d.askerKayit?.[entity.id];
        if (rankData) {
            const rank = Systems.getAskerRank(rankData.kill || 0);
            searchRange = Math.floor(searchRange * (rank.viewBonus || 1));
        }
        if (askerConfig.type === "ranged") searchRange = Config.AI_VIEW_RANGE;

        const nearby = Core.Cache?.getNearbyEntities?.(entity.location, searchRange) || [];
        let bestTarget = null, bestDistSq = Infinity;

        for (const other of nearby) {
            if (other.id === entity.id || !Core.Cache?.isValidEntity?.(other)) continue;
            const otherKid = Core.Cache?.getEntityKrallikId?.(other);
            if (!otherKid || otherKid === state.krallikId) continue;
            if (Core.Diplomacy?.isAllied?.(state.krallikId, otherKid)) continue;

            const isPlayer = other.typeId === "minecraft:player";
            const isAtWar = Core.Diplomacy?.isAtWar?.(state.krallikId, otherKid);
            if (!isAtWar && !isPlayer) continue;

            if (isPlayer) {
                try {
                    const claimDim = other.dimension?.id ?? "minecraft:overworld";
                    const claim = ClaimManager.getClaimAt(other.location, claimDim);
                    if (claim?.krallik === state.krallikId) {
                        if (ClaimManager.hasPermission(claim.id, other.name || "")) continue;
                    }
                } catch(_e) {}
            }

            const distSq = Core.Performance.distanceSq(entity.location, other.location);
            if (distSq < bestDistSq) { bestDistSq = distSq; bestTarget = other; }
        }
        return bestTarget;
    },

    _attackTarget(entity, state, target) {
        if (!target?.isValid?.() || !target.location) { state.currentTarget = null; this._clearMark(state); return; }
        this._markTarget(entity, state, target);

        const distSq = Core.Performance.distanceSq(entity.location, target.location);
        const askerTipi = this._getSoldierType(entity);
        const askerConfig = this._getSoldierConfig(askerTipi);
        const optimalRange = askerConfig.range || 1.5;
        const moraleM = Core.Morale?.getMoraleMultiplier?.(state.morale) || { speed: 1 };
        let speed = (askerConfig.speed || 1) * (moraleM.speed || 1);

        const d = Core.Database.load();
        const krallik = d.kralliklar[state.krallikId];
        const ulkeBonus = Config.ULKELER[krallik?.ulkeTipi]?.bonus || {};
        if (ulkeBonus.speed) speed *= ulkeBonus.speed;
        if (krallik?.intikamModu) speed *= 1.2;

        // IŞINLAMA YOK - SADECE YÜRÜME
        if (distSq > optimalRange * optimalRange) {
            Systems.moveEntity(entity, target.location, speed);
        } else {
            try {
                const faceLoc = { x: target.location.x, y: target.location.y, z: target.location.z };
                if (typeof entity.lookAt === "function") entity.lookAt(faceLoc);
            } catch(e) {}
        }

        state.aiCooldown = Math.max(5, Config.AI_COMBAT_CHECK - Math.floor(speed * 5));
        state.lastAttack = Date.now();
    },

    // NapoleonicMergedBp birimleri (tame/sahipli durumda) sadece bu tag'i taşıyan
    // hedeflere saldırabilir (bkz. entity JSON'larındaki minecraft:soldier_tame /
    // minecraft:cavalry_tame içine eklenen nearest_attackable_target). Böylece
    // sahipli askerler vahşi canavarlara değil, yalnızca Krallık AI'ının seçtiği
    // düşman askerine/oyuncusuna saldırır.
    _markTarget(entity, state, target) {
        if (!target?.isValid?.()) return;
        const tag = Config.ASKER_HEDEF_TAG;
        if (!tag) return;
        if (state.markedTargetId === target.id) return;
        this._clearMark(state);
        try { target.addTag?.(tag); } catch(e) {}
        state.markedTargetId = target.id;
    },

    _clearMark(state) {
        const tag = Config.ASKER_HEDEF_TAG;
        if (!state.markedTargetId || !tag) { state.markedTargetId = null; return; }
        try {
            const old = Core.Cache?.getEntityById?.(state.markedTargetId);
            if (old?.isValid?.()) old.removeTag?.(tag);
        } catch(e) {}
        state.markedTargetId = null;
    },

    _behaviorGuard(entity, state) {
        const d = Core.Database.load();
        const krallik = d.kralliklar[state.krallikId];
        if (!krallik) return;
        const kral = world.getAllPlayers().find(p => p.name === krallik.lider);
        if (!kral) { state.aiCooldown = 30; return; }

        const guardSoldiers = Core.Cache?.getKrallikEntities?.(state.krallikId)?.filter(e => {
            if (!Core.Cache?.isValidEntity?.(e)) return false;
            return (e.getTags?.() || []).includes("krali_koru");
        }) || [];
        const slotIndex = guardSoldiers.findIndex(e => e.id === entity.id);
        const totalGuards = Math.max(1, guardSoldiers.length);
        const GUARD_RADIUS = Math.max(3, Math.min(8, totalGuards * 0.6 + 2));
        const angle = ((slotIndex >= 0 ? slotIndex : 0) / totalGuards) * Math.PI * 2;
        const targetX = kral.location.x + Math.cos(angle) * GUARD_RADIUS;
        const targetZ = kral.location.z + Math.sin(angle) * GUARD_RADIUS;
        const targetPos = { x: targetX, y: kral.location.y, z: targetZ };

        const threat = this._findTarget(entity, state);
        if (threat) {
            const threatDistToKing = Core.Performance.distanceSq(threat.location, kral.location);
            if (threatDistToKing <= 10 * 10) {
                const ix = (threat.location.x + kral.location.x) / 2;
                const iz = (threat.location.z + kral.location.z) / 2;
                Systems.moveEntity(entity, { x: ix, y: entity.location.y, z: iz });
                this._attackTarget(entity, state, threat);
                state.aiCooldown = 6;
                return;
            }
        }

        const distToSlot = Core.Performance.distanceSq(entity.location, targetPos);
        if (distToSlot > 2.5 * 2.5) {
            const dist = Math.sqrt(distToSlot) || 1;
            const speed = dist > 15 ? 1.5 : dist > 6 ? 1.2 : 1.0;
            Systems.moveEntity(entity, targetPos, speed);
        }
        state.aiCooldown = 10;
    },

    _behaviorHold(entity, state) {
        if (!state.holdPoint) { state.holdPoint = { x: entity.location.x, z: entity.location.z }; }
        const distToHold = Core.Performance.distanceSq(entity.location, state.holdPoint);
        if (distToHold > 18 * 18) {
            this._moveTo(entity, state.holdPoint);
            state.aiCooldown = 8;
            return;
        }
        const threat = this._findTarget(entity, state);
        if (threat) {
            const dsq = Core.Performance.distanceSq(entity.location, threat.location);
            if (dsq <= 12 * 12) {
                this._attackTarget(entity, state, threat);
                state.aiCooldown = 6;
                return;
            }
        }
        state.aiCooldown = 15;
    },

    _behaviorDefend(entity, state) {
        const claims = ClaimManager.getKrallikClaims(state.krallikId);
        if (claims.length > 0) {
            const nearestClaim = claims.reduce((a, b) => {
                const dA = Core.Performance.distanceSq(entity.location, { x: a.x, z: a.z });
                const dB = Core.Performance.distanceSq(entity.location, { x: b.x, z: b.z });
                return dA < dB ? a : b;
            }, claims[0]);
            const distToClaim = Math.sqrt(Core.Performance.distanceSq(entity.location, { x: nearestClaim.x, z: nearestClaim.z }));
            const claimRadius = nearestClaim.radius || ClaimManager.CONFIG.DEFAULT_RADIUS;
            if (distToClaim > claimRadius + 20) {
                this._moveTo(entity, { x: nearestClaim.x, z: nearestClaim.z });
            }
        }
        const target = this._findTarget(entity, state);
        if (target) { this._attackTarget(entity, state, target); }
        state.aiCooldown = 15;
    },

    _behaviorRetreat(entity, state) {
        state.combatState = "retreating";
        this._clearMark(state);
        const claims = ClaimManager.getKrallikClaims(state.krallikId);
        if (claims.length > 0) {
            const claim = claims[0];
            this._moveTo(entity, { x: claim.x, z: claim.z });
        }
        state.aiCooldown = 10;
    },

    _behaviorRally(entity, state) {
        const krallik = Core.Database.load().kralliklar[state.krallikId];
        if (!krallik) return;
        const lider = world.getAllPlayers().find(p => p.name === krallik.lider);
        if (lider) {
            const dsq = Core.Performance.distanceSq(entity.location, lider.location);
            if (dsq > 4 * 4) {
                const speed = dsq > 30 * 30 ? 1.5 : 1.2;
                Systems.moveEntity(entity, lider.location, speed);
                state.aiCooldown = 6;
            } else {
                state.aiCooldown = 20;
            }
        } else { state.aiCooldown = 30; }
    },

    _behaviorPatrol(entity, state) {
        const claims = ClaimManager.getKrallikClaims(state.krallikId);
        if (claims.length === 0) return;
        const claim = claims[0];
        const claimRadius = claim.radius || ClaimManager.CONFIG.DEFAULT_RADIUS;

        if (!state.patrolPoint || Core.Performance.distanceSq(entity.location, state.patrolPoint) < 6) {
            const angle = (state.patrolIndex * 0.5) % (Math.PI * 2);
            state.patrolPoint = { x: claim.x + Math.cos(angle) * claimRadius * 0.8, z: claim.z + Math.sin(angle) * claimRadius * 0.8 };
            state.patrolIndex++;
        }
        const target = this._findTarget(entity, state);
        if (target) { this._attackTarget(entity, state, target); }
        else if (state.patrolPoint) { this._moveTo(entity, state.patrolPoint); }
        state.aiCooldown = 12;
    },

    _behaviorAggressive(entity, state) {
        const target = this._findTarget(entity, state);
        if (target) this._attackTarget(entity, state, target);
        state.aiCooldown = 8;
    },

    _moveTo(entity, targetLoc, speed = 1.0) {
        if (!targetLoc) return;
        Systems.moveEntity(entity, targetLoc, speed);
    }
};

export const Combat = {
    _damageTrack: {},
    _killStreaks: {},

    onEntityHurt(entity, damage, attacker) {
        if (!entity?.isValid?.() || !attacker?.isValid?.()) return;
        const eKid = Core.Cache?.getEntityKrallikId?.(entity);
        const aKid = Core.Cache?.getEntityKrallikId?.(attacker);
        if (!eKid || !aKid || eKid === aKid) return;

        const d = Core.Database.load();
        const eK = d.kralliklar[eKid], aK = d.kralliklar[aKid];
        if (!eK || !aK) return;
        if (Core.Diplomacy?.isAllied?.(aKid, eKid)) return;
        if (Core.Diplomacy?.hasNonAggression?.(aKid, eKid)) return;

        const eid = entity.id;
        if (!this._damageTrack[eid]) {
            this._damageTrack[eid] = { totalDamage: 0, attackers: {}, lastAttacker: null, assistors: new Set() };
        }
        const track = this._damageTrack[eid];
        track.totalDamage += damage;
        track.lastAttacker = aKid;
        if (!track.attackers[aKid]) track.attackers[aKid] = { damage: 0, hits: 0 };
        track.attackers[aKid].damage += damage;
        track.attackers[aKid].hits++;
        for (const kid of Object.keys(track.attackers)) { if (kid !== aKid) track.assistors.add(kid); }

        if (entity.typeId === "minecraft:player") {
            const hp = entity.getComponent("health")?.currentValue;
            if (hp !== undefined && hp <= damage) this._checkKralDeath(entity, aKid);
        }
    },

    onEntityDeath(entity) {
        const track = this._damageTrack[entity.id];
        if (!track) return;
        const d = Core.Database.load();
        const eKid = Core.Cache?.getEntityKrallikId?.(entity);
        const killerKid = track.lastAttacker;
        if (!killerKid || !eKid) { delete this._damageTrack[entity.id]; return; }

        const killerK = d.kralliklar[killerKid];
        if (killerK) {
            const bonus = 100 + Math.floor(track.totalDamage * 0.1);
            killerK.toplamKill = (killerK.toplamKill || 0) + 1;
            killerK.hazine += bonus;
            killerK.warScore = (killerK.warScore || 0) + 10;
            if (!this._killStreaks[killerKid]) this._killStreaks[killerKid] = 0;
            this._killStreaks[killerKid]++;
            if (this._killStreaks[killerKid] >= 5) killerK.hazine += 50;
        }

        const entityK = d.kralliklar[eKid];
        if (entityK) entityK.warScore = Math.max(0, (entityK.warScore || 0) - 5);

        for (const akid of track.assistors) {
            if (akid === killerKid) continue;
            const aK = d.kralliklar[akid];
            if (aK) aK.hazine += 25;
        }

        if (!d.combatLogs) d.combatLogs = [];
        d.combatLogs.unshift({ timestamp: Date.now(), victimKid: eKid, killerKid, assistors: [...track.assistors], totalDamage: track.totalDamage, entityType: entity.typeId });
        if (d.combatLogs.length > 200) d.combatLogs.length = 200;

        if (d.askerKayit?.[entity.id]) { d.askerKayit[entity.id].kill = (d.askerKayit[entity.id].kill || 0) + 1; }

        if (entity.typeId === "minecraft:player") {
            Core.Profile?.updateStat?.(entity.name || entity.id, "death", 1);
            if (killerKid) {
                const killerPlayer = world.getAllPlayers().find(p => Core.Database.getOyuncuKrallikId(p.name) === killerKid);
                if (killerPlayer) Core.Profile?.updateStat?.(killerPlayer.name, "kill", 1);
            }
        }

        delete this._damageTrack[entity.id];
        Core.Database.markDirty("krallik_army");
        Core.Database.markDirty("krallik_core");
    },

    _checkKralDeath(playerEntity, killerKid) {
        const d = Core.Database.load();
        const playerName = playerEntity.name || playerEntity.id;
        for (const [kid, krallik] of Object.entries(d.kralliklar)) {
            if (krallik.lider === playerName) {
                krallik.kralOldu = true;
                krallik.moral = Math.max(10, (krallik.moral || 60) - 20);
                Core.News?.addNews?.("yonetim", `${krallik.isim} §fkralı öldü!`);
                const askerSayisi = Core.Cache?.getKrallikEntityCount?.(kid) || 0;
                const dusmanAskeri = Core.Cache?.getKrallikEntityCount?.(killerKid) || 0;
                if (askerSayisi > dusmanAskeri) {
                    krallik.intikamModu = true;
                    for (const e of Core.Cache?.getKrallikEntities?.(kid) || []) Systems.addTag(e, "saldir");
                } else {
                    for (const e of Core.Cache?.getKrallikEntities?.(kid) || []) Systems.addTag(e, "geri_cekil");
                }
                Core.Database.markDirty("krallik_core");
                break;
            }
        }
    },

    resetKillStreak(kid) { this._killStreaks[kid] = 0; }
};

export const Morale = {
    update(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return;
        let moral = k.moral || 60;

        const asker = Core.Cache?.getKrallikEntityCount?.(kid) || 0;
        const claims = ClaimManager.getKrallikClaims(kid).length;
        const hazine = k.hazine || 0;
        const savas = (k.savaslar || []).length;

        if (hazine > 10000) moral = Math.min(100, moral + 1);
        if (claims > 5) moral = Math.min(100, moral + 1);
        if (asker > 20) moral = Math.min(100, moral + 0.5);
        if (hazine < 0) moral = Math.max(0, moral - 3);
        if (savas > 2) moral = Math.max(0, moral - 2);
        if (asker < 3) moral = Math.max(0, moral - 1);

        const recentLosses = (d.combatLogs || []).filter(l => l.victimKid === kid && Date.now() - l.timestamp < 300000).length;
        moral = Math.max(0, moral - recentLosses * 0.5);

        if (k.intikamModu) { moral = Math.min(100, moral + 15); k.intikamModu = false; }
        if (k.kralOldu) { moral = Math.max(10, moral - 20); k.kralOldu = false; }

        const ulke = Config.ULKELER[k.ulkeTipi];
        if (ulke?.bonus?.morale) moral *= ulke.bonus.morale;

        const gelisim = k.gelisimAgaci?.askeri || 0;
        moral = Math.min(100, moral + gelisim * 0.5);

        try {
            const ittifakCount = Core.Diplomacy?.getAllies?.(kid)?.length ?? (k.muttefikler || []).length;
            if (ittifakCount > 0) moral = Math.min(100, moral + ittifakCount * 0.5);
        } catch(e) {}

        k.moral = Math.round(Math.max(0, Math.min(100, moral)));
        Core.Database.markDirty("krallik_core");
    },

    getMoraleMultiplier(moral) {
        if (moral >= 80) return { damage: 1.2, speed: 1.15, aggression: 1.3 };
        if (moral >= 60) return { damage: 1.0, speed: 1.0, aggression: 1.0 };
        if (moral >= 40) return { damage: 0.9, speed: 0.95, aggression: 0.8 };
        if (moral >= 20) return { damage: 0.75, speed: 0.85, aggression: 0.6 };
        return { damage: 0.5, speed: 0.7, aggression: 0.4 };
    }
};

export const Siege = {
    start(attackerId, claimId) {
        const d = Core.Database.load();
        const claim = d.claimler?.[claimId];
        if (!claim || claim.krallik === attackerId || claim.contested) return false;

        const attacker = d.kralliklar[attackerId];
        const defender = d.kralliklar[claim.krallik];
        if (!attacker || !defender) return false;

        const siegeLocCheck = { x: claim.x, z: claim.z };
        const nearby = Core.Cache?.getNearbyEntities?.(siegeLocCheck, Config.SIEGE_CONTEST_RANGE)?.filter(e => Core.Cache?.getEntityKrallikId?.(e) === attackerId).length || 0;
        if (nearby < 3) return false;

        if (!Core.Diplomacy?.isAtWar?.(attackerId, claim.krallik)) {
            Core.Diplomacy?.declareWar?.(attackerId, claim.krallik);
        }

        claim.contested = true;
        claim.contestedBy = attackerId;
        attacker.status = "kusatma";
        defender.status = "kusatma";
        attacker.kusatmaCount = (attacker.kusatmaCount || 0) + 1;

        if (!d.sieges) d.sieges = {};
        d.sieges[claimId] = {
            claimId, attackerKrallikId: attackerId, defenderKrallikId: claim.krallik,
            startTime: Date.now(), captureProgress: 0, lastTick: Date.now(),
            attackerWave: 0, defenderWave: 0
        };

        Core.Alarm?.triggerRaidAlarm?.(claim.krallik, attackerId);
        Core.News?.addNews?.("kusatma", `${attacker.isim} §f→ §c${defender.isim} §fbölgesini kuşatıyor!`);
        Core.Database.markDirty("krallik_claims");
        Systems.broadcastToKrallik(attackerId, `§c🏰 KUŞATMA! ${attacker.isim} §f→ §c${defender.isim} §fbölgesini kuşatıyor!`);
        return true;
    },

    tick() {
        const d = Core.Database.load();
        if (!d.sieges) return;
        const now = Date.now();

        for (const [claimId, siege] of Object.entries(d.sieges)) {
            const claim = d.claimler?.[claimId];
            if (!claim) { delete d.sieges[claimId]; continue; }

            const loc = { x: claim.x, z: claim.z };
            const range = Config.SIEGE_CONTEST_RANGE;

            const attackers = Core.Cache?.getNearbyEntities?.(loc, range)?.filter(e => Core.Cache?.getEntityKrallikId?.(e) === siege.attackerKrallikId).length || 0;
            const defenders = Core.Cache?.getNearbyEntities?.(loc, range)?.filter(e => Core.Cache?.getEntityKrallikId?.(e) === siege.defenderKrallikId).length || 0;

            if (attackers === 0) {
                claim.contested = false;
                claim.contestedBy = null;
                delete d.sieges[claimId];
                Core.Database.markDirty("krallik_claims");
                continue;
            }

            const moraleA = Morale.getMoraleMultiplier(d.kralliklar[siege.attackerKrallikId]?.moral || 60);
            const moraleD = Morale.getMoraleMultiplier(d.kralliklar[siege.defenderKrallikId]?.moral || 60);

            siege.attackerWave = Math.min(3, Math.floor(attackers / 5));
            siege.defenderWave = Math.min(3, Math.floor(defenders / 3));

            const timeDiff = (now - siege.lastTick) / 1000;
            const attackPower = attackers * (moraleA.damage || 1) * (1 + siege.attackerWave * 0.2);
            const defensePower = defenders * Config.SIEGE_DEFENSE_BONUS * (moraleD.damage || 1) + (claim.level || 1) * 0.5;

            const progressChange = (attackPower - defensePower) * timeDiff / Config.SIEGE_CAPTURE_TIME;
            siege.captureProgress += Math.max(-0.1, Math.min(0.3, progressChange));
            siege.captureProgress = Math.max(0, Math.min(100, siege.captureProgress));
            siege.lastTick = now;

            if (siege.captureProgress >= 100) {
                const oldKid = claim.krallik;
                claim.krallik = siege.attackerKrallikId;
                claim.contested = false;
                claim.contestedBy = null;
                claim.health = 50;
                delete d.sieges[claimId];

                const newK = d.kralliklar[siege.attackerKrallikId];
                if (newK) {
                    newK.hazine += 1000;
                    newK.warScore += 100;
                    newK.zaferCount = (newK.zaferCount || 0) + 1;
                    if (!(newK.savaslar || []).length) newK.status = "baris";
                }
                const oldK = d.kralliklar[oldKid];
                if (oldK) oldK.maglubiyetCount = (oldK.maglubiyetCount || 0) + 1;

                Core.SavasRaporu?.addRapor?.(siege.attackerKrallikId, siege.defenderKrallikId, "zafer", { claimId, oluSayisi: defenders });
                Core.News?.addNews?.("claim", `${newK?.isim || "?"} §fbir bölgeyi ele geçirdi!`);
                Systems.broadcastToKrallik(siege.attackerKrallikId, `§a🏁 ${newK?.isim || "?"} §fkuşatmayı kazandı!`);
            } else if (siege.captureProgress <= 0 && now - siege.startTime > 60000) {
                claim.contested = false;
                claim.contestedBy = null;
                delete d.sieges[claimId];
            }
            Core.Database.markDirty("krallik_claims");
        }
    }
};

export const Formasyon = {
    _aktifFormasyonlar: {},

    uygula(player, tip) {
        const id = Systems.getPlayerKrallikId(player);
        if (!id) return;
        const loc = player.location;

        Core.Cache?.getEntities?.(true);
        const askerler = Core.Cache?.getKrallikEntities?.(id)?.filter(e => {
            if (!Core.Cache?.isValidEntity?.(e)) return false;
            return (e.getTags?.() || []).some(t => t.startsWith("asker_"));
        }) || [];

        if (askerler.length === 0) {
            Systems.sendMessage(player, "§7Yakında asker bulunamadı.");
            return;
        }

        const spacing = 2;
        let pozisyonlar = [];

        if (tip === "savunma") {
            const melee = askerler.filter(e => !e.getTags?.()?.includes("asker_gunner") && !e.getTags?.()?.includes("asker_cuirassier"));
            const gunners = askerler.filter(e => e.getTags?.()?.includes("asker_gunner"));
            for (let i = 0; i < melee.length; i++) pozisyonlar.push({ x: loc.x + (i - melee.length / 2) * spacing, y: loc.y, z: loc.z + 3 });
            for (let i = 0; i < gunners.length; i++) pozisyonlar.push({ x: loc.x + (i - gunners.length / 2) * spacing * 1.5, y: loc.y, z: loc.z - 3 });
        } else if (tip === "saldiri") {
            for (let i = 0; i < askerler.length; i++) {
                const row = Math.floor(i / 3), col = i % 3;
                pozisyonlar.push({ x: loc.x + (col - 1) * spacing, y: loc.y, z: loc.z + row * spacing + 2 });
            }
        } else if (tip === "cizgi") {
            for (let i = 0; i < askerler.length; i++) pozisyonlar.push({ x: loc.x + (i - askerler.length / 2) * spacing, y: loc.y, z: loc.z });
        } else if (tip === "kare") {
            const side = Math.ceil(Math.sqrt(askerler.length));
            for (let i = 0; i < askerler.length; i++) {
                const row = Math.floor(i / side), col = i % side;
                pozisyonlar.push({ x: loc.x + (col - side / 2) * spacing, y: loc.y, z: loc.z + (row - side / 2) * spacing });
            }
        } else if (tip === "cember") {
            const r = Math.max(4, askerler.length * spacing / (2 * Math.PI));
            for (let i = 0; i < askerler.length; i++) {
                const angle = (2 * Math.PI * i) / askerler.length;
                pozisyonlar.push({ x: loc.x + Math.cos(angle) * r, y: loc.y, z: loc.z + Math.sin(angle) * r });
            }
        }

        const hedefTag = (tip === "saldiri") ? "saldir" : "mevzi_kur";
        const slotlar = [];

        askerler.forEach((e, i) => {
            ["saldir","savun","kolacan","geri_cekil","krali_koru","acil_toplan","bayragi_savun","devriye","mevzi_kur","formasyon_aktif","serbest"].forEach(t => Systems.removeTag(e, t));
            Systems.addTag(e, hedefTag);
            Systems.addTag(e, "formasyon_aktif");

            if (i < pozisyonlar.length) {
                const p = pozisyonlar[i];
                Systems.moveEntity(e, p);
                try {
                    let st = AI._soldierStates?.[e.id];
                    if (!st) st = AI.initSoldier(e, id);
                    if (st) {
                        st.holdPoint = { x: p.x, z: p.z };
                        st.formationOffsetX = p.x - loc.x;
                        st.formationOffsetZ = p.z - loc.z;
                        st.formationTip = tip;
                    }
                } catch {}
                slotlar.push({ entityId: e.id, offsetX: p.x - loc.x, offsetZ: p.z - loc.z });
            }
        });

        this._aktifFormasyonlar[id] = { tip, komut: hedefTag, slotlar };
        Systems.sendMessage(player, `§a✔ ${askerler.length} asker §e${tip}§a formasyonuna geçti!`);
    },

    formasyonTick() {
        for (const [kid, formasyon] of Object.entries(this._aktifFormasyonlar)) {
            if (!formasyon?.slotlar?.length) continue;
            const d = Core.Database.load();
            const k = d.kralliklar[kid];
            if (!k) continue;
            const kral = world.getAllPlayers().find(p => p.name === k.lider);
            if (!kral) continue;

            const merkez = kral.location;
            formasyon.slotlar.forEach((slot) => {
                try {
                    const e = Core.Cache?.getEntityById?.(slot.entityId);
                    if (!e || !Core.Cache?.isValidEntity?.(e)) return;
                    const tags = e.getTags?.() || [];
                    if (!tags.includes("formasyon_aktif")) return;
                    if (tags.includes("saldir")) return;

                    const hedefX = merkez.x + (slot.offsetX || 0);
                    const hedefZ = merkez.z + (slot.offsetZ || 0);
                    const st = AI._soldierStates?.[e.id];
                    if (st) { st.holdPoint = { x: hedefX, z: hedefZ }; }
                } catch {}
            });
        }
    },

    boz(kid) { delete this._aktifFormasyonlar[kid]; }
};

export const Devriye = {
    _devriyeRotalari: {},

    devriyeAta(kid, claimId) {
        if (!this._devriyeRotalari[kid]) this._devriyeRotalari[kid] = {};
        const d = Core.Database.load();
        const claim = d.claimler?.[claimId];
        if (!claim || claim.krallik !== kid) return;
        const rota = { claimId, noktalar: this._rotaOlustur(claim), aktif: true, sonNokta: 0 };
        this._devriyeRotalari[kid][claimId] = rota;
        try {
            const entities = Core.Cache?.getKrallikEntities?.(kid)?.filter(e => Core.Cache?.isValidEntity?.(e)) || [];
            const devriyeAday = entities.filter(e => (e.getTags?.() || []).includes("asker_gunner")).slice(0, 5);
            for (const e of devriyeAday) Systems.addTag(e, "devriye");
        } catch(e) {}
        return rota;
    },

    _rotaOlustur(claim) {
        const noktalar = [];
        const radius = claim.radius || ClaimManager.CONFIG.DEFAULT_RADIUS;
        const cx = typeof claim.x === "number" ? claim.x : 0;
        const cz = typeof claim.z === "number" ? claim.z : 0;
        for (let i = 0; i < 8; i++) {
            const angle = (i / 8) * Math.PI * 2;
            noktalar.push({ x: cx + Math.cos(angle) * radius * 0.75, z: cz + Math.sin(angle) * radius * 0.75 });
        }
        return noktalar;
    },

    devriyeTick() {
        for (const [kid, rotalar] of Object.entries(this._devriyeRotalari)) {
            const entities = Core.Cache?.getKrallikEntities?.(kid) || [];
            const gunners = entities.filter(e => {
                if (!Core.Cache?.isValidEntity?.(e)) return false;
                const tags = e.getTags?.() || [];
                if (!tags.some(t => t.startsWith("asker_"))) return false;
                return tags.includes("devriye") || tags.includes("kolacan");
            });
            if (gunners.length === 0) continue;
            for (const [claimId, rota] of Object.entries(rotalar)) {
                if (!rota.aktif || !rota.noktalar?.length) continue;
                const hedef = rota.noktalar[rota.sonNokta % rota.noktalar.length];
                if (!hedef) continue;
                for (const gunner of gunners.slice(0, 5)) {
                    AI._moveTo(gunner, hedef);
                }
                rota.sonNokta++;
            }
        }
    }
};