// ============================================================
// MODÜL 11: EVENTS - Event Yönetimi ve Krallık Olayları (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { Systems } from "./04_military.js";
import { News } from "./06_kingdom.js";

// ============================================================
// EVENT MANAGER - Global ve Krallık Eventleri
// ============================================================
export const EventManager = {
    startGlobalEvent(title, durationMs, effect) {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        const id = "global_" + Date.now();
        d.events.active[id] = {
            id, type: "global", title,
            startTime: Date.now(),
            endTime: Date.now() + (durationMs || 0),
            effect: effect || {},
            participants: {}
        };
        Core.Database.markDirty("krallik_core");
        Systems.broadcastToKrallik(null, `§6🌍 Dünya Olayı: §f${title}`);
        News.addNews?.("event", `Dünya olayı başladı: ${title}`);
        return id;
    },

    startKingdomEvent(kid, title, durationMs, effect) {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        const id = "kingdom_" + Date.now() + "_" + kid;
        d.events.active[id] = {
            id, type: "kingdom", kid, title,
            startTime: Date.now(),
            endTime: Date.now() + (durationMs || 0),
            effect: effect || {},
            participants: {}
        };
        Core.Database.markDirty("krallik_core");
        Systems.broadcastToKrallik(kid, `§b📢 Krallık Olayı: §f${title}`);
        News.addNews?.("event", `${Core.Database.getKrallik(kid)?.isim || kid} krallığında olay başladı: ${title}`);
        return id;
    },

    endEvent(eventId) {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        const ev = d.events.active?.[eventId];
        if (!ev) return false;
        d.events.history.unshift({ ...ev, endedAt: Date.now() });
        if (d.events.history.length > 100) d.events.history.length = 100;
        delete d.events.active[eventId];
        Core.Database.markDirty("krallik_core");
        
        if (ev.type === "global") {
            Systems.broadcastToKrallik(null, `§e🌍 Dünya Olayı sona erdi: §f${ev.title}`);
        } else {
            Systems.broadcastToKrallik(ev.kid, `§e📢 Krallık Olayı sona erdi: §f${ev.title}`);
        }
        return true;
    },

    getActiveEffect(kid) {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        const combined = { gelirMultiplier: 1, damageMultiplier: 1, marketDiscount: 1, marketPriceMultiplier: 1, aggressionBonus: 1, defenseBonus: 1, speedBonus: 1 };
        for (const ev of Object.values(d.events.active || {})) {
            if (ev.type === "global" || (ev.type === "kingdom" && ev.kid === kid)) {
                if (ev.effect?.gelirMultiplier) combined.gelirMultiplier *= ev.effect.gelirMultiplier;
                if (ev.effect?.damageMultiplier) combined.damageMultiplier *= ev.effect.damageMultiplier;
                if (ev.effect?.marketDiscount) combined.marketDiscount *= ev.effect.marketDiscount;
                if (ev.effect?.marketPriceMultiplier) combined.marketPriceMultiplier *= ev.effect.marketPriceMultiplier;
                if (ev.effect?.aggressionBonus) combined.aggressionBonus *= ev.effect.aggressionBonus;
                if (ev.effect?.defenseBonus) combined.defenseBonus *= ev.effect.defenseBonus;
                if (ev.effect?.speedBonus) combined.speedBonus *= ev.effect.speedBonus;
            }
        }
        return combined;
    },

    addParticipantScore(eventId, playerName, points) {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        const ev = d.events.active?.[eventId];
        if (!ev) return false;
        ev.participants = ev.participants || {};
        ev.participants[playerName] = (ev.participants[playerName] || 0) + (points || 0);
        Core.Database.markDirty("krallik_core");
        return true;
    },

    getLeaderboard(eventId, limit = 10) {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        const ev = d.events.active?.[eventId] || (d.events.history || []).find(e => e.id === eventId);
        if (!ev) return [];
        return Object.entries(ev.participants || {})
            .map(([p, s]) => ({ player: p, score: s }))
            .sort((a, b) => b.score - a.score)
            .slice(0, limit);
    },

    getActiveEvents() {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        return Object.values(d.events.active || {});
    },

    getEventHistory(limit = 20) {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        return (d.events.history || []).slice(0, limit);
    },

    getEventDetails(eventId) {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        return d.events.active?.[eventId] || (d.events.history || []).find(e => e.id === eventId) || null;
    },

    tick() {
        const d = Core.Database.load();
        if (!d.events) d.events = { active: {}, history: [] };
        const now = Date.now();
        for (const [id, ev] of Object.entries(d.events.active || {})) {
            if (now >= (ev.endTime || 0)) this.endEvent(id);
        }
    }
};

// ============================================================
// EVENTS - Krallık Bazlı Rastgele Olaylar
// ============================================================
export const Events = {
    _lastEventCheck: 0,
    _eventCooldown: 60000, // 1 dakika cooldown

    tick() {
        const d = Core.Database.load();
        const now = Date.now();
        
        // Cooldown kontrolü
        if (now - this._lastEventCheck < this._eventCooldown) return;
        this._lastEventCheck = now;

        for (const [kid, k] of Object.entries(d.kralliklar || {})) {
            if (!d.krallikEventleri) d.krallikEventleri = {};
            if (!d.krallikEventleri[kid]) d.krallikEventleri[kid] = {};

            const events = d.krallikEventleri[kid];

            // Süresi dolan eventleri temizle
            for (const [eventId, event] of Object.entries(events)) {
                if (event?.active && now > event.expiry) {
                    event.active = false;
                    Systems.broadcastToKrallik(kid, `§e"${event.message}" olayı sona erdi.`);
                }
            }

            // Yeni event başlatma şansı
            for (const [eventId, eventDef] of Object.entries(Config.EVENTS)) {
                if (events[eventId]?.active) continue;
                
                // Event başlama şansı (her tick'te %0.01 - %0.05 arası)
                const chance = eventDef.chance / 10000;
                if (Math.random() > chance) continue;
                
                events[eventId] = {
                    active: true,
                    startTime: now,
                    expiry: now + eventDef.duration * 50,
                    ...eventDef
                };
                News.addNews?.("event", eventDef.message, { krallik: kid });
                Systems.broadcastToKrallik(kid, `§6📢 ${eventDef.message}`);
            }
        }
        Core.Database.markDirty("krallik_economy");
    },

    triggerEvent(kid, eventId) {
        const d = Core.Database.load();
        const eventDef = Config.EVENTS[eventId];
        if (!eventDef) return false;
        
        if (!d.krallikEventleri) d.krallikEventleri = {};
        if (!d.krallikEventleri[kid]) d.krallikEventleri[kid] = {};
        
        d.krallikEventleri[kid][eventId] = {
            active: true,
            startTime: Date.now(),
            expiry: Date.now() + eventDef.duration * 50,
            ...eventDef
        };
        Systems.broadcastToKrallik(kid, `§6📢 ${eventDef.message}`);
        Core.Database.markDirty("krallik_economy");
        return true;
    },

    forceEndEvent(kid, eventId) {
        const d = Core.Database.load();
        const event = d.krallikEventleri?.[kid]?.[eventId];
        if (!event) return false;
        event.active = false;
        Systems.broadcastToKrallik(kid, `§e"${event.message}" olayı sona erdirildi.`);
        Core.Database.markDirty("krallik_economy");
        return true;
    },

    getActiveEventsForKingdom(kid) {
        const d = Core.Database.load();
        const events = d.krallikEventleri?.[kid] || {};
        const active = [];
        for (const [id, ev] of Object.entries(events)) {
            if (ev.active) active.push({ id, ...ev });
        }
        return active;
    },

    getAllActiveEvents() {
        const d = Core.Database.load();
        const allActive = [];
        for (const [kid, events] of Object.entries(d.krallikEventleri || {})) {
            for (const [id, ev] of Object.entries(events)) {
                if (ev.active) allActive.push({ kid, id, ...ev });
            }
        }
        return allActive;
    },

    extendEvent(kid, eventId, extraDurationTicks) {
        const d = Core.Database.load();
        const event = d.krallikEventleri?.[kid]?.[eventId];
        if (!event?.active) return false;
        event.expiry += extraDurationTicks * 50;
        Core.Database.markDirty("krallik_economy");
        return true;
    },

    applyEventEffects(kid, eventId) {
        const d = Core.Database.load();
        const events = d.krallikEventleri?.[kid] || {};
        const event = events[eventId];
        if (!event?.active) return null;
        
        const effects = {};
        if (event.gelirMultiplier) effects.gelirMultiplier = event.gelirMultiplier;
        if (event.marketPriceMultiplier) effects.marketPriceMultiplier = event.marketPriceMultiplier;
        if (event.marketDiscount) effects.marketDiscount = event.marketDiscount;
        if (event.damageMultiplier) effects.damageMultiplier = event.damageMultiplier;
        if (event.aggressionBonus) effects.aggressionBonus = event.aggressionBonus;
        
        return effects;
    }
};

// ============================================================
// ÖZEL EVENT TİPLERİ
// ============================================================
export const SpecialEvents = {
    // Savaş eventi: tüm krallıklar arasında savaş bonusu
    warEvent: {
        start(attackerKid, defenderKid) {
            const durationMs = 30 * 60 * 1000; // 30 dakika
            const effect = { damageMultiplier: 1.5, aggressionBonus: 2.0 };
            const id = EventManager.startGlobalEvent(`Savaş: ${attackerKid} vs ${defenderKid}`, durationMs, effect);
            EventManager.addParticipantScore(id, attackerKid, 0);
            EventManager.addParticipantScore(id, defenderKid, 0);
            return id;
        }
    },

    // Kıtlık eventi
    famineEvent: {
        start(kid = null) {
            const durationMs = 15 * 60 * 1000;
            const effect = { gelirMultiplier: 0.5, marketPriceMultiplier: 1.8 };
            if (kid) return EventManager.startKingdomEvent(kid, "Kıtlık Zamanı", durationMs, effect);
            return EventManager.startGlobalEvent("Küresel Kıtlık", durationMs, effect);
        }
    },

    // Bereket eventi
    prosperityEvent: {
        start(kid = null) {
            const durationMs = 20 * 60 * 1000;
            const effect = { gelirMultiplier: 1.5, marketDiscount: 0.7 };
            if (kid) return EventManager.startKingdomEvent(kid, "Bereket Zamanı", durationMs, effect);
            return EventManager.startGlobalEvent("Küresel Bereket", durationMs, effect);
        }
    },

    // Kahramanlık eventi
    heroismEvent: {
        start(kid) {
            const durationMs = 10 * 60 * 1000;
            const effect = { damageMultiplier: 2.0, defenseBonus: 1.3 };
            return EventManager.startKingdomEvent(kid, "Kahramanlık Çağı", durationMs, effect);
        }
    },

    // Ticaret eventi
    tradeEvent: {
        start(kid = null) {
            const durationMs = 25 * 60 * 1000;
            const effect = { marketDiscount: 0.5, gelirMultiplier: 1.2 };
            if (kid) return EventManager.startKingdomEvent(kid, "Ticaret Fırtınası", durationMs, effect);
            return EventManager.startGlobalEvent("Küresel Ticaret", durationMs, effect);
        }
    },

    // Savunma eventi
    defenseEvent: {
        start(kid = null) {
            const durationMs = 20 * 60 * 1000;
            const effect = { defenseBonus: 1.5, gelirMultiplier: 0.8 };
            if (kid) return EventManager.startKingdomEvent(kid, "Savunma Duyarlılığı", durationMs, effect);
            return EventManager.startGlobalEvent("Küresel Savunma", durationMs, effect);
        }
    },

    // Hız eventi
    speedEvent: {
        start(kid = null) {
            const durationMs = 15 * 60 * 1000;
            const effect = { speedBonus: 1.5, aggressionBonus: 1.3 };
            if (kid) return EventManager.startKingdomEvent(kid, "Rüzgar Gibi", durationMs, effect);
            return EventManager.startGlobalEvent("Hızlanma Zamanı", durationMs, effect);
        }
    },

    // Veba eventi (olumsuz)
    plagueEvent: {
        start(kid = null) {
            const durationMs = 10 * 60 * 1000;
            const effect = { gelirMultiplier: 0.6, damageMultiplier: 0.7 };
            if (kid) return EventManager.startKingdomEvent(kid, "Kara Veba", durationMs, effect);
            return EventManager.startGlobalEvent("Küresel Salgın", durationMs, effect);
        }
    },

    // İsyan eventi (sadece krallık)
    rebellionEvent: {
        start(kid) {
            const durationMs = 5 * 60 * 1000;
            const effect = { gelirMultiplier: 0.4, aggressionBonus: 1.5 };
            return EventManager.startKingdomEvent(kid, "Halk İsyanı", durationMs, effect);
        }
    },

    // Formatlı event başlatma
    startCustomEvent(title, durationSeconds, effect, kid = null) {
        const durationMs = durationSeconds * 1000;
        if (kid) {
            return EventManager.startKingdomEvent(kid, title, durationMs, effect);
        }
        return EventManager.startGlobalEvent(title, durationMs, effect);
    }
};