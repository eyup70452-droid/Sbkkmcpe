// ============================================================
// MODÜL 05: DİPLOMASİ - İttifak, Savaş, Vassal, Kahraman (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { Systems } from "./04_military.js";

export const Diplomacy = {
    _getKey(a, b) { return [a, b].sort().join("|"); },

    _ensureRoots(d) {
        if (!d.diplomacy) d.diplomacy = { relations: {}, wars: {}, alliances: {}, treaties: {}, tradeAgreements: {}, embargoes: {}, ceasefires: {} };
        if (!d.diplomacy.relations) d.diplomacy.relations = {};
        if (!d.diplomacy.wars) d.diplomacy.wars = {};
        if (!d.diplomacy.alliances) d.diplomacy.alliances = {};
        if (!d.diplomacy.treaties) d.diplomacy.treaties = {};
        if (!d.diplomacy.tradeAgreements) d.diplomacy.tradeAgreements = {};
        if (!d.diplomacy.embargoes) d.diplomacy.embargoes = {};
        if (!d.diplomacy.ceasefires) d.diplomacy.ceasefires = {};
    },

    hasAccess(ownerKid, visitorKid) {
        if (!ownerKid || !visitorKid) return false;
        if (ownerKid === visitorKid) return true;
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(ownerKid, visitorKid);
        if (d.diplomacy.alliances[key]) return true;
        if (d.diplomacy.tradeAgreements[key]) return true;
        const treaties = d.treaties || {};
        if (treaties[ownerKid]?.[visitorKid] || treaties[visitorKid]?.[ownerKid]) return true;
        return false;
    },

    getRelation(kidA, kidB) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        return d.diplomacy.relations[key]?.value || 0;
    },

    modifyRelation(kidA, kidB, delta, reason = "unknown") {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        if (!d.diplomacy.relations[key]) {
            d.diplomacy.relations[key] = { value: 0, lastUpdate: Date.now() };
        }
        d.diplomacy.relations[key].value = Math.max(-100, Math.min(100, d.diplomacy.relations[key].value + delta));
        d.diplomacy.relations[key].lastUpdate = Date.now();
        Core.Database.markDirty("krallik_core");
        Core.LogSistemi?.log?.("diplomasi", `İlişki değişti: ${kidA}↔${kidB} ${delta > 0 ? "+" : ""}${delta} (${reason})`);
        return d.diplomacy.relations[key].value;
    },

    isAtWar(kidA, kidB) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        const war = d.diplomacy.wars[key];
        return !!(war && !war.endTime);
    },

    declareWar(kidA, kidB, reason = "declared") {
        if (this.isAtWar(kidA, kidB)) return false;
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        d.diplomacy.wars[key] = { startTime: Date.now(), endTime: null, reason };

        const k1 = d.kralliklar[kidA];
        const k2 = d.kralliklar[kidB];
        if (k1) {
            if (!k1.savaslar) k1.savaslar = [];
            if (!k1.savaslar.includes(kidB)) k1.savaslar.push(kidB);
            k1.status = "savas";
        }
        if (k2) {
            if (!k2.savaslar) k2.savaslar = [];
            if (!k2.savaslar.includes(kidA)) k2.savaslar.push(kidA);
            k2.status = "savas";
        }

        try {
            if (k1) Core.Leaderboard?.recordKingdomStat?.(kidA, "warScore", (k1.warScore || 0) - 5);
        } catch(e) {}

        Core.Database.markDirty("krallik_core");
        Core.News?.addNews?.("savas", `${k1?.isim || kidA} ↔ ${k2?.isim || kidB} SAVAŞ başladı!`);
        Systems.broadcastToKrallik(kidA, `§c⚔️ ${k1?.isim || kidA} ↔ ${k2?.isim || kidB} SAVAŞ başladı!`);
        try { Core.Vassal?.efendiSavasIlanında?.(kidA, kidB); Core.Vassal?.efendiSavasIlanında?.(kidB, kidA); } catch(e) {}
        return true;
    },

    makePeace(kidA, kidB, reason = "peace") {
        if (!this.isAtWar(kidA, kidB)) return false;
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        if (d.diplomacy.wars[key]) d.diplomacy.wars[key].endTime = Date.now();

        const k1 = d.kralliklar[kidA];
        const k2 = d.kralliklar[kidB];
        if (k1 && k1.savaslar) k1.savaslar = k1.savaslar.filter(s => s !== kidB);
        if (k2 && k2.savaslar) k2.savaslar = k2.savaslar.filter(s => s !== kidA);
        if (k1 && (!k1.savaslar || k1.savaslar.length === 0)) k1.status = "baris";
        if (k2 && (!k2.savaslar || k2.savaslar.length === 0)) k2.status = "baris";

        this.modifyRelation(kidA, kidB, 15, reason);
        Core.Database.markDirty("krallik_core");
        Core.News?.addNews?.("diplomasi", `${k1?.isim || kidA} & ${k2?.isim || kidB} barış yaptı!`);
        Systems.broadcastToKrallik(kidA, `§a🕊️ ${k1?.isim || kidA} & ${k2?.isim || kidB} barış yaptı!`);
        return true;
    },

    isAllied(kidA, kidB) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        return !!d.diplomacy.alliances[key];
    },

    formAlliance(kidA, kidB) {
        if (this.isAtWar(kidA, kidB) || this.isAllied(kidA, kidB)) return false;
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        d.diplomacy.alliances[key] = { startTime: Date.now() };

        const k1 = d.kralliklar[kidA];
        const k2 = d.kralliklar[kidB];
        if (k1) {
            if (!k1.muttefikler) k1.muttefikler = [];
            if (!k1.muttefikler.includes(kidB)) k1.muttefikler.push(kidB);
        }
        if (k2) {
            if (!k2.muttefikler) k2.muttefikler = [];
            if (!k2.muttefikler.includes(kidA)) k2.muttefikler.push(kidA);
        }

        this.modifyRelation(kidA, kidB, 25, "alliance");
        Core.Database.markDirty("krallik_core");
        Core.News?.addNews?.("diplomasi", `${k1?.isim || kidA} & ${k2?.isim || kidB} ittifak kurdu!`);
        Systems.broadcastToKrallik(kidA, `§a🤝 ${k1?.isim || kidA} & ${k2?.isim || kidB} ittifak kurdu!`);
        return true;
    },

    breakAlliance(kidA, kidB) {
        if (!this.isAllied(kidA, kidB)) return false;
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        delete d.diplomacy.alliances[key];

        const k1 = d.kralliklar[kidA];
        const k2 = d.kralliklar[kidB];
        if (k1 && k1.muttefikler) k1.muttefikler = k1.muttefikler.filter(m => m !== kidB);
        if (k2 && k2.muttefikler) k2.muttefikler = k2.muttefikler.filter(m => m !== kidA);

        this.modifyRelation(kidA, kidB, -20, "break_alliance");
        Core.Database.markDirty("krallik_core");
        Core.News?.addNews?.("diplomasi", `${k1?.isim || kidA} & ${k2?.isim || kidB} ittifakı bozdu!`);
        return true;
    },

    nonAggressionPact(kidA, kidB, durationMs = 3600000) {
        if (this.isAtWar(kidA, kidB)) return false;
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        d.diplomacy.treaties[key] = { type: "non_aggression", endTime: Date.now() + durationMs };

        d.treaties = d.treaties || {};
        d.treaties[kidA] = d.treaties[kidA] || {};
        d.treaties[kidB] = d.treaties[kidB] || {};
        d.treaties[kidA][kidB] = { type: "non_aggression", startDate: Date.now(), endDate: Date.now() + durationMs };
        d.treaties[kidB][kidA] = { type: "non_aggression", startDate: Date.now(), endDate: Date.now() + durationMs };

        Core.Database.markDirty("krallik_core");
        Core.Database.markDirty("krallik_economy");
        return true;
    },

    hasNonAggression(kidA, kidB) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        const treaty = d.diplomacy.treaties[key];
        if (treaty && treaty.type === "non_aggression" && treaty.endTime > Date.now()) return true;
        const t2 = d.treaties?.[kidA]?.[kidB];
        return !!(t2 && t2.type === "non_aggression" && t2.endDate > Date.now());
    },

    tradeAgreement(kidA, kidB) {
        if (this.isAtWar(kidA, kidB)) return false;
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        d.diplomacy.tradeAgreements[key] = { startTime: Date.now() };

        d.treaties = d.treaties || {};
        d.treaties[kidA] = d.treaties[kidA] || {};
        d.treaties[kidB] = d.treaties[kidB] || {};
        d.treaties[kidA][kidB] = { type: "trade", startDate: Date.now(), endDate: null };
        d.treaties[kidB][kidA] = { type: "trade", startDate: Date.now(), endDate: null };

        const k1 = d.kralliklar[kidA];
        const k2 = d.kralliklar[kidB];
        if (k1) k1.gelir = (k1.gelir || 0) + 5;
        if (k2) k2.gelir = (k2.gelir || 0) + 5;

        Core.Database.markDirty("krallik_core");
        Core.Database.markDirty("krallik_economy");
        return true;
    },

    hasTradeAgreement(kidA, kidB) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        return !!d.diplomacy.tradeAgreements[key];
    },

    getMutualAllies(kid) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const allies = [];
        for (const key of Object.keys(d.diplomacy.alliances || {})) {
            const [a, b] = key.split("|");
            if (a === kid && !this.isAtWar(kid, b)) allies.push(b);
            if (b === kid && !this.isAtWar(kid, a)) allies.push(a);
        }
        return allies;
    },

    getAllies(kid) { return this.getMutualAllies(kid); },

    callAllies(kid, message = "§c⚔️ Müttefik çağrısı!") {
        const allies = this.getMutualAllies(kid);
        for (const ally of allies) {
            Systems.broadcastToKrallik(ally, message);
        }
        return allies.length;
    },

    setEmbargo(kidA, kidB, active) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = kidA + "->" + kidB;
        d.diplomacy.embargoes[key] = { active: !!active, lastUpdate: Date.now() };
        Core.Database.markDirty("krallik_core");
    },

    hasEmbargo(kidA, kidB) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = kidA + "->" + kidB;
        return d.diplomacy.embargoes?.[key]?.active === true;
    },

    spy(kid, targetKid) {
        const d = Core.Database.load();
        const target = d.kralliklar[targetKid];
        if (!target) return null;
        return {
            kingdom: targetKid,
            name: target.isim,
            treasury: target.hazine || 0,
            armyCount: Core.Cache?.getKrallikEntityCount?.(targetKid) || 0,
            claimCount: Core.Database.getClaimler(targetKid).length,
            reputation: target.reputation || 50,
            atWar: this.isAtWar(kid, targetKid)
        };
    },

    propaganda(kid, targetKid, delta) {
        return this.modifyRelation(kid, targetKid, delta, "propaganda");
    },

    ceasefire(kidA, kidB, durationMs = 30 * 60 * 1000) {
        if (!this.isAtWar(kidA, kidB)) return false;
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        d.diplomacy.ceasefires[key] = { endTime: Date.now() + durationMs };
        Core.Database.markDirty("krallik_core");
        return true;
    },

    isCeasefireActive(kidA, kidB) {
        const d = Core.Database.load();
        this._ensureRoots(d);
        const key = this._getKey(kidA, kidB);
        const cf = d.diplomacy.ceasefires?.[key];
        return !!(cf && cf.endTime > Date.now());
    },

    endWar(kidA, kidB, kazananKid = null) {
        const result = this.makePeace(kidA, kidB, "admin_end");
        if (result && kazananKid) {
            const d = Core.Database.load();
            const k = d.kralliklar?.[kazananKid];
            if (k) {
                k.warScore = (k.warScore || 0) + 50;
                k.zaferCount = (k.zaferCount || 0) + 1;
                Core.Database.markDirty("krallik_core");
            }
        }
        return result;
    }
};

export const Vassal = {
    _data() {
        const d = Core.Database.load();
        if (!d.vasallar) d.vasallar = {};
        return d.vasallar;
    },

    teklifEt(vasilKid, lordKid) {
        const d = Core.Database.load();
        if (!d.kralliklar?.[vasilKid] || !d.kralliklar?.[lordKid]) return { ok: false, msg: "Krallık bulunamadı." };
        if (vasilKid === lordKid) return { ok: false, msg: "Kendine vasal olamazsın." };
        if (this.getLord(vasilKid)) return { ok: false, msg: "Zaten bir efendiye bağlısın." };
        if (this.getVasallar(lordKid).includes(vasilKid)) return { ok: false, msg: "Zaten vasalın." };
        if (Diplomacy.isAtWar(vasilKid, lordKid)) return { ok: false, msg: "Savaş halindeyken vasal olunamaz." };

        const vs = this._data();
        vs[vasilKid] = { lordKid, haracOrani: 0.20, baslangic: Date.now(), onayBekliyor: true };
        Core.Database.markDirty("krallik_core");

        Core.KrallikBildirim?.gonder?.(lordKid, `§e👑 ${d.kralliklar[vasilKid].isim} vasal olmak istiyor! Diplomasi > Vasal menüsünden yanıtla.`);
        return { ok: true, msg: `${d.kralliklar[lordKid].isim}'e vasal teklifi gönderildi.` };
    },

    kabul(lordKid, vasilKid) {
        const vs = this._data();
        const kayit = vs[vasilKid];
        if (!kayit || kayit.lordKid !== lordKid || !kayit.onayBekliyor) return { ok: false, msg: "Bekleyen teklif yok." };
        kayit.onayBekliyor = false;
        Core.Database.markDirty("krallik_core");
        const d = Core.Database.load();
        Core.KrallikBildirim?.gonder?.(vasilKid, `§a👑 ${d.kralliklar[lordKid].isim} vasal teklifinizi kabul etti!`);
        Systems.broadcastToKrallik(vasilKid, `§6👑 ${d.kralliklar[vasilKid].isim} §f→ §6${d.kralliklar[lordKid].isim} §fvasalı oldu.`);
        return { ok: true, msg: "Vasal ilişkisi kuruldu." };
    },

    reddet(lordKid, vasilKid) {
        const vs = this._data();
        if (vs[vasilKid]?.lordKid !== lordKid) return { ok: false, msg: "Teklif bulunamadı." };
        delete vs[vasilKid];
        Core.Database.markDirty("krallik_core");
        const d = Core.Database.load();
        Core.KrallikBildirim?.gonder?.(vasilKid, `§c👑 ${d.kralliklar[lordKid].isim} vasal teklifinizi reddetti.`);
        return { ok: true, msg: "Teklif reddedildi." };
    },

    isyan(vasilKid) {
        const vs = this._data();
        const kayit = vs[vasilKid];
        if (!kayit || kayit.onayBekliyor) return { ok: false, msg: "Vasal ilişkisi yok." };
        const lordKid = kayit.lordKid;
        delete vs[vasilKid];
        Core.Database.markDirty("krallik_core");
        try { Diplomacy.declareWar(vasilKid, lordKid); } catch(e) {}
        const d = Core.Database.load();
        Systems.broadcastToKrallik(vasilKid, `§c🗡️ ${d.kralliklar[vasilKid]?.isim} efendisi §f${d.kralliklar[lordKid]?.isim}§c'e isyan etti!`);
        return { ok: true, msg: "İsyan başladı! Efendinizle savaşa girdiniz." };
    },

    azat(lordKid, vasilKid) {
        const vs = this._data();
        if (vs[vasilKid]?.lordKid !== lordKid) return { ok: false, msg: "Bu krallığın efendisi değilsin." };
        delete vs[vasilKid];
        Core.Database.markDirty("krallik_core");
        const d = Core.Database.load();
        Core.KrallikBildirim?.gonder?.(vasilKid, `§e👑 ${d.kralliklar[lordKid]?.isim} sizi serbest bıraktı.`);
        return { ok: true, msg: `${d.kralliklar[vasilKid]?.isim} azat edildi.` };
    },

    getLord(kid) {
        const vs = this._data();
        const k = vs[kid];
        return (k && !k.onayBekliyor) ? k.lordKid : null;
    },

    getVasallar(lordKid) {
        const vs = this._data();
        return Object.entries(vs).filter(([, v]) => v.lordKid === lordKid && !v.onayBekliyor).map(([kid]) => kid);
    },

    getBekleyenTeklifler(lordKid) {
        const vs = this._data();
        return Object.entries(vs).filter(([, v]) => v.lordKid === lordKid && v.onayBekliyor).map(([kid, v]) => ({ kid, ...v }));
    },

    savasIzniVarMi(kid, hedefKid) {
        const lordKid = this.getLord(kid);
        if (!lordKid) return true;
        if (Diplomacy.isAtWar(lordKid, hedefKid)) return true;
        return false;
    },

    haracTick() {
        const vs = this._data();
        const d = Core.Database.load();
        let dirty = false;
        for (const [vasilKid, kayit] of Object.entries(vs)) {
            if (kayit.onayBekliyor) continue;
            const vasal = d.kralliklar?.[vasilKid];
            const lord = d.kralliklar?.[kayit.lordKid];
            if (!vasal || !lord) { delete vs[vasilKid]; dirty = true; continue; }
            const harac = Math.floor((vasal.gelir || 0) * (kayit.haracOrani || 0.20));
            if (harac <= 0) continue;
            vasal.hazine = Math.max(-5000, (vasal.hazine || 0) - harac);
            lord.hazine = (lord.hazine || 0) + harac;
            dirty = true;
        }
        if (dirty) Core.Database.markDirty("krallik_core");
    },

    efendiSavasIlanında(lordKid, hedefKid) {
        for (const vasilKid of this.getVasallar(lordKid)) {
            try {
                if (!Diplomacy.isAtWar(vasilKid, hedefKid)) {
                    Diplomacy.declareWar(vasilKid, hedefKid);
                    const d = Core.Database.load();
                    Core.KrallikBildirim?.gonder?.(vasilKid, `§c⚔️ Efendiniz ${d.kralliklar[lordKid]?.isim} savaşa girdi — siz de savaştasınız!`);
                }
            } catch(e) {}
        }
    }
};

export const Hero = {
    MALIYET: 25000,
    BONUS_RANGE: 10,

    TIPLER: {
        warlord: { id: "warlord", name: "Savaş Lordu", emoji: "⚔️", desc: "Yanındaki askerlere +%20 hasar", entity: "minecraft:villager_v2" },
        architect: { id: "architect", name: "Mimar", emoji: "🏗️", desc: "Claim yükseltme maliyeti -%15", entity: "minecraft:villager_v2" },
        spymaster: { id: "spymaster", name: "Casus Şefi", emoji: "🕵️", desc: "+50% görüş mesafesi", entity: "minecraft:villager_v2" }
    },

    _data() {
        const d = Core.Database.load();
        if (!d.kahramanlar) d.kahramanlar = {};
        return d.kahramanlar;
    },

    getHero(kid) { return this._data()[kid] || null; },

    buyHero(player, tip) {
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return { ok: false, msg: "Bir krallığa ait değilsin." };
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return { ok: false, msg: "Krallık bulunamadı." };
        if (k.lider !== player.name) return { ok: false, msg: "Sadece kral kahraman satın alabilir." };

        const heroData = this._data();
        if (heroData[kid]?.alive) return { ok: false, msg: "Zaten aktif bir kahramanın var." };

        if ((k.hazine || 0) < this.MALIYET) return { ok: false, msg: `Yetersiz hazine. Gerekli: ${this.MALIYET} ZMC` };
        const tipDef = this.TIPLER[tip];
        if (!tipDef) return { ok: false, msg: "Geçersiz kahraman tipi." };

        const claims = Core.Database.getClaimler(kid);
        const loc = claims.length ? { x: claims[0].x, y: 64, z: claims[0].z } : { x: player.location.x, y: player.location.y, z: player.location.z };

        let entity = null;
        try {
            entity = player.dimension.spawnEntity(tipDef.entity, loc);
            Systems.addTag(entity, `krallik_${kid}`);
            Systems.addTag(entity, "kahraman");
            Systems.addTag(entity, `hero_${tip}`);
        } catch(e) {
            return { ok: false, msg: "Entity spawn başarısız." };
        }

        k.hazine -= this.MALIYET;
        heroData[kid] = { tip, entityId: entity.id, alive: true, satinAlinma: Date.now(), istatistik: { savas: 0, bonus: 0 } };
        Core.Database.markDirty("krallik_core");
        Systems.broadcastToKrallik(kid, `§6🦸 ${k.isim} yeni kahramanı ${tipDef.emoji} ${tipDef.name}'i aldı!`);
        return { ok: true, msg: `${tipDef.name} satın alındı!` };
    },

    onHeroDeath(entityId) {
        const heroes = this._data();
        for (const [kid, h] of Object.entries(heroes)) {
            if (h.entityId === entityId && h.alive) {
                h.alive = false;
                Core.Database.markDirty("krallik_core");
                const d = Core.Database.load();
                Core.KrallikBildirim?.gonder?.(kid, `§c☠ Kahramanın öldü! Yeni kahraman satın alabilirsin.`);
                Systems.broadcastToKrallik(kid, `§c☠ ${d.kralliklar?.[kid]?.isim || kid} krallığının kahramanı yenildi!`);
                return true;
            }
        }
        return false;
    },

    applyBonuses() {
        const heroes = this._data();
        const d = Core.Database.load();
        for (const [kid, hero] of Object.entries(heroes)) {
            if (!hero.alive) continue;
            if (hero.tip !== "warlord") continue;

            try {
                const entities = Core.Cache?.getKrallikEntities?.(kid) || [];
                const kahraman = entities.find(e => (e.getTags?.() || []).includes("kahraman"));

                if (!kahraman || !Core.Cache?.isValidEntity?.(kahraman)) {
                    for (const e of entities) {
                        try {
                            if ((e.getTags?.() || []).includes("hero_bonus")) Systems.removeTag(e, "hero_bonus");
                        } catch(e) {}
                    }
                    continue;
                }

                const kLoc = kahraman.location;
                const yakin = new Set();
                const uzak = [];

                for (const e of entities) {
                    if (!Core.Cache?.isValidEntity?.(e)) continue;
                    const tags = e.getTags?.() || [];
                    if (tags.includes("kahraman")) continue;
                    if (!tags.some(t => t.startsWith("asker_"))) continue;
                    const el = e.location;
                    const dx = el.x - kLoc.x, dz = el.z - kLoc.z;
                    if (Math.sqrt(dx*dx + dz*dz) <= this.BONUS_RANGE) {
                        yakin.add(e);
                    } else {
                        uzak.push(e);
                    }
                }

                for (const e of yakin) {
                    if (!(e.getTags?.() || []).includes("hero_bonus")) Systems.addTag(e, "hero_bonus");
                }
                for (const e of uzak) {
                    try {
                        if ((e.getTags?.() || []).includes("hero_bonus")) Systems.removeTag(e, "hero_bonus");
                    } catch(e) {}
                }
                hero.istatistik.bonus = (hero.istatistik.bonus || 0) + yakin.size;
            } catch(e) {}
        }
    },

    getUpgradeDiscount(kid) {
        const h = this.getHero(kid);
        return (h?.alive && h?.tip === "architect") ? 0.15 : 0;
    }
};

export const KrallikBildirim = {
    sendKrallik(kid, msg, meta = {}) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return false;
        k.bildirimler = k.bildirimler || [];
        if (!Array.isArray(k.bildirimler)) k.bildirimler = [];
        k.bildirimler.unshift({ t: Date.now(), msg, meta });
        if (k.bildirimler.length > 50) k.bildirimler.length = 50;
        Systems.broadcastToKrallik(kid, msg);
        Core.Database.markDirty("krallik_core");
        return true;
    },

    sendOyuncu(playerName, msg, meta = {}) {
        const p = world.getAllPlayers().find(x => x.name === playerName);
        if (p) Systems.sendMessage(p, msg);
        const prof = Core.Profile?.getProfile?.(playerName) || {};
        prof.bildirimler = prof.bildirimler || [];
        prof.bildirimler.unshift({ t: Date.now(), msg, meta });
        if (prof.bildirimler.length > 50) prof.bildirimler.length = 50;
        Core.Database.markDirty("krallik_profiles");
        return true;
    },

    gonder(kid, msg, meta = {}) { return this.sendKrallik(kid, msg, meta); }
};