// ============================================================
// MODÜL 06: KRALLIK YÖNETİMİ - Krallık, Profil, Liderlik, Haberler, Admin (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { MessageFormData, ModalFormData, ActionFormData } from "@minecraft/server-ui";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager } from "./02_claim.js";
import { Systems, AI, Morale } from "./04_military.js";
import { Diplomacy } from "./05_diplomacy.js";

export const KrallikYonetim = {
    kur(player, isim, aciklama, renkIndex, ulkeIndex) {
        if (!Core.RateLimiter.isAllowed(player, "krallik_kur", 1, 10000)) {
            Systems.sendMessage(player, "§cÇok hızlı! Lütfen bekle.");
            return false;
        }
        if (Systems.getZMC(player) < 500) { Systems.sendMessage(player, "§cYetersiz ZMC! (500 gerekli)"); return false; }
        const d = Core.Database.load();
        if (d.oyuncular[player.name]) { Systems.sendMessage(player, "§cZaten bir krallıktasınız!"); return false; }
        if (!isim?.trim() || isim.trim().length < 2) { Systems.sendMessage(player, "§cKrallık adı en az 2 karakter olmalı!"); return false; }

        const renkler = ["§c", "§9", "§a", "§e", "§5", "§6", "§f", "§8"];
        const ulkeKeys = Object.keys(Config.ULKELER);

        Systems.removeZMC(player, 500);
        const kid = "k_" + Date.now();
        const sv = Config.SEVIYE_GEREKLERI[0];
        const ulke = ulkeKeys[ulkeIndex] || "british";

        d.kralliklar[kid] = {
            id: kid, isim: renkler[renkIndex] + isim.trim(), aciklama: aciklama || "",
            lider: player.name, ulkeTipi: ulke, renk: renkler[renkIndex],
            seviye: 1, hazine: 0, gelir: 0, moral: 60,
            uyeler: [player.name], yardimcilar: [], roller: { [player.name]: "kral" },
            savaslar: [], muttefikler: [], maxToprak: sv.maxToprak,
            askerLimiti: sv.askerLimiti, maxYardimci: sv.maxYardimci,
            toplamKill: 0, reputation: 50, diplomaticPower: 10,
            trustLevels: {}, treaties: {}, vasallar: [], harac: {},
            warScore: 0, totalPower: 0, status: "baris",
            gelisimAgaci: { askeri: 0, ekonomi: 0, savunma: 0, diplomasi: 0 },
            eventleri: {}, alarmSeviyesi: 0, kralOldu: false, intikamModu: false,
            marketSales: 0, kusatmaCount: 0, zaferCount: 0, maglubiyetCount: 0
        };
        d.oyuncular[player.name] = kid;
        if (!d.diplomacy) d.diplomacy = { relations: {}, wars: {}, alliances: {}, treaties: {}, tradeAgreements: {}, embargoes: {}, ceasefires: {} };
        if (!d.diplomacy.relations[kid]) d.diplomacy.relations[kid] = {};
        Core.Database._bindHazineToZmc(d.kralliklar[kid]);
        Core.Database.markDirty("krallik_core");
        Core.Database.save(true);
        Core.Cache?.invalidateProfileCache?.(player.name);
        Core.Profile?.initializeProfile?.(player.name);
        Core.Logger?.info?.("krallik", `Krallık kuruldu: ${isim}`, { actor: player.name, krallik: kid });
        Core.News?.addNews?.("krallik", `${renkler[renkIndex]}${isim} §fkrallığı kuruldu!`, { kurucu: player.name });
        Systems.sendMessage(player, `§a✔ ${renkler[renkIndex]}${isim} §fkrallığı kuruldu! 🏰`);
        return true;
    },

    katil(player, krallikId) {
        const d = Core.Database.load();
        const k = d.kralliklar[krallikId];
        if (!k) return false;
        if (d.oyuncular[player.name]) { Systems.sendMessage(player, "§cZaten bir krallıktasınız!"); return false; }
        k.uyeler.push(player.name);
        k.roller[player.name] = "uye";
        d.oyuncular[player.name] = krallikId;
        Core.Database.markDirty("krallik_core");
        Core.Cache?.invalidateProfileCache?.(player.name);
        return true;
    },

    seviyeAtla(krallikId, callerPlayer = null) {
        if (callerPlayer && !Core.RateLimiter.isAllowed(callerPlayer, "seviye_atla", 1, 5000)) {
            Systems.sendMessage(callerPlayer, "§cÇok hızlı! Lütfen bekle.");
            return false;
        }
        const d = Core.Database.load();
        const k = d.kralliklar[krallikId];
        if (!k) return false;
        const yeni = (k.seviye || 1) + 1;
        if (yeni > Config.SEVIYE_GEREKLERI.length) return false;
        const sv = Config.SEVIYE_GEREKLERI[yeni - 1];
        if ((k.hazine || 0) < sv.seviyeUcreti) return false;
        k.hazine -= sv.seviyeUcreti;
        k.seviye = yeni;
        k.askerLimiti = sv.askerLimiti;
        k.maxToprak = sv.maxToprak;
        k.maxYardimci = sv.maxYardimci;
        Core.Database.markDirty("krallik_core");
        return yeni;
    },

    dagil(kid, sebep = "manual") {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return false;

        const uyeler = Array.isArray(k.uyeler) ? [...k.uyeler] : [];
        for (const u of uyeler) {
            if (d.oyuncular?.[u] === kid) delete d.oyuncular[u];
            try { Core.Cache?.invalidateProfileCache?.(u); } catch(e) {}
        }

        try {
            for (const [cid, c] of Object.entries(d.claimler || {})) {
                if (c?.krallik === kid) {
                    if (d.sieges?.[cid]) delete d.sieges[cid];
                    if (c.contested) { c.contested = false; c.contestedBy = null; c.siegeProgress = 0; }
                    try { ClaimManager.removeAllSignsForClaim?.(cid); } catch(e) {}
                    delete d.claimler[cid];
                }
            }
            for (const [sid, s] of Object.entries(d.sieges || {})) {
                if (s?.attackerId === kid || s?.defenderId === kid) {
                    const targetClaim = d.claimler?.[s.claimId];
                    if (targetClaim) { targetClaim.contested = false; targetClaim.contestedBy = null; targetClaim.siegeProgress = 0; }
                    delete d.sieges[sid];
                }
            }
        } catch(e) {}

        try {
            for (const [a, map] of Object.entries(d.treaties || {})) {
                if (map && typeof map === "object") delete map[kid];
            }
            delete d.treaties?.[kid];
        } catch(e) {}

        delete d.kralliklar[kid];
        Core.Database.markDirty("krallik_core");
        Core.Database.markDirty("krallik_claims");
        try { Core.Cache?.invalidateClaimCache?.(); } catch(e) {}

        Core.Logger?.info?.("yonetim", `Krallık dağıtıldı: ${kid} (sebep=${sebep})`, { actor: "system", krallik: kid });
        Systems.broadcastToKrallik(kid, `§c☠ Krallık dağıtıldı: §f${k.isim || kid} §7(sebep: ${sebep})`);
        return true;
    },

    transferLiderlik(kid, yeniLider) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return false;
        k.lider = yeniLider;
        if (!k.uyeler?.includes(yeniLider)) (k.uyeler = k.uyeler || []).push(yeniLider);
        k.roller = k.roller || {};
        k.roller[yeniLider] = "kral";
        Core.LogSistemi?.log?.("yonetim", `Liderlik transfer edildi: ${kid} → ${yeniLider}`, { actor: "system", target: yeniLider });
        Core.Database.markDirty("krallik_core");
        return true;
    },

    dagilmaOylamasiBaslat(kid, baslatan, sureMs = 10 * 60 * 1000) {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        k.dagilmaOylamasi = { start: Date.now(), end: Date.now() + sureMs, yes: [], no: [], startedBy: baslatan };
        Core.Database.markDirty("krallik_core");
        KrallikBildirim.sendKrallik(kid, "§e🗳️ Krallık dağılma oylaması başladı!");
        return true;
    },

    dagilmaOyuVer(kid, oyuncu, oy) {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k?.dagilmaOylamasi) return false;
        const o = k.dagilmaOylamasi;
        o.yes = (o.yes || []).filter(x => x !== oyuncu);
        o.no = (o.no || []).filter(x => x !== oyuncu);
        if (oy === true) o.yes.push(oyuncu); else o.no.push(oyuncu);
        Core.Database.markDirty("krallik_core");
        return true;
    },

    dagilmaOylamasiSonuclandir(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k?.dagilmaOylamasi) return { ok: false };
        const o = k.dagilmaOylamasi;
        if (Date.now() < o.end) return { ok: false, reason: "sure" };
        const uyeSayisi = (k.uyeler || []).length || 1;
        const yes = (o.yes || []).length;
        const passed = yes >= Math.ceil(uyeSayisi * 0.6);
        delete k.dagilmaOylamasi;
        Core.Database.markDirty("krallik_core");
        if (passed) {
            this.dagil(kid, "oylama");
            return { ok: true, passed: true };
        }
        KrallikBildirim.sendKrallik(kid, "§aOylama başarısız; krallık dağılmadı.");
        return { ok: true, passed: false };
    },

    mirasBelirle(kid, varis) {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        k.varis = varis;
        Core.Database.markDirty("krallik_core");
        return true;
    },

    mirasUygulaEgerGerekli(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return false;
        const liderOnline = world.getAllPlayers().some(p => p.name === k.lider);
        if (liderOnline) return false;
        if (k.varis && (k.uyeler || []).includes(k.varis)) {
            return this.transferLiderlik(kid, k.varis);
        }
        const hedef = (k.yardimcilar || [])[0] || (k.uyeler || [])[0];
        if (hedef) return this.transferLiderlik(kid, hedef);
        return false;
    },

    logFiltrele({ kategori = null, actor = null, target = null, level = null, since = 0, search = null, limit = 100 } = {}) {
        const d = Core.Database.load();
        const list = (d.logs || []).slice(0, 500);
        return list.filter(l => {
            if (kategori && l.category !== kategori) return false;
            if (actor && l.actor !== actor) return false;
            if (target && l.target !== target) return false;
            if (level && l.level !== level) return false;
            if (since && l.timestamp < since) return false;
            if (search && !(l.message || "").toLowerCase().includes(search.toLowerCase())) return false;
            return true;
        }).slice(0, limit);
    },

    savasSonucuKaydet(kid, sonuc) {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        if (sonuc === "zafer") k.zaferCount = (k.zaferCount || 0) + 1;
        if (sonuc === "maglubiyet") k.maglubiyetCount = (k.maglubiyetCount || 0) + 1;
        Core.Database.markDirty("krallik_core");
        return true;
    },

    rozetEkle(kid, rozetId) {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        k.rozetler = k.rozetler || [];
        if (!k.rozetler.includes(rozetId)) k.rozetler.push(rozetId);
        Core.Database.markDirty("krallik_core");
        return true;
    },

    unvanAyarla(kid, unvan) {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        k.unvan = unvan;
        Core.Database.markDirty("krallik_core");
        return true;
    },

    aiValiAyarla(kid, aktif, ayarlar = {}) {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        k.aiVali = { aktif: !!aktif, ayarlar: ayarlar || {} };
        Core.Database.markDirty("krallik_core");
        return true;
    },

    stratejikHarita(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return null;
        const claimler = Core.Database.getClaimler(kid);
        const merkez = claimler[0] ? { x: claimler[0].x, z: claimler[0].z } : null;
        return {
            kid, isim: k.isim,
            claimSayisi: claimler.length,
            merkez,
            komsuClaimler: Core.ClaimHarita?.komsulariGetir ? Core.ClaimHarita.komsulariGetir(kid) : []
        };
    },

    diplomatikPuanEkle(kid, miktar, sebep = "sistem") {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        k.diplomaticPower = (k.diplomaticPower || 0) + (miktar || 0);
        Core.LogSistemi?.log?.("diplomasi", `Diplomatik puan: ${miktar} (${sebep})`, { target: kid });
        Core.Database.markDirty("krallik_core");
        return true;
    },

    diplomatikPuanHarca(kid, miktar, sebep = "islem") {
        const k = Core.Database.load().kralliklar?.[kid];
        if (!k) return false;
        if ((k.diplomaticPower || 0) < miktar) return false;
        k.diplomaticPower -= miktar;
        Core.Database.markDirty("krallik_core");
        return true;
    },

    ekonomikRapor(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return null;
        return {
            kid, isim: k.isim,
            hazine: k.hazine || 0,
            gelir: k.gelir || 0,
            marketSales: k.marketSales || 0,
            butce: k.butce || { gelirHedef: 0, giderLimit: 0, notlar: "" },
            sonKriz: k.ekonomikKriz || null
        };
    },

    askeriRapor(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return null;
        const askerCount = Core.Cache?.getKrallikEntityCount?.(kid) || 0;
        return {
            kid, isim: k.isim,
            askerCount,
            askerLimiti: k.askerLimiti || 0,
            moral: k.moral || 0,
            toplamKill: k.toplamKill || 0
        };
    },

    uyeAt(kid, uyeAdi) {
        const d = Core.Database.load();
        const k = d.kralliklar?.[kid];
        if (!k) return false;
        if (k.lider === uyeAdi) return false;
        k.uyeler = (k.uyeler || []).filter(u => u !== uyeAdi);
        if (k.roller) delete k.roller[uyeAdi];
        if (d.oyuncular?.[uyeAdi] === kid) delete d.oyuncular[uyeAdi];
        Core.Database.markDirty("krallik_core");
        Core.Cache?.invalidateProfileCache?.(uyeAdi);
        return true;
    }
};

export const Profile = {
    initializeProfile(playerName) {
        const d = Core.Database.load();
        if (!d.profiles) d.profiles = {};
        if (!d.profiles[playerName]) {
            d.profiles[playerName] = {
                name: playerName,
                kill: 0, death: 0, askerOldurme: 0, claimSayisi: 0,
                savasSayisi: 0, kazanc: 0, marketHarcama: 0, itibar: 50,
                onlineSure: 0, guc: 0, kusatmaSayisi: 0,
                zaferSayisi: 0, maglubiyetSayisi: 0, liderlikSuresi: 0,
                enGucluAsker: null, toplamAsker: 0, ekonomiPuani: 0,
                dunyaSiralamasi: 0, rozet: null, unvan: null, biyografi: "",
                gizlilikAyarlari: {
                    kill: true, death: true, askerOldurme: true,
                    kazanc: true, marketHarcama: true, onlineSure: true,
                    guc: true, kdOrani: true, biyografi: true
                },
                renkTemasi: "default",
                badges: [],
                theme: "default",
                background: null,
                settings: {},
                privacyLevel: "herkes",
                signature: "",
                friends: [],
                blocked: [],
                reports: [],
                createdAt: Date.now()
            };
            Core.Database.markDirty("krallik_profiles");
        }
        return d.profiles[playerName];
    },

    getProfile(playerName) {
        const d = Core.Database.load();
        if (!d.profiles?.[playerName]) return this.initializeProfile(playerName);
        return d.profiles[playerName];
    },

    updateStat(playerName, stat, value) {
        const profile = this.getProfile(playerName);
        if (profile[stat] !== undefined) {
            profile[stat] += value;
            Core.Database.markDirty("krallik_profiles");
            Core.Cache?.invalidateProfileCache?.(playerName);
        }
    },

    setStat(playerName, stat, value) {
        const profile = this.getProfile(playerName);
        profile[stat] = value;
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
    },

    getKD(playerName) {
        const profile = this.getProfile(playerName);
        if (profile.death === 0) return profile.kill;
        return (profile.kill / profile.death).toFixed(2);
    },

    updateGizlilik(playerName, ayarlar) {
        const profile = this.getProfile(playerName);
        Object.assign(profile.gizlilikAyarlari, ayarlar);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
    },

    setUnvan(playerName, unvan) {
        const profile = this.getProfile(playerName);
        profile.unvan = unvan;
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
    },

    setBiyografi(playerName, biyografi) {
        const profile = this.getProfile(playerName);
        profile.biyografi = biyografi;
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
    },

    setRenkTemasi(playerName, tema) {
        const profile = this.getProfile(playerName);
        profile.renkTemasi = tema;
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
    },

    addBadge(playerName, badgeId) {
        const profile = this.getProfile(playerName);
        if (!profile.badges) profile.badges = [];
        if (!profile.badges.includes(badgeId)) profile.badges.push(badgeId);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    removeBadge(playerName, badgeId) {
        const profile = this.getProfile(playerName);
        if (profile.badges) profile.badges = profile.badges.filter(b => b !== badgeId);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    getBadges(playerName) {
        const profile = this.getProfile(playerName);
        return profile.badges || [];
    },

    setTheme(playerName, themeId) {
        const profile = this.getProfile(playerName);
        profile.theme = themeId;
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    getTheme(playerName) {
        const profile = this.getProfile(playerName);
        return profile.theme || "default";
    },

    setBackground(playerName, bgUrl) {
        const profile = this.getProfile(playerName);
        profile.background = bgUrl;
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    getBackground(playerName) {
        const profile = this.getProfile(playerName);
        return profile.background || null;
    },

    setSetting(playerName, key, value) {
        const profile = this.getProfile(playerName);
        if (!profile.settings) profile.settings = {};
        profile.settings[key] = value;
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    getSetting(playerName, key, defaultValue = null) {
        const profile = this.getProfile(playerName);
        return profile.settings?.[key] ?? defaultValue;
    },

    getAllSettings(playerName) {
        const profile = this.getProfile(playerName);
        return profile.settings || {};
    },

    setPrivacyLevel(playerName, level) {
        const profile = this.getProfile(playerName);
        profile.privacyLevel = level;
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    getPrivacyLevel(playerName) {
        const profile = this.getProfile(playerName);
        return profile.privacyLevel || "herkes";
    },

    setSignature(playerName, signature) {
        const profile = this.getProfile(playerName);
        profile.signature = String(signature || "").slice(0, 120);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    getSignature(playerName) {
        const profile = this.getProfile(playerName);
        return profile.signature || "";
    },

    addFriend(playerName, friendName) {
        if (playerName === friendName) return false;
        const profile = this.getProfile(playerName);
        if (!profile.friends) profile.friends = [];
        if (!profile.friends.includes(friendName)) profile.friends.push(friendName);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    removeFriend(playerName, friendName) {
        const profile = this.getProfile(playerName);
        if (profile.friends) profile.friends = profile.friends.filter(f => f !== friendName);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    getFriends(playerName) {
        const profile = this.getProfile(playerName);
        return profile.friends || [];
    },

    areFriends(playerName, otherName) {
        const profile = this.getProfile(playerName);
        return (profile.friends || []).includes(otherName);
    },

    blockPlayer(playerName, blockedName) {
        const profile = this.getProfile(playerName);
        if (!profile.blocked) profile.blocked = [];
        if (!profile.blocked.includes(blockedName)) profile.blocked.push(blockedName);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    unblockPlayer(playerName, blockedName) {
        const profile = this.getProfile(playerName);
        if (profile.blocked) profile.blocked = profile.blocked.filter(b => b !== blockedName);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return true;
    },

    isBlocked(playerName, targetName) {
        const profile = this.getProfile(playerName);
        return (profile.blocked || []).includes(targetName);
    },

    getBlockedList(playerName) {
        const profile = this.getProfile(playerName);
        return profile.blocked || [];
    },

    addOnlineTime(playerName, seconds) {
        const profile = this.getProfile(playerName);
        profile.onlineSure = (profile.onlineSure || 0) + seconds;
        Core.Leaderboard?.recordPlayerStat?.(playerName, "onlineSure", seconds);
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
    },

    addReputation(playerName, delta) {
        const profile = this.getProfile(playerName);
        profile.itibar = Math.max(0, Math.min(100, (profile.itibar || 50) + delta));
        Core.Database.markDirty("krallik_profiles");
        Core.Cache?.invalidateProfileCache?.(playerName);
        return profile.itibar;
    },

    getReputation(playerName) {
        const profile = this.getProfile(playerName);
        return profile.itibar || 50;
    },

    reportPlayer(reporterName, targetName, reason) {
        const d = Core.Database.load();
        if (!d.reports) d.reports = [];
        d.reports.unshift({ timestamp: Date.now(), reporter: reporterName, target: targetName, reason: reason, status: "pending" });
        if (d.reports.length > 200) d.reports.length = 200;
        Core.Database.markDirty("krallik_admin");
        Core.LogSistemi?.log?.("admin", `${reporterName} rapor etti: ${targetName} - ${reason}`);
        return true;
    },

    getReports(status = null, limit = 50) {
        const d = Core.Database.load();
        let reports = d.reports || [];
        if (status) reports = reports.filter(r => r.status === status);
        return reports.slice(0, limit);
    },

    resolveReport(reportIndex, resolvedBy, action) {
        const d = Core.Database.load();
        const reports = d.reports || [];
        if (reports[reportIndex]) {
            reports[reportIndex].status = "resolved";
            reports[reportIndex].resolvedBy = resolvedBy;
            reports[reportIndex].resolvedAt = Date.now();
            reports[reportIndex].action = action;
            Core.Database.markDirty("krallik_admin");
            return true;
        }
        return false;
    },

    formatProfileForDisplay(playerName, isOwner = false) {
        const profile = this.getProfile(playerName);
        const gizlilik = profile.gizlilikAyarlari || {};
        const formatValue = (key, value) => { if (isOwner) return value; return gizlilik[key] ? value : "§7Gizli"; };
        return {
            name: profile.name,
            unvan: profile.unvan || "Yok",
            kill: formatValue("kill", profile.kill),
            death: formatValue("death", profile.death),
            kd: formatValue("kdOrani", this.getKD(playerName)),
            askerOldurme: formatValue("askerOldurme", profile.askerOldurme),
            kazanc: formatValue("kazanc", `${profile.kazanc.toLocaleString()} ZMC`),
            marketHarcama: formatValue("marketHarcama", `${profile.marketHarcama.toLocaleString()} ZMC`),
            onlineSure: formatValue("onlineSure", `${Math.floor(profile.onlineSure / 3600)} saat`),
            guc: formatValue("guc", Core.Power?.formatPower?.(profile.guc) || profile.guc),
            biyografi: isOwner ? (profile.biyografi || "Biyografi yok") : (gizlilik.biyografi ? (profile.biyografi || "Biyografi yok") : "§7Gizli"),
            rozet: profile.rozet || "Yok",
            renkTemasi: profile.renkTemasi
        };
    }
};

export const Leaderboard = {
    _weekKey() {
        const dt = new Date();
        const year = dt.getFullYear();
        const onejan = new Date(year, 0, 1);
        const ms = dt - onejan;
        const day = Math.floor(ms / 86400000) + 1;
        const week = Math.ceil(day / 7);
        return `${year}W${String(week).padStart(2, "0")}`;
    },
    _monthKey() { const t = new Date(); return `${t.getFullYear()}M${String(t.getMonth() + 1).padStart(2, "0")}`; },
    _seasonKey() { const t = new Date(); const q = Math.floor(t.getMonth() / 3) + 1; return `${t.getFullYear()}S${q}`; },

    _resetIfNeeded() {
        const d = Core.Database.load();
        if (!d.leaderboardMeta) d.leaderboardMeta = { week: null, month: null, season: null };
        const wk = this._weekKey(), mk = this._monthKey(), sk = this._seasonKey();
        let changed = false;
        if (d.leaderboardMeta.week !== wk) { d.leaderboard.weekly = {}; d.leaderboardMeta.week = wk; changed = true; }
        if (d.leaderboardMeta.month !== mk) { d.leaderboard.monthly = {}; d.leaderboardMeta.month = mk; changed = true; }
        if (d.leaderboardMeta.season !== sk) { d.leaderboard.season = {}; d.leaderboardMeta.season = sk; changed = true; }
        if (changed) Core.Database.markDirty("krallik_leaderboard");
    },

    calculateAll() {
        try {
            const d = Core.Database.load();
            const results = {};
            for (const kategori of (Config.LEADERBOARD_KATEGORILERI || [])) {
                try { results[kategori.id] = this._calculateCategory(kategori); } catch(e) { results[kategori.id] = []; }
            }
            if (!d.leaderboard) d.leaderboard = { data: {}, weekly: {}, monthly: {}, season: {}, players: {}, kingdoms: {}, lastUpdate: 0 };
            d.leaderboard.data = results;
            d.leaderboard.lastUpdate = Date.now();
            Core.Database.markDirty("krallik_leaderboard");
            return results;
        } catch(e) { return {}; }
    },

    _calculateCategory(kategori) {
        const d = Core.Database.load();
        const sirala = [];
        for (const [kid, k] of Object.entries(d.kralliklar || {})) {
            let value = 0;
            switch (kategori.field) {
                case "totalPower": value = k.totalPower || 0; break;
                case "hazine": value = k.hazine || 0; break;
                case "warScore": value = k.warScore || 0; break;
                case "claimCount": value = Core.Database.getClaimler(kid).length; break;
                case "askerCount": value = Core.Cache?.getKrallikEntityCount?.(kid) || 0; break;
                case "reputation": value = k.reputation || 0; break;
                case "gelir": value = k.gelir || 0; break;
                case "marketSales": value = k.marketSales || 0; break;
                case "seviye": value = k.seviye || 1; break;
                case "kusatmaCount": value = k.kusatmaCount || 0; break;
            }
            sirala.push({ id: kid, name: k.isim, value, leader: k.lider });
        }
        sirala.sort((a, b) => b.value - a.value);
        return sirala.slice(0, 20);
    },

    getCategory(kategoriId) {
        try { return Core.Cache?.getLeaderboardCache?.()?.data?.[kategoriId] || []; } catch(e) { return []; }
    },

    recordKingdomStat(kid, field, value) {
        this._resetIfNeeded();
        const d = Core.Database.load();
        if (!d.leaderboard.weekly[kid]) d.leaderboard.weekly[kid] = {};
        if (!d.leaderboard.monthly[kid]) d.leaderboard.monthly[kid] = {};
        if (!d.leaderboard.season[kid]) d.leaderboard.season[kid] = {};
        d.leaderboard.weekly[kid][field] = value;
        d.leaderboard.monthly[kid][field] = value;
        d.leaderboard.season[kid][field] = value;
        Core.Database.markDirty("krallik_leaderboard");
    },

    recordPlayerStat(playerName, field, delta = 1) {
        const d = Core.Database.load();
        if (!d.leaderboard.players) d.leaderboard.players = {};
        if (!d.leaderboard.players[playerName]) d.leaderboard.players[playerName] = { kill: 0, olum: 0, onlineSure: 0 };
        d.leaderboard.players[playerName][field] = (d.leaderboard.players[playerName][field] || 0) + delta;
        Core.Database.markDirty("krallik_leaderboard");
    },

    getPlayerStats(playerName) {
        const d = Core.Database.load();
        return d.leaderboard.players?.[playerName] || { kill: 0, olum: 0, onlineSure: 0 };
    },

    getPlayerLeaderboard(field, limit = 10) {
        const d = Core.Database.load();
        const players = d.leaderboard.players || {};
        const sorted = Object.entries(players).map(([name, stats]) => ({ name, value: stats[field] || 0 })).sort((a, b) => b.value - a.value).slice(0, limit);
        return sorted;
    },

    getTopSoldiers(limit = 10) {
        const d = Core.Database.load();
        const soldiers = [];
        for (const [id, rec] of Object.entries(d.askerKayit || {})) soldiers.push({ id, kill: rec.kill || 0, krallik: rec.krallik, type: rec.type });
        soldiers.sort((a, b) => b.kill - a.kill);
        return soldiers.slice(0, limit);
    },

    formatLeaderboard(kategoriId, limit = 10) {
        const kategori = this.getCategory(kategoriId);
        const katDef = Config.LEADERBOARD_KATEGORILERI.find(k => k.id === kategoriId);
        if (!katDef) return "§7Kategori bulunamadı";
        let msg = `§l${katDef.emoji} ${katDef.name}\n§8────────────────\n`;
        const topN = kategori.slice(0, limit);
        if (topN.length === 0) msg += "§7Henüz veri yok\n";
        else topN.forEach((k, i) => {
            const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `§7${i + 1}.`;
            msg += `${medal} §f${k.name} §7- §e${typeof k.value === "number" ? k.value.toLocaleString() : k.value}\n`;
        });
        return msg;
    },

    formatPeriodLeaderboard(period, field, limit = 10) {
        const periodNames = { weekly: "Haftalık", monthly: "Aylık", season: "Sezonluk" };
        const data = this.getPeriodLeaderboard(period, field, limit);
        let msg = `§l${periodNames[period]} ${field.toUpperCase()}\n§8────────────────\n`;
        if (data.length === 0) msg += "§7Henüz veri yok\n";
        else data.forEach((k, i) => {
            const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `§7${i + 1}.`;
            msg += `${medal} §f${k.name} §7- §e${typeof k.value === "number" ? k.value.toLocaleString() : String(k.value ?? 0)}\n`;
        });
        return msg;
    },

    getPeriodLeaderboard(period, field, limit = 10) {
        this._resetIfNeeded();
        const store = this._getPeriodStorage(period);
        const data = store || {};
        const sorted = Object.entries(data).filter(([, stats]) => stats && typeof stats === "object").map(([kid, stats]) => ({ kid, value: stats[field] || 0, name: Core.Database.getKrallik(kid)?.isim || kid })).sort((a, b) => b.value - a.value).slice(0, limit);
        return sorted;
    },

    _getPeriodStorage(period) {
        const d = Core.Database.load();
        if (period === "weekly") return d.leaderboard.weekly;
        if (period === "monthly") return d.leaderboard.monthly;
        if (period === "season") return d.leaderboard.season;
        return d.leaderboard.data;
    },

    getPlayerRank(playerName, kategoriId) {
        const cache = Core.Cache?.getLeaderboardCache?.();
        const kategori = cache?.data?.[kategoriId];
        if (!kategori) return null;
        const kid = Core.Database.getOyuncuKrallikId(playerName);
        if (!kid) return null;
        const index = kategori.findIndex(k => k.id === kid);
        if (index === -1) return null;
        return { rank: index + 1, ...kategori[index] };
    }
};

export const News = {
    addNews(category, message, metadata = {}) {
        const d = Core.Database.load();
        if (!d.news) d.news = [];
        d.news.unshift({ timestamp: Date.now(), category, message, metadata });
        if (d.news.length > 50) d.news.length = 50;
        Core.Database.markDirty("krallik_news");
        Core.LogSistemi?.log?.(category, message, metadata);
    },

    getNews(category = null, limit = 50) {
        const d = Core.Database.load();
        let news = d.news || [];
        if (category) news = news.filter(n => n.category === category);
        return news.slice(0, limit);
    },

    formatNewsFeed(limit = 10) {
        const news = this.getNews(null, limit);
        let msg = `§l📰 HABERLER\n§8────────────────\n`;
        if (news.length === 0) msg += "§7Henüz haber yok\n";
        else news.forEach(n => {
            const time = new Date(n.timestamp).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
            const catEmoji = n.category === "savas" ? "⚔️" : n.category === "claim" ? "🏁" : n.category === "diplomasi" ? "🕊️" : n.category === "krallik" ? "🏰" : "📌";
            msg += `${catEmoji} §7[${time}] §f${n.message}\n`;
        });
        return msg;
    }
};

export const SavasRaporu = {
    addRapor(attackerKid, defenderKid, sonuc, detaylar = {}) {
        const d = Core.Database.load();
        if (!d.savasRaporlari) d.savasRaporlari = [];
        d.savasRaporlari.unshift({
            timestamp: Date.now(), attackerKid, defenderKid, sonuc, detaylar,
            oluSayisi: detaylar.oluSayisi || 0, hasarMiktari: detaylar.hasarMiktari || 0
        });
        if (d.savasRaporlari.length > 100) d.savasRaporlari.length = 100;
        Core.Database.markDirty("krallik_logs");
    },

    getRaporlar(kid, limit = 10) {
        const d = Core.Database.load();
        return (d.savasRaporlari || []).filter(r => r.attackerKid === kid || r.defenderKid === kid).slice(0, limit);
    },

    formatRapor(rapor) {
        const d = Core.Database.load();
        const attacker = d.kralliklar[rapor.attackerKid];
        const defender = d.kralliklar[rapor.defenderKid];
        const sonucEmoji = rapor.sonuc === "zafer" ? "🏆" : rapor.sonuc === "yenilgi" ? "💀" : "🤝";
        return `${sonucEmoji} ${attacker?.isim || "?"} vs ${defender?.isim || "?"} - ${rapor.sonuc} (Ölü: ${rapor.oluSayisi || 0})`;
    }
};

export const Alarm = {
    triggerProximityAlarm(kid, playerName, distance) {
        Systems.broadcastToKrallik(kid, `§e⚠ Sınır yakınında yabancı: §f${playerName} §e(${distance}m)`);
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (k && k.status === "baris") k.status = "alarm";
        Core.Database.markDirty("krallik_core");
    },

    triggerRaidAlarm(kid, attackerKid) {
        const d = Core.Database.load();
        const attacker = d.kralliklar[attackerKid];
        Systems.broadcastToKrallik(kid, `§c⚔️ BASKIN! ${attacker?.isim || "Düşman"} §ckuvvetleri bölgenize saldırıyor!`);
        Systems.broadcastToKrallik(kid, "§6🛡️ Savunma sistemi aktif!");
        if (d.kralliklar[kid]) { d.kralliklar[kid].status = "savas"; d.kralliklar[kid].alarmSeviyesi = 100; }
        Core.Database.markDirty("krallik_core");
    },

    triggerBlockBreakAlarm(kid, playerName, blockType) {
        Systems.broadcastToKrallik(kid, `§c⚠ ${playerName} §fbölgenizde §c${blockType} §fkırdı!`);
    }
};

export const LogSistemi = {
    kategoriler: ["market", "savas", "claim", "asker", "ekonomi", "diplomasi", "yonetim", "customize", "admin"],

    log(kategori, mesaj, detay = {}) { Core.Logger?.info?.(kategori, mesaj, detay); },

    getir(kategori, limit = 50) { return Core.Logger?.getByCategory?.(kategori, limit) || []; },

    filtrele(kategori, arama, limit = 50) {
        const logs = this.getir(kategori, limit);
        if (!arama) return logs;
        return logs.filter(l => l.message?.toLowerCase().includes(arama.toLowerCase()));
    },

    temizle(kategori) {
        const d = Core.Database.load();
        if (d.logKategorileri?.[kategori]) {
            d.logKategorileri[kategori] = [];
            Core.Database.markDirty("krallik_logs");
        }
    }
};

export const Admin = {
    _ensureAdmin() {
        const d = Core.Database.load();
        d.adminAyarlari = d.adminAyarlari || {};
        d.adminAyarlari.banlist = d.adminAyarlari.banlist || {};
        return d.adminAyarlari;
    },

    isAdmin(player) { return Systems.isAdmin(player); },

    ban(playerName, reason = "ban") {
        const a = this._ensureAdmin();
        a.banlist[playerName] = { t: Date.now(), reason };
        Core.Database.markDirty("krallik_admin");
        return true;
    },

    unban(playerName) {
        const a = this._ensureAdmin();
        delete a.banlist[playerName];
        Core.Database.markDirty("krallik_admin");
        return true;
    },

    kick(playerName, reason = "kick") {
        const safePlayer = String(playerName).replace(/[^a-zA-Z0-9_]/g, "");
        const safeReason = String(reason).replace(/[^a-zA-Z0-9_ ]/g, "").slice(0, 100);
        try { world.getDimension("overworld").runCommandAsync(`kick "${safePlayer}" ${safeReason}`); } catch(e) {}
        return true;
    },

    krallikSil(kid) { return KrallikYonetim.dagil(kid, "admin"); },
    krallikTransfer(kid, yeniLider) { return KrallikYonetim.transferLiderlik(kid, yeniLider); },

    itemVer(playerName, itemId, amount = 1) {
        const safePlayer = String(playerName).replace(/[^a-zA-Z0-9_]/g, "");
        const safeItem = String(itemId).replace(/[^a-zA-Z0-9_:.]/g, "");
        const safeAmount = Math.max(1, Math.min(64, parseInt(amount) || 1));
        try { world.getDimension("overworld").runCommandAsync(`give "${safePlayer}" ${safeItem} ${safeAmount}`); } catch(e) {}
    },

    itemAl(playerName, itemId, amount = 1) {
        const safePlayer = String(playerName).replace(/[^a-zA-Z0-9_]/g, "");
        const safeItem = String(itemId).replace(/[^a-zA-Z0-9_:.]/g, "");
        const safeAmount = Math.max(1, Math.min(64, parseInt(amount) || 1));
        try { world.getDimension("overworld").runCommandAsync(`clear "${safePlayer}" ${safeItem} ${safeAmount}`); } catch(e) {}
    },

    paraVer(playerName, amount) {
        const safeAmount = Math.max(0, parseInt(amount) || 0);
        try {
            globalThis.Krallik?.Patch?.init?.();
            const obj = world.scoreboard.getObjective("zmc");
            if (!obj) return;
            const target = world.getAllPlayers().find(p => p.name === playerName);
            if (target) {
                const cur = obj.getScore(target.scoreboardIdentity) ?? 0;
                obj.setScore(target.scoreboardIdentity, cur + safeAmount);
            }
            // NOT: Krallık "hazine"si artık ayrı bir sayaç değil; krallık LİDERİNİN
            // kişisel zmc skoruna canlı olarak bağlıdır (bkz. 00_core.js
            // _bindHazineToZmc). Hedef oyuncu lider ise zmc'si yukarıda zaten
            // değişti ve hazine de otomatik olarak güncellendi; ekstra bir
            // "hazineye ekle" işlemi burada YAPILMAZ, yoksa çift sayım olur.
        } catch(e) {}
    },

    paraAl(playerName, amount) {
        const safeAmount = Math.max(0, parseInt(amount) || 0);
        try {
            globalThis.Krallik?.Patch?.init?.();
            const obj = world.scoreboard.getObjective("zmc");
            if (!obj) return;
            const target = world.getAllPlayers().find(p => p.name === playerName);
            if (target) {
                const cur = obj.getScore(target.scoreboardIdentity) ?? 0;
                obj.setScore(target.scoreboardIdentity, Math.max(0, cur - safeAmount));
            }
            // Bkz. paraVer notu: hazine zaten liderin zmc'sine bağlı, ekstra işlem yok.
        } catch(e) {}
    },

    askerSpawn(dimensionId, x, y, z, entityType) {
        try { world.getDimension(dimensionId || "overworld").runCommandAsync(`summon ${entityType} ${x} ${y} ${z}`); } catch(e) {}
    },

    claimSil(claimId) {
        const d = Core.Database.load();
        if (d.claimler?.[claimId]) {
            try { Core.Duvar?.onClaimDeleted?.(claimId); } catch(e) {}
            try { ClaimManager.removeAllSignsForClaim?.(claimId); } catch(e) {}
            delete d.claimler[claimId];
            Core.Database.markDirty("krallik_claims");
            return true;
        }
        return false;
    },

    eventBaslat(title, sureMs) { return Core.EventManager?.startGlobalEvent?.(title, sureMs); },
    eventDurdur(id) { return Core.EventManager?.endEvent?.(id); },

    liderlikSifirla() {
        const d = Core.Database.load();
        d.leaderboard = {};
        d.leaderboardMeta = { week: null, month: null, season: null };
        Core.Database.markDirty("krallik_leaderboard");
        return true;
    }
};