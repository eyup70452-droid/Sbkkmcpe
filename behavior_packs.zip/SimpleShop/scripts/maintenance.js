// ============================================================
// MODÜL 14: MAINTENANCE - Bakım, Temizlik, Performans ve Kurtarma (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager } from "./02_claim.js";
import { Systems } from "./04_military.js";

// ============================================================
// BAKIM SİSTEMİ
// ============================================================
export const Maintenance = {
    // Ölü askerleri temizle
    cleanDeadSoldiers() {
        const d = Core.Database.load();
        const entities = Core.Cache?.getEntities?.(true) || [];
        const validIds = new Set(entities.filter(e => e?.id).map(e => e.id));
        let cleaned = 0;
        for (const id of Object.keys(d.askerKayit || {})) {
            if (!validIds.has(id)) {
                delete d.askerKayit[id];
                cleaned++;
            }
        }
        if (cleaned > 0) {
            Core.Database.markDirty("krallik_army");
            Core.Logger?.info?.("maintenance", `${cleaned} ölü asker temizlendi`);
        }
    },

    // Eski combat loglarını temizle
    cleanOldCombatLogs() {
        const d = Core.Database.load();
        const cutoff = Date.now() - 86400000; // 24 saat
        if (d.combatLogs) {
            const oldLen = d.combatLogs.length;
            d.combatLogs = d.combatLogs.filter(l => l.timestamp > cutoff);
            if (d.combatLogs.length !== oldLen) {
                Core.Database.markDirty("krallik_logs");
                Core.Logger?.info?.("maintenance", `${oldLen - d.combatLogs.length} eski combat log temizlendi`);
            }
        }
    },

    // Eski siege kayıtlarını temizle
    cleanOldSieges() {
        const d = Core.Database.load();
        const now = Date.now();
        let cleaned = false;
        if (d.sieges) {
            for (const [id, siege] of Object.entries(d.sieges)) {
                if (now - siege.startTime > 1800000) { // 30 dakika
                    const claim = d.claimler?.[id];
                    if (claim) {
                        claim.contested = false;
                        claim.contestedBy = null;
                        claim.siegeProgress = 0;
                    }
                    delete d.sieges[id];
                    cleaned = true;
                }
            }
        }
        if (cleaned) {
            Core.Database.markDirty("krallik_claims");
            Core.Logger?.info?.("maintenance", "Eski siege kayıtları temizlendi");
        }
    },

    // Eski claim permission'larını temizle
    cleanClaimPermissions() {
        try { ClaimManager?.cleanupPermissions?.(); } catch(e) {}
    },

    // Claim'leri normalize et
    normalizeAllClaims() {
        try { ClaimManager?.normalizeAllClaims?.(); } catch(e) {}
    },

    // Claim tick işlemleri
    claimTick() {
        try { ClaimManager?.tick?.(); } catch(e) {}
    },

    // Eski treaty'leri temizle
    cleanOldTreaties() {
        const d = Core.Database.load();
        const now = Date.now();
        let cleaned = false;
        if (d.treaties) {
            for (const [kid, treaties] of Object.entries(d.treaties)) {
                if (typeof treaties !== "object") continue;
                for (const [target, treaty] of Object.entries(treaties)) {
                    if (treaty?.endDate && treaty.endDate < now) {
                        delete treaties[target];
                        cleaned = true;
                    }
                }
            }
        }
        if (d.diplomacy?.treaties) {
            for (const [key, treaty] of Object.entries(d.diplomacy.treaties)) {
                if (treaty?.endTime && treaty.endTime < now) {
                    delete d.diplomacy.treaties[key];
                    cleaned = true;
                }
            }
        }
        if (cleaned) Core.Database.markDirty("krallik_core");
    },

    // Eski event kayıtlarını temizle
    cleanOldEvents() {
        const d = Core.Database.load();
        const now = Date.now();
        let cleaned = false;
        if (d.events?.history) {
            const oldLen = d.events.history.length;
            d.events.history = d.events.history.filter(e => now - e.endTime < 7 * 24 * 60 * 60 * 1000);
            if (d.events.history.length !== oldLen) cleaned = true;
        }
        if (d.krallikEventleri) {
            for (const [kid, events] of Object.entries(d.krallikEventleri)) {
                for (const [eventId, event] of Object.entries(events)) {
                    if (event.expiry && event.expiry < now - 24 * 60 * 60 * 1000) {
                        delete events[eventId];
                        cleaned = true;
                    }
                }
            }
        }
        if (cleaned) Core.Database.markDirty("krallik_economy");
    },

    // Tüm bakım işlemlerini çalıştır
    runAll() {
        this.cleanDeadSoldiers();
        this.cleanOldCombatLogs();
        this.cleanOldSieges();
        this.cleanClaimPermissions();
        this.normalizeAllClaims();
        this.claimTick();
        this.cleanOldTreaties();
        this.cleanOldEvents();
        Core.Logger?.info?.("maintenance", "Periyodik bakım tamamlandı");
    }
};

// ============================================================
// OTOMATİK KAYIT SİSTEMİ
// ============================================================
export const AutoSave = {
    _lastSave: 0,
    _saveInterval: 300000, // 5 dakika
    _isSaving: false,

    save(force = false) {
        if (this._isSaving) return;
        const now = Date.now();
        if (!force && (now - this._lastSave) < this._saveInterval) return;
        
        this._isSaving = true;
        try {
            Core.Database.save(true);
            this._lastSave = now;
            Core.Logger?.info?.("autosave", "Otomatik kayıt yapıldı");
        } catch(e) {
            Core.Logger?.error?.("autosave", e);
        } finally {
            this._isSaving = false;
        }
    },
    
    setInterval(ms) {
        this._saveInterval = Math.max(60000, ms);
    },

    getLastSaveTime() {
        return this._lastSave;
    },

    getTimeUntilNextSave() {
        const elapsed = Date.now() - this._lastSave;
        return Math.max(0, this._saveInterval - elapsed);
    }
};

// ============================================================
// PERFORMANS İZLEYİCİ
// ============================================================
export const PerformanceMonitor = {
    _lastTPS: 20,
    _lastMemory: 0,
    _alerts: [],
    _tickTimes: [],
    _maxTickTimes: 100,

    check() {
        const tps = Core.Telemetry?.getTPS?.() || 20;
        this._lastTPS = tps;
        
        // Tick süresi hesapla
        const tickTime = Core.Telemetry?.getLastTickMs?.() || 50;
        this._tickTimes.push(tickTime);
        if (this._tickTimes.length > this._maxTickTimes) this._tickTimes.shift();
        
        const avgTickTime = this._tickTimes.reduce((a, b) => a + b, 0) / this._tickTimes.length;
        
        if (tps < 15) {
            this._addAlert("düşük_tps", `TPS düşük: ${tps} (Ortalama tick: ${avgTickTime.toFixed(1)}ms)`, "warning");
        }
        if (tps < 10) {
            this._addAlert("kritik_tps", `TPS kritik: ${tps}`, "critical");
        }
        if (avgTickTime > 100) {
            this._addAlert("yüksek_tick", `Tick süresi yüksek: ${avgTickTime.toFixed(1)}ms`, "warning");
        }
        
        // Bellek kontrolü (yaklaşık)
        try {
            const cacheSize = Core.MemoryCache?._map?.size || 0;
            if (cacheSize > 10000) {
                this._addAlert("büyük_cache", `Cache boyutu: ${cacheSize}`, "warning");
            }
        } catch(e) {}
    },
    
    _addAlert(code, message, level) {
        const now = Date.now();
        const lastAlert = this._alerts.find(a => a.code === code);
        if (!lastAlert || (now - lastAlert.timestamp) > 300000) {
            this._alerts.unshift({
                code, message, level,
                timestamp: now,
                tps: this._lastTPS
            });
            if (this._alerts.length > 50) this._alerts.pop();
            Core.Logger?.warning?.("performance", message);
        }
    },
    
    getAlerts(limit = 10) {
        return this._alerts.slice(0, limit);
    },
    
    clearAlerts() {
        this._alerts = [];
    },
    
    getStats() {
        const avgTickTime = this._tickTimes.length ? this._tickTimes.reduce((a, b) => a + b, 0) / this._tickTimes.length : 50;
        return {
            tps: this._lastTPS,
            avgTickTime: avgTickTime.toFixed(1),
            alertCount: this._alerts.length,
            lastAlert: this._alerts[0] || null,
            cacheSize: Core.MemoryCache?._map?.size || 0
        };
    },

    getDetailedStats() {
        const d = Core.Database.load();
        const entityCount = Core.Cache?.getEntities?.().length || 0;
        const krallikCount = Object.keys(d.kralliklar || {}).length;
        const claimCount = Object.keys(d.claimler || {}).length;
        const askerCount = Object.keys(d.askerKayit || {}).length;
        
        return {
            tps: this._lastTPS,
            avgTickTime: this._tickTimes.length ? (this._tickTimes.reduce((a, b) => a + b, 0) / this._tickTimes.length).toFixed(1) : 50,
            entityCount: entityCount,
            krallikCount: krallikCount,
            claimCount: claimCount,
            askerCount: askerCount,
            alertCount: this._alerts.length
        };
    }
};

// ============================================================
// VERİ OPTİMİZASYONU
// ============================================================
export const DataOptimizer = {
    // Eski logları temizle
    optimizeLogs() {
        const d = Core.Database.load();
        const cutoff = Date.now() - (Config.LOG_CLEANUP_AGE || 604800000);
        
        if (d.logs) {
            const oldLen = d.logs.length;
            d.logs = d.logs.filter(l => l.timestamp > cutoff);
            if (d.logs.length !== oldLen) Core.Database.markDirty("krallik_logs");
        }
        
        if (d.marketHistory) {
            for (const kid of Object.keys(d.marketHistory)) {
                d.marketHistory[kid] = d.marketHistory[kid].slice(0, 100);
            }
            Core.Database.markDirty("krallik_economy");
        }
        
        if (d.news && d.news.length > 100) {
            d.news = d.news.slice(0, 100);
            Core.Database.markDirty("krallik_news");
        }
        
        if (d.savasRaporlari && d.savasRaporlari.length > 200) {
            d.savasRaporlari = d.savasRaporlari.slice(0, 200);
            Core.Database.markDirty("krallik_logs");
        }
    },
    
    // Önbellek temizle
    clearCache() {
        Core.MemoryCache?.cleanup?.();
        Core.Cache?.invalidateClaimCache?.();
        Core.Cache?.invalidateLeaderboardCache?.();
        Core.Logger?.info?.("optimizer", "Önbellekler temizlendi");
    },
    
    // Veritabanı boyutunu kontrol et
    getDatabaseSize() {
        let totalSize = 0;
        const keys = Core.Database?._propertyKeys || [];
        for (const key of keys) {
            try {
                const raw = world.getDynamicProperty(key);
                if (raw) totalSize += raw.length;
            } catch(e) {}
        }
        return totalSize;
    },
    
    // Veritabanı temizliği (kullanılmayan verileri sil)
    pruneDatabase() {
        const d = Core.Database.load();
        let pruned = false;
        
        // Krallığı olmayan oyuncuları temizle
        for (const [name, kid] of Object.entries(d.oyuncular || {})) {
            if (!d.kralliklar?.[kid]) {
                delete d.oyuncular[name];
                pruned = true;
            }
        }
        
        // Geçersiz claim'leri temizle
        for (const [cid, claim] of Object.entries(d.claimler || {})) {
            if (!d.kralliklar?.[claim.krallik]) {
                delete d.claimler[cid];
                pruned = true;
            }
        }
        
        // Geçersiz asker kayıtlarını temizle
        for (const [aid, asker] of Object.entries(d.askerKayit || {})) {
            if (!d.kralliklar?.[asker.krallik]) {
                delete d.askerKayit[aid];
                pruned = true;
            }
        }
        
        if (pruned) {
            Core.Database.markDirty("krallik_core");
            Core.Database.markDirty("krallik_claims");
            Core.Database.markDirty("krallik_army");
            Core.Logger?.info?.("optimizer", "Veritabanı temizliği yapıldı");
        }
    },
    
    run() {
        this.optimizeLogs();
        this.clearCache();
        this.pruneDatabase();
        const sizeKB = Math.round(this.getDatabaseSize() / 1024);
        Core.Logger?.info?.("optimizer", `Veri optimizasyonu tamamlandı. DB boyutu: ~${sizeKB} KB`);
        return sizeKB;
    }
};

// ============================================================
// EMERGENCY RECOVERY (Acil Kurtarma)
// ============================================================
export const EmergencyRecovery = {
    _lastRecovery: 0,
    _recoveryCooldown: 60000, // 1 dakika

    // Kritik hata durumunda veri kurtarma
    recoverFromCorruption() {
        const now = Date.now();
        if (now - this._lastRecovery < this._recoveryCooldown) return false;
        this._lastRecovery = now;
        
        try {
            const d = Core.Database.load();
            let fixed = false;
            
            // Kralliklar kontrolü
            if (!d.kralliklar) { d.kralliklar = {}; fixed = true; }
            if (!d.oyuncular) { d.oyuncular = {}; fixed = true; }
            if (!d.claimler) { d.claimler = {}; fixed = true; }
            if (!d.askerKayit) { d.askerKayit = {}; fixed = true; }
            
            // Geçersiz krallık referanslarını temizle
            for (const [name, kid] of Object.entries(d.oyuncular || {})) {
                if (!d.kralliklar[kid]) {
                    delete d.oyuncular[name];
                    fixed = true;
                }
            }
            
            // Geçersiz claim referanslarını temizle
            for (const [cid, claim] of Object.entries(d.claimler || {})) {
                if (!d.kralliklar[claim.krallik]) {
                    delete d.claimler[cid];
                    fixed = true;
                }
            }
            
            // Geçersiz siege referanslarını temizle
            for (const [cid, siege] of Object.entries(d.sieges || {})) {
                if (!d.claimler[siege.claimId]) {
                    delete d.sieges[cid];
                    fixed = true;
                }
            }
            
            if (fixed) {
                Core.Database.markDirty("krallik_core");
                Core.Database.markDirty("krallik_claims");
                Core.Logger?.warning?.("recovery", "Veri kurtarma işlemi yapıldı");
            }
            return fixed;
        } catch(e) {
            Core.Logger?.error?.("recovery", e);
            return false;
        }
    },
    
    // Yedekten geri yükleme
    restoreFromBackup(backupId) {
        return Core.Backup?.restore?.(backupId) || false;
    },
    
    // Otomatik yedekten geri yükleme (en son)
    restoreLatestBackup() {
        const backups = Core.Backup?.listBackups?.() || [];
        if (backups.length === 0) return false;
        const latest = backups[0];
        return this.restoreFromBackup(latest.id);
    },
    
    // Sistem durumunu kontrol et
    healthCheck() {
        const issues = [];
        const warnings = [];
        
        try {
            const d = Core.Database.load();
            if (Object.keys(d.kralliklar || {}).length > 0 && Object.keys(d.oyuncular || {}).length === 0) {
                warnings.push("Oyuncu verisi yok ancak krallıklar var");
            }
            
            const tps = Core.Telemetry?.getTPS?.() || 20;
            if (tps < 12) issues.push(`TPS çok düşük: ${tps}`);
            if (tps < 8) issues.push(`TPS kritik: ${tps} - Sistem yanıt vermiyor olabilir`);
            
            const dbSize = DataOptimizer.getDatabaseSize();
            if (dbSize > 10 * 1024 * 1024) issues.push(`Veritabanı çok büyük: ~${Math.round(dbSize / 1024 / 1024)} MB`);
            
            // Claim kontrolü
            const claims = Object.values(d.claimler || {});
            const orphanClaims = claims.filter(c => !d.kralliklar[c.krallik]).length;
            if (orphanClaims > 0) issues.push(`${orphanClaims} sahipsiz claim bulundu`);
            
            // Scheduler kontrolü
            if (!Core.Scheduler?._intervals || Object.keys(Core.Scheduler._intervals).length === 0) {
                issues.push("Scheduler çalışmıyor olabilir");
            }
            
        } catch(e) {
            issues.push(`Sağlık kontrolü hatası: ${e.message}`);
        }
        
        return {
            healthy: issues.length === 0,
            issues: issues,
            warnings: warnings,
            timestamp: Date.now(),
            recommendations: this._getRecommendations(issues, warnings)
        };
    },
    
    _getRecommendations(issues, warnings) {
        const recs = [];
        if (issues.some(i => i.includes("TPS"))) recs.push("Oyuncu sayısını azaltın veya AI tick aralığını artırın");
        if (issues.some(i => i.includes("çok büyük"))) recs.push("Veritabanı temizliği yapın (/admin > GENEL > veri optimizasyonu)");
        if (issues.some(i => i.includes("sahipsiz"))) recs.push("Sahipsiz claimleri temizleyin");
        if (warnings.length > 0) recs.push("Sistemi yeniden başlatmayı deneyin");
        return recs;
    },
    
    // Acil durum müdahalesi (tüm sistemleri yeniden başlatmayı dener)
    emergencyRestart() {
        Core.Logger?.warning?.("emergency", "Acil durum yeniden başlatma başlatıldı");
        
        // Önce verileri kaydet
        Core.Database.save(true);
        
        // Scheduler'ı yeniden başlat
        if (Core.Systems?.Main?.init) {
            Core.Systems.Main.init();
        }
        
        // Cache'leri temizle
        DataOptimizer.clearCache();
        
        // Kurtarma dene
        this.recoverFromCorruption();
        
        Core.Logger?.info?.("emergency", "Acil durum yeniden başlatma tamamlandı");
        return true;
    }
};