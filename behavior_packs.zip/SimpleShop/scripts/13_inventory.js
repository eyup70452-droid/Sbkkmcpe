// ============================================================
// MODÜL 13: INVENTORY - Envanter ve Item Yönetimi (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { Systems } from "./04_military.js";
import { UI as UI1 } from "./07_ui.js";
import { UI as UI2 } from "./07_ui2.js";
const getUI = () => globalThis.Krallik?.UI || { ...UI1, ...UI2 };

// ============================================================
// ENVANTER SİSTEMİ
// ============================================================
export const Inventory = {
    MARKET_ITEM_ID: "invshop:trigger",
    KRALLIK_ITEM_ID: "krallik:trigger",
    ZMC_ITEM_ID: "zmc:trigger",
    _cooldowns: new Map(),

    giveItems(player) {
        try {
            if (!player?.isValid?.()) return;
            const inventory = player.getComponent("inventory")?.container;
            if (!inventory) return;
            
            let hasMarket = false, hasKrallik = false, hasZmc = false;
            for (let i = 0; i < inventory.size; i++) {
                const item = inventory.getItem(i);
                if (!item) continue;
                if (item.typeId === this.MARKET_ITEM_ID) hasMarket = true;
                if (item.typeId === this.KRALLIK_ITEM_ID) hasKrallik = true;
                if (item.typeId === this.ZMC_ITEM_ID) hasZmc = true;
            }
            
            if (!hasMarket) {
                Systems.runCommand(player, `give @s ${this.MARKET_ITEM_ID} 1 0 {"keep_on_death":{},"item_lock":"lock_in_inventory"}`);
            }
            if (!hasKrallik) {
                Systems.runCommand(player, `give @s ${this.KRALLIK_ITEM_ID} 1 0 {"keep_on_death":{},"item_lock":"lock_in_inventory"}`);
            }
            if (!hasZmc) {
                Systems.runCommand(player, `give @s ${this.ZMC_ITEM_ID} 1 0 {"keep_on_death":{},"item_lock":"lock_in_inventory"}`);
            }
        } catch(e) {}
    },

    checkAllPlayers() {
        for (const player of world.getAllPlayers()) {
            this.giveItems(player);
        }
    },

    preventDrop(e) {
        const t = e.itemStack?.typeId;
        if (t === this.MARKET_ITEM_ID || t === this.KRALLIK_ITEM_ID || t === this.ZMC_ITEM_ID) {
            e.cancel = true;
        }
    },

    countItem(player, itemId) {
        try {
            const inventory = player.getComponent("inventory")?.container;
            if (!inventory) return 0;
            let count = 0;
            for (let i = 0; i < inventory.size; i++) {
                const item = inventory.getItem(i);
                if (item && item.typeId === itemId) {
                    count += item.amount;
                }
            }
            return count;
        } catch(e) { return 0; }
    },

    hasItem(player, itemId, amount = 1) {
        return this.countItem(player, itemId) >= amount;
    },

    removeItem(player, itemId, amount = 1) {
        try {
            const inventory = player.getComponent("inventory")?.container;
            if (!inventory) return false;
            let remaining = amount;
            for (let i = 0; i < inventory.size && remaining > 0; i++) {
                const item = inventory.getItem(i);
                if (item && item.typeId === itemId) {
                    const take = Math.min(remaining, item.amount);
                    item.amount -= take;
                    remaining -= take;
                    if (item.amount <= 0) {
                        inventory.setItem(i, undefined);
                    } else {
                        inventory.setItem(i, item);
                    }
                }
            }
            return remaining === 0;
        } catch(e) { return false; }
    },

    addItem(player, itemId, amount = 1, extraData = {}) {
        try {
            let extraStr = "";
            if (Object.keys(extraData).length > 0) {
                extraStr = " " + JSON.stringify(extraData);
            }
            Systems.runCommand(player, `give @s ${itemId} ${amount}${extraStr}`);
            return true;
        } catch(e) { return false; }
    },

    clearItems(player, itemId = null) {
        try {
            if (itemId) {
                Systems.runCommand(player, `clear @s ${itemId}`);
            } else {
                Systems.runCommand(player, `clear @s`);
            }
            return true;
        } catch(e) { return false; }
    },

    getItemCountInAllInventories(itemId) {
        let total = 0;
        for (const player of world.getAllPlayers()) {
            total += this.countItem(player, itemId);
        }
        return total;
    },

    createCustomItem(itemId, name, lore = [], enchantments = []) {
        const components = {
            "minecraft:display_name": { value: name },
            "minecraft:item_lock": { lock_mode: "lock_in_inventory" },
            "minecraft:keep_on_death": {}
        };
        if (lore.length > 0) {
            components["minecraft:lore"] = { value: lore };
        }
        // Custom item oluşturma için worldInitialize event'inde component kaydı gerekiyor
        return {
            typeId: itemId,
            name: name,
            lore: lore,
            enchantments: enchantments,
            components: components
        };
    },

    isOnCooldown(player, action, cooldownSeconds = 5) {
        const key = `${player.name}:${action}`;
        const lastUse = this._cooldowns.get(key);
        if (lastUse && Date.now() - lastUse < cooldownSeconds * 1000) {
            const remaining = Math.ceil((cooldownSeconds * 1000 - (Date.now() - lastUse)) / 1000);
            Systems.sendMessage(player, `§cBu işlem için ${remaining} saniye bekleyin!`);
            return true;
        }
        this._cooldowns.set(key, Date.now());
        return false;
    },

    resetCooldown(player, action) {
        this._cooldowns.delete(`${player.name}:${action}`);
    }
};

// ============================================================
// ITEM KULLANIM DİNLEYİCİLERİ
// ============================================================
export const ItemHandlers = {
    _handlers: new Map(),

    registerHandler(itemId, handler) {
        this._handlers.set(itemId, handler);
    },

    handleItemUse(player, itemStack) {
        const handler = this._handlers.get(itemStack.typeId);
        if (handler) {
            try {
                handler(player, itemStack);
                return true;
            } catch(e) {
                Core.Logger?.error?.("ItemHandler", e);
            }
        }
        return false;
    },

    registerDefaultHandlers() {
        this.registerHandler("krallik:trigger", (player) => {
            if (Inventory.isOnCooldown(player, "menu", 1)) return;
            getUI().anaMenu(player);
        });
        
        this.registerHandler("invshop:trigger", (player) => {
            if (Inventory.isOnCooldown(player, "market", 1)) return;
            getUI().marketMenusu(player);
        });
        
        this.registerHandler("minecraft:compass", (player) => {
            const kid = Systems.getPlayerKrallikId(player);
            if (kid) {
                const claims = Core.Database.getClaimler(kid);
                if (claims.length > 0) {
                    const claim = claims[0];
                    Systems.sendMessage(player, `§a📍 Claim merkezi: (${Math.floor(claim.x)}, ${Math.floor(claim.z)})`);
                    Systems.sendMessage(player, `§7Mesafe: ${Math.floor(Math.sqrt(Math.pow(player.location.x - claim.x, 2) + Math.pow(player.location.z - claim.z, 2)))} blok`);
                } else {
                    Systems.sendMessage(player, "§cHenüz claim'iniz yok!");
                }
            } else {
                Systems.sendMessage(player, "§cÖnce bir krallığa katılmalısınız!");
            }
        });

        this.registerHandler("minecraft:ender_pearl", (player) => {
            if (Inventory.isOnCooldown(player, "recall", 30)) {
                const e = { cancel: true };
                return e;
            }
            // Recall to kingdom claim center
            const kid = Systems.getPlayerKrallikId(player);
            if (kid) {
                const claims = Core.Database.getClaimler(kid);
                if (claims.length > 0) {
                    const claim = claims[0];
                    Systems.teleport(player, claim.x, claim.y + 1, claim.z);
                    Systems.sendMessage(player, `§a✔ Krallık merkezine ışınlandınız!`);
                }
            }
            return null;
        });

        this.registerHandler("minecraft:clock", (player) => {
            const kid = Systems.getPlayerKrallikId(player);
            if (kid) {
                const krallik = Core.Database.getKrallik(kid);
                if (krallik) {
                    const time = new Date();
                    Systems.sendMessage(player, `§6📅 ${time.toLocaleDateString("tr-TR")} §7- §e${time.toLocaleTimeString("tr-TR")}`);
                    Systems.sendMessage(player, `§7💰 Hazine: §a${(krallik.hazine || 0).toLocaleString()} ZMC`);
                    Systems.sendMessage(player, `§7⚔️ Güç: §d${Core.Power?.formatPower?.(krallik.totalPower) || krallik.totalPower || 0}`);
                }
            }
        });
    },

    removeHandler(itemId) {
        return this._handlers.delete(itemId);
    },

    getAllHandlers() {
        return Array.from(this._handlers.keys());
    }
};

// ============================================================
// CHEST SİSTEMİ - Claim içindeki sandıklar
// ============================================================
export const ChestSystem = {
    _chestCache: new Map(),
    _lastScan: 0,
    SCAN_INTERVAL: Config.CHEST_SCAN_INTERVAL || 60000,

    scanChests(claimId) {
        const d = Core.Database.load();
        const claim = d.claimler?.[claimId];
        if (!claim) return [];
        
        // Önbellekten döndür
        const now = Date.now();
        const cached = this._chestCache.get(claimId);
        if (cached && now - cached.time < this.SCAN_INTERVAL) {
            return cached.chests;
        }
        
        const dim = world.getDimension(claim.dimension || "overworld");
        const cx = Math.floor(claim.x), cz = Math.floor(claim.z);
        const r = claim.radius || 32;
        
        const chests = [];
        // Not: Bedrock API'da blok tarama sınırlı, bu nedenle önbellek kullanılır
        // Gerçek tarama için runCommandAsync kullanılabilir
        
        this._chestCache.set(claimId, { chests: chests, time: now });
        return chests;
    },
    
    calculateChestValue(chestLocation) {
        // İçindeki itemlerin değerini hesapla
        // Değerli item listesi
        const valuableItems = {
            "minecraft:diamond": 100,
            "minecraft:netherite_ingot": 500,
            "minecraft:emerald": 80,
            "minecraft:gold_ingot": 20,
            "minecraft:iron_ingot": 5,
            "minecraft:ancient_debris": 400
        };
        return 0; // Komutla tarama yapılamadığı için 0 döner
    },
    
    getTotalChestValue(claimId) {
        const d = Core.Database.load();
        return d.chestValueCache?.[claimId] || 0;
    },
    
    updateChestValueCache(claimId, value) {
        const d = Core.Database.load();
        if (!d.chestValueCache) d.chestValueCache = {};
        d.chestValueCache[claimId] = value;
        Core.Database.markDirty("krallik_economy");
    },

    // Sandık koruma (claim sahibi olmayanlar açamasın)
    isChestProtected(chestLocation, player) {
        const claim = Core.ClaimManager?.getClaimAt?.(chestLocation, player.dimension.id);
        if (!claim) return false;
        const kid = Systems.getPlayerKrallikId(player);
        return claim.krallik !== kid;
    }
};

// ============================================================
// BLOK DEĞER SİSTEMİ
// ============================================================
export const BlockValueSystem = {
    // Blok değerleri (claim değeri hesaplamak için)
    BLOCK_VALUES: {
        "minecraft:diamond_ore": 100,
        "minecraft:deepslate_diamond_ore": 110,
        "minecraft:gold_ore": 50,
        "minecraft:deepslate_gold_ore": 55,
        "minecraft:iron_ore": 20,
        "minecraft:deepslate_iron_ore": 22,
        "minecraft:coal_ore": 5,
        "minecraft:deepslate_coal_ore": 6,
        "minecraft:emerald_ore": 80,
        "minecraft:deepslate_emerald_ore": 88,
        "minecraft:copper_ore": 10,
        "minecraft:deepslate_copper_ore": 11,
        "minecraft:lapis_ore": 15,
        "minecraft:deepslate_lapis_ore": 17,
        "minecraft:redstone_ore": 8,
        "minecraft:deepslate_redstone_ore": 9,
        "minecraft:nether_quartz_ore": 12,
        "minecraft:nether_gold_ore": 30,
        "minecraft:ancient_debris": 500,
        "minecraft:netherite_block": 5000,
        "minecraft:diamond_block": 900,
        "minecraft:gold_block": 450,
        "minecraft:iron_block": 180,
        "minecraft:emerald_block": 720
    },
    
    getBlockValue(blockTypeId) {
        return this.BLOCK_VALUES[blockTypeId] || 0;
    },
    
    calculateClaimBlockValue(claimId) {
        const d = Core.Database.load();
        const claim = d.claimler?.[claimId];
        if (!claim) return 0;
        
        // Önbellekten al
        return d.blockValueCache?.[claimId] || 0;
    },
    
    updateBlockValueCache(claimId, value) {
        const d = Core.Database.load();
        if (!d.blockValueCache) d.blockValueCache = {};
        d.blockValueCache[claimId] = value;
        Core.Database.markDirty("krallik_economy");
    },
    
    addBlockValue(blockTypeId, value) {
        this.BLOCK_VALUES[blockTypeId] = value;
    },
    
    removeBlockValue(blockTypeId) {
        delete this.BLOCK_VALUES[blockTypeId];
    },
    
    // Claim içindeki blokların yaklaşık değerini hesapla (alan bazlı)
    estimateClaimBlockValue(claim) {
        const radius = claim.radius || 32;
        const area = Math.PI * radius * radius;
        const averageBlockValue = 10; // Ortalama blok değeri
        return Math.floor(area * averageBlockValue);
    }
};