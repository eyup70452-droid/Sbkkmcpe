// ============================================================
// MODÜL 00: CORE - KRALLIK FRAMEWORK V6 (TAM EKSİKSİZ)
// ============================================================
import { world, system } from "@minecraft/server";

export const KrallikCore = {
    version: "6.0.0",
    started: false,
    startedAt: 0,

    RateLimiter: {
        _log: {},
        isAllowed(player, action, limit = 3, windowMs = 1000) {
            const name = player?.name || player;
            if (!name) return true;
            const now = Date.now();
            if (!this._log[name]) this._log[name] = {};
            if (!this._log[name][action]) this._log[name][action] = [];
            this._log[name][action] = this._log[name][action].filter(t => now - t < windowMs);
            if (this._log[name][action].length >= limit) return false;
            this._log[name][action].push(now);
            return true;
        },
        getRemaining(player, action, limit = 3, windowMs = 1000) {
            const name = player?.name || player;
            if (!name) return limit;
            const now = Date.now();
            const times = (this._log[name]?.[action] || []).filter(t => now - t < windowMs);
            return Math.max(0, limit - times.length);
        },
        cleanup() {
            const now = Date.now();
            for (const name of Object.keys(this._log)) {
                for (const action of Object.keys(this._log[name])) {
                    this._log[name][action] = this._log[name][action].filter(t => now - t < 5000);
                    if (!this._log[name][action].length) delete this._log[name][action];
                }
                if (!Object.keys(this._log[name]).length) delete this._log[name];
            }
        }
    },

    CoreRuntime: {
        version: "3.0.0",
        started: false,
        startedAt: 0,
        start() {
            if (this.started) return;
            this.started = true;
            this.startedAt = Date.now();
            try { KrallikCore.Database?.migrateDiplomacy?.(); } catch(e) {}
            // Systems.Main yoktur; modüller main.js'de startKrallik() ile başlatılır
        },
        stop() { this.started = false; }
    },

    EventBus: {
        _handlers: {},
        on(eventName, handler) {
            if (!this._handlers[eventName]) this._handlers[eventName] = [];
            this._handlers[eventName].push(handler);
            return () => this.off(eventName, handler);
        },
        once(eventName, handler) {
            const off = this.on(eventName, (...args) => { try { handler(...args); } finally { off(); } });
            return off;
        },
        off(eventName, handler) {
            const list = this._handlers[eventName];
            if (!list) return;
            const idx = list.indexOf(handler);
            if (idx >= 0) list.splice(idx, 1);
        },
        emit(eventName, payload) {
            const list = this._handlers[eventName] || [];
            for (const h of list) { try { h(payload); } catch(e) {} }
            try { KrallikCore.ModuleRegistry?.executeHook?.(eventName, payload); } catch(e) {}
        }
    },

    SafeEntity: {
        _refs: new Map(),
        register(key, entity, meta = null) {
            if (!key) return;
            const id = entity?.id;
            if (!id) return;
            this._refs.set(String(key), { id, lastSeen: Date.now(), meta });
        },
        get(key) {
            const rec = this._refs.get(String(key));
            if (!rec) return null;
            const ent = KrallikCore.Cache?.getEntityById?.(rec.id) || null;
            if (!ent || !KrallikCore.Cache?.isValidEntity?.(ent)) return null;
            rec.lastSeen = Date.now();
            return ent;
        },
        cleanup(maxAgeMs = 600000) {
            const now = Date.now();
            for (const [k, v] of this._refs.entries()) if (now - (v.lastSeen || 0) > maxAgeMs) this._refs.delete(k);
        }
    },

    Telemetry: {
        _lastTickMs: 0, _lastDtMs: 50, _tps: 20, _samples: [],
        tick() {
            const now = Date.now();
            if (this._lastTickMs) {
                const dt = now - this._lastTickMs;
                this._lastDtMs = dt;
                const tps = Math.max(1, Math.min(20, Math.round((20 * 1000) / Math.max(1, dt))));
                this._tps = tps;
                this._samples.push({ t: now, dt, tps });
                if (this._samples.length > 120) this._samples.shift();
            }
            this._lastTickMs = now;
        },
        getTPS() { return this._tps; },
        getLastTickMs() { return this._lastDtMs; }
    },

    MemoryCache: {
        _map: new Map(),
        set(key, value, ttlMs = 30000) {
            this._map.set(String(key), { value, exp: Date.now() + Math.max(0, ttlMs) });
            return value;
        },
        get(key, fallback = null) {
            const rec = this._map.get(String(key));
            if (!rec) return fallback;
            if (Date.now() > rec.exp) { this._map.delete(String(key)); return fallback; }
            return rec.value;
        },
        delete(key) { this._map.delete(String(key)); },
        cleanup() { const now = Date.now(); for (const [k, v] of this._map.entries()) if (now > v.exp) this._map.delete(k); }
    },

    Guardian: {
        _baseline: null,
        init() {
            if (this._baseline) return;
            this._baseline = {
                SchedulerRegister: KrallikCore.Scheduler?.register,
                DatabaseSave: KrallikCore.Database?.save,
                ClaimIsProtected: KrallikCore.ClaimManager?.isProtected
            };
        },
        check() {
            if (!this._baseline) this.init();
            const b = this._baseline;
            if (b.SchedulerRegister !== KrallikCore.Scheduler?.register) KrallikCore.Logger?.warning?.("Guardian", "Scheduler.register değişmiş olabilir.");
            if (b.DatabaseSave !== KrallikCore.Database?.save) KrallikCore.Logger?.warning?.("Guardian", "Database.save değişmiş olabilir.");
            if (b.ClaimIsProtected !== KrallikCore.ClaimManager?.isProtected) KrallikCore.Logger?.warning?.("Guardian", "ClaimManager.isProtected değişmiş olabilir.");
        }
    },

    EmergencyTPSDowngrade: {
        level: 0, _baseRates: null,
        tick() {
            const tps = KrallikCore.Telemetry.getTPS();
            const nextLevel = tps < 12 ? 3 : tps < 15 ? 2 : tps < 18 ? 1 : 0;
            if (nextLevel === this.level) return;
            if (!this._baseRates) this._baseRates = Object.assign({}, KrallikCore.Scheduler._adaptiveRates);
            this.level = nextLevel;
            if (nextLevel === 0) {
                KrallikCore.Scheduler._updateAdaptiveRates();
                this._baseRates = null;
            } else {
                const base = this._baseRates || KrallikCore.Scheduler._adaptiveRates;
                const m = nextLevel === 1 ? 1.5 : nextLevel === 2 ? 2.5 : 4.0;
                const r = {};
                for (const k of Object.keys(base)) r[k] = Math.floor(base[k] * m);
                KrallikCore.Scheduler._adaptiveRates = r;
            }
            try { KrallikCore.Logger.warning("performance", `Emergency TPS downgrade seviye=${this.level} (TPS≈${tps})`); } catch(e) {}
        }
    },

    AllocationStormDetector: {
        _lastSize: 0,
        tick() {
            const size = KrallikCore.MemoryCache?._map?.size || 0;
            const delta = size - this._lastSize;
            this._lastSize = size;
            if (delta > 1000) try { KrallikCore.Logger.warning("performance", `Allocation storm? cache +${delta}`); } catch(e) {}
        }
    },

    BridgeCallThrottler: {
        throttled(name, fn, minIntervalMs) { KrallikCore.Scheduler.registerThrottled(name, fn, minIntervalMs); }
    },

    RuntimeInvariantEnforcer: {
        assert(cond, msg = "Invariant") {
            if (cond) return true;
            try { KrallikCore.Logger.error("Invariant", msg); } catch(e) {}
            return false;
        }
    },

    Virtualization: {
        BUBBLE_RADIUS: 96,
        getBubbleEntities(center, radius = null) { return KrallikCore.Cache.getNearbyEntities(center, radius ?? this.BUBBLE_RADIUS); },
        isInsideBubble(center, loc, radius = null) { return KrallikCore.Performance.isInRange(center, loc, radius ?? this.BUBBLE_RADIUS); }
    },

    SpatialPartitioning: {
        getChunkKey(loc) { return loc ? `${Math.floor(loc.x / 16)},${Math.floor(loc.z / 16)}` : "0,0"; },
        getSectorKey(loc) {
            const sx = Math.floor((loc.x || 0) / 32);
            const sz = Math.floor((loc.z || 0) / 32);
            return `${sx},${sz}`;
        }
    },

    SectorGrid: {
        SIZE: 32,
        keyFromLoc(loc) {
            const sx = Math.floor((loc.x || 0) / this.SIZE);
            const sz = Math.floor((loc.z || 0) / this.SIZE);
            return `${sx},${sz}`;
        },
        key(x, z) { return `${Math.floor(x / this.SIZE)},${Math.floor(z / this.SIZE)}`; }
    },

    ObjectPools: {
        get(key, factory) { return KrallikCore.Performance.poolGet(key, factory); },
        put(key, obj) { KrallikCore.Performance.poolReturn(key, obj); }
    },

    Utils: {
        clamp(n, min, max) { return Math.max(min, Math.min(max, n)); },
        random(min = 0, max = 1) { return Math.floor(Math.random() * (max - min + 1)) + min; },
        randomFloat(min = 0, max = 1) { return Math.random() * (max - min) + min; },
        chance(pct) { return Math.random() * 100 < pct; },
        pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; },
        lerp(a, b, t) { return a + (b - a) * Math.max(0, Math.min(1, t)); },
        dist2D(x1, z1, x2, z2) { return Math.sqrt((x2 - x1) ** 2 + (z2 - z1) ** 2); },
        deepClone(obj) { try { return JSON.parse(JSON.stringify(obj)); } catch { return obj; } },
        hashStr(s = "") { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(16); }
    },

    Performance: {
        _tickCount: 0, _tickModulos: {}, _objectPool: {},
        distanceSq(loc1, loc2) { if (!loc1 || !loc2) return Infinity; const dx = loc1.x - loc2.x, dz = loc1.z - loc2.z; return dx * dx + dz * dz; },
        isInRange(loc1, loc2, range) { return this.distanceSq(loc1, loc2) <= range * range; },
        filterInRange(entities, center, range) {
            const rangeSq = range * range, result = [];
            if (!center || !entities) return result;
            for (const e of entities) {
                if (!e?.location) continue;
                const dx = center.x - e.location.x, dz = center.z - e.location.z;
                if (dx * dx + dz * dz <= rangeSq) result.push(e);
            }
            return result;
        },
        findNearest(entities, center) {
            let nearest = null, nearestDistSq = Infinity;
            if (!center || !entities) return null;
            for (const e of entities) {
                if (!e?.location) continue;
                const dsq = this.distanceSq(center, e.location);
                if (dsq < nearestDistSq) { nearestDistSq = dsq; nearest = e; }
            }
            return nearest;
        },
        shouldRun(key, interval) {
            if (!this._tickModulos[key]) this._tickModulos[key] = Math.floor(Math.random() * interval);
            return (this._tickCount % interval) === this._tickModulos[key];
        },
        poolGet(key, factory) { if (!this._objectPool[key]) this._objectPool[key] = []; if (this._objectPool[key].length > 0) return this._objectPool[key].pop(); return factory(); },
        poolReturn(key, obj) { if (!this._objectPool[key]) this._objectPool[key] = []; if (this._objectPool[key].length < 100) this._objectPool[key].push(obj); },
        tick() { this._tickCount++; }
    },

    DeadPointerCleaner: {
        run() { try { KrallikCore.Cache.cleanupInvalid(); } catch(e) {} }
    },

    SelfHealing: {
        run() {
            try { KrallikCore.MemoryCache.cleanup(); } catch(e) {}
            try { KrallikCore.DeadPointerCleaner.run(); } catch(e) {}
            try { KrallikCore.Database.save(false); } catch(e) {}
        }
    },

    Logger: {
        log(level, category, message, metadata = {}) {
            const d = KrallikCore.Database.load();
            if (!d.logs) d.logs = [];
            d.logs.unshift({ timestamp: Date.now(), level, category, message, actor: metadata.actor || "system", target: metadata.target || null, metadata });
            if (d.logs.length > (KrallikCore.Config?.MAX_LOGS || 500)) d.logs.length = KrallikCore.Config?.MAX_LOGS || 500;
            const cutoff = Date.now() - (KrallikCore.Config?.LOG_CLEANUP_AGE || 604800000);
            d.logs = d.logs.filter(l => l.timestamp > cutoff);
            if (!d.logKategorileri) d.logKategorileri = {};
            if (!d.logKategorileri[category]) d.logKategorileri[category] = [];
            d.logKategorileri[category].unshift({ timestamp: Date.now(), level, message, metadata });
            if (d.logKategorileri[category].length > 200) d.logKategorileri[category].length = 200;
            KrallikCore.Database.markDirty("krallik_logs");
        },
        info(c, m, meta) { this.log("INFO", c, m, meta); },
        warning(c, m, meta) { this.log("WARNING", c, m, meta); },
        error(c, m, meta) { this.log("ERROR", c, m, meta); try { console.warn(`[Krallik:${c}] ${m}`, meta || ""); } catch(e) {} },
        critical(c, m, meta) { this.log("CRITICAL", c, m, meta); try { console.error(`[Krallik:${c}] ${m}`, meta || ""); } catch(e) {} },
        getByCategory(category, limit = 50) {
            const d = KrallikCore.Database.load();
            return (d.logKategorileri?.[category] || []).slice(0, limit);
        }
    },

    Database: {
        _data: null, _dirtyFlags: {}, _saveQueue: null, _lastSave: 0, _saveLock: false,
        _propertyKeys: ["krallik_core", "krallik_claims", "krallik_army", "krallik_logs", "krallik_economy", "krallik_market", "krallik_customize", "krallik_profiles", "krallik_leaderboard", "krallik_news", "krallik_admin", "krallik_duvarlar", "krallik_extras"],

        load() {
            if (this._data) return this._data;
            this._data = {
                kralliklar: {}, oyuncular: {}, claimler: {}, askerKayit: {}, olumKayitlari: [], logs: [], sieges: {}, treaties: {},
                combatLogs: [], powerCache: {}, chestValueCache: {}, blockValueCache: {}, marketStock: {}, krallikEventleri: {},
                customizeMenus: {}, savasRaporlari: [], adminAyarlari: {}, profiles: {},
                leaderboard: { data: {}, weekly: {}, monthly: {}, season: {}, players: {}, kingdoms: {}, lastUpdate: 0 },
                leaderboardMeta: { week: null, month: null, season: null },
                news: [], marketLogs: [], marketHistory: {}, karaBorsa: {}, borsa: {}, logKategorileri: {}, reports: [],
                duvarlar: {},
                diplomacy: { relations: {}, wars: {}, alliances: {}, treaties: {}, tradeAgreements: {}, embargoes: {}, ceasefires: {} },
                events: { active: {}, history: [] }, _diplomacyMigrated: false,
                ticaretYollari: {}, kahramanlar: {}, vasallar: {},
                claimDrawSessions: {}
            };
            try {
                for (const key of this._propertyKeys) {
                    const raw = world.getDynamicProperty(key);
                    if (raw) { try { this._mergeData(key, JSON.parse(raw)); } catch(e) { KrallikCore.Logger.warning("Database.load", `Property bozuk: ${key}`); } }
                }
            } catch(e) { KrallikCore.Logger.error("Database.load", e); }
            this._bindAllHazine();
            return this._data;
        },

        _bindAllHazine() {
            try {
                for (const k of Object.values(this._data.kralliklar || {})) this._bindHazineToZmc(k);
            } catch(e) {}
        },

        _mergeData(key, parsed) {
            const map = {
                "krallik_core": ["kralliklar", "oyuncular", "diplomacy", "events", "_diplomacyMigrated"],
                "krallik_claims": ["claimler", "sieges", "claimDrawSessions"],
                "krallik_army": ["askerKayit", "olumKayitlari"],
                "krallik_logs": ["logs", "combatLogs", "savasRaporlari", "marketLogs", "logKategorileri"],
                "krallik_economy": ["treaties", "powerCache", "chestValueCache", "blockValueCache", "krallikEventleri", "marketHistory", "karaBorsa", "borsa"],
                "krallik_market": ["marketStock"],
                "krallik_customize": ["customizeMenus"],
                "krallik_profiles": ["profiles"],
                "krallik_leaderboard": ["leaderboard", "leaderboardMeta"],
                "krallik_news": ["news"],
                "krallik_admin": ["adminAyarlari", "reports"],
                "krallik_duvarlar": ["duvarlar"],
                "krallik_extras": ["ticaretYollari", "kahramanlar", "vasallar"]
            };
            const fields = map[key] || [];
            for (const f of fields) if (parsed[f] !== undefined) this._data[f] = parsed[f];
        },

        markDirty(section = "krallik_core") { this._dirtyFlags[section] = true; },

        migrateDiplomacy() {
            const d = this.load();
            if (d._diplomacyMigrated) return;
            if (!d.diplomacy) d.diplomacy = { relations: {}, wars: {}, alliances: {}, treaties: {}, tradeAgreements: {}, embargoes: {}, ceasefires: {} };
            if (!d.events) d.events = { active: {}, history: [] };
            const now = Date.now();
            const keyOf = (a, b) => [a, b].sort().join("|");
            for (const [kid, k] of Object.entries(d.kralliklar || {})) {
                if (Array.isArray(k.savaslar)) {
                    for (const targetKid of k.savaslar) {
                        if (!targetKid) continue;
                        const key = keyOf(kid, targetKid);
                        if (!d.diplomacy.wars[key]) d.diplomacy.wars[key] = { startTime: now, endTime: null, reason: "migrated" };
                    }
                }
                if (Array.isArray(k.muttefikler)) {
                    for (const targetKid of k.muttefikler) {
                        if (!targetKid) continue;
                        const key = keyOf(kid, targetKid);
                        if (!d.diplomacy.alliances[key]) d.diplomacy.alliances[key] = { startTime: now };
                    }
                }
            }
            d._diplomacyMigrated = true;
            this.markDirty("krallik_core");
        },

        save(force = false) {
            if (this._saveLock && !force) return;
            const now = Date.now();
            const hasDirty = Object.values(this._dirtyFlags).some(v => v);
            if (!hasDirty && !force) return;
            if (!force && now - this._lastSave < 3000) {
                if (!this._saveQueue) this._saveQueue = KrallikCore.Scheduler.runLater(() => this.save(true), 20);
                return;
            }
            this._saveLock = true;
            try {
                const d = this._data;
                const packages = {
                    "krallik_core": { kralliklar: d.kralliklar, oyuncular: d.oyuncular, diplomacy: d.diplomacy, events: d.events, _diplomacyMigrated: !!d._diplomacyMigrated },
                    "krallik_claims": { claimler: d.claimler, sieges: d.sieges, claimDrawSessions: d.claimDrawSessions || {} },
                    "krallik_army": { askerKayit: d.askerKayit, olumKayitlari: d.olumKayitlari },
                    "krallik_logs": { logs: d.logs, combatLogs: d.combatLogs, savasRaporlari: d.savasRaporlari, marketLogs: d.marketLogs, logKategorileri: d.logKategorileri },
                    "krallik_economy": { treaties: d.treaties, powerCache: d.powerCache, chestValueCache: d.chestValueCache, blockValueCache: d.blockValueCache, krallikEventleri: d.krallikEventleri, marketHistory: d.marketHistory, karaBorsa: d.karaBorsa, borsa: d.borsa },
                    "krallik_market": { marketStock: d.marketStock },
                    "krallik_customize": { customizeMenus: d.customizeMenus },
                    "krallik_profiles": { profiles: d.profiles },
                    "krallik_leaderboard": { leaderboard: d.leaderboard, leaderboardMeta: d.leaderboardMeta },
                    "krallik_news": { news: d.news },
                    "krallik_admin": { adminAyarlari: d.adminAyarlari, reports: d.reports },
                    "krallik_duvarlar": { duvarlar: d.duvarlar },
                    "krallik_extras": { ticaretYollari: d.ticaretYollari, kahramanlar: d.kahramanlar, vasallar: d.vasallar }
                };
                let anyFailed = false;
                for (const [key, val] of Object.entries(packages)) {
                    if (!(this._dirtyFlags[key] || force)) continue;
                    try {
                        const json = JSON.stringify(val);
                        if (json.length > 30000) {
                            KrallikCore.Logger.warning("Database.save", `"${key}" property boyutu kritik (${json.length} karakter) — Bedrock 32KB limiti aşılacak, bu property atlanıyor!`);
                            anyFailed = true;
                            continue; // 32KB'yi geçerse setDynamicProperty zaten hata fırlatır, önceden önle
                        } else if (json.length > 24000) {
                            KrallikCore.Logger.warning("Database.save", `"${key}" property boyutu büyük (${json.length} karakter) — veri optimizasyonu önerilir.`);
                        }
                        world.setDynamicProperty(key, json);
                        delete this._dirtyFlags[key];
                    } catch (e) {
                        anyFailed = true;
                        this._dirtyFlags[key] = true;
                        KrallikCore.Logger.error("Database.save", `"${key}" kaydedilemedi: ${e?.message || e}`);
                        // dirty bayrağı bilerek temizlenmiyor/yeniden işaretleniyor; bir sonraki save() denemesinde tekrar denenecek.
                    }
                }
                this._lastSave = now;
                if (!anyFailed && this._saveQueue) this._saveQueue = null;
            } catch(e) { KrallikCore.Logger.error("Database.save", e); }
            finally { this._saveLock = false; }
        },

        reloadPlayer(playerName) {
            // ÖNEMLİ: Bu fonksiyon her playerSpawn'da çalışır (ölüm/respawn, dimension
            // değişimi, yeniden bağlanma dahil). Önceki sürüm, disk'teki (henüz
            // Database.save() ile yazılmamış olabilen, yani BAYAT) "krallik_core"
            // verisini okuyup bunu bellekteki CANLI krallık/hazine objesinin üzerine
            // yazıyordu. save() 3 saniyelik debounce ile çalıştığından, bu durum
            // henüz diske yazılmamış hazine/gelir/vergi değişikliklerinin oyuncu
            // her respawn olduğunda sıfırlanmasına/eski haline dönmesine sebep
            // oluyordu (örn. hazine sürekli 0 gösteriyor şikayeti).
            //
            // Bellek (this._data) zaten otoriter kaynaktır; dünya zaten yüklüyse
            // disk'ten tekrar okuyup üzerine yazmamıza gerek yok. Bu fonksiyon
            // artık sadece dünya ilk yüklendiğinde (henüz hiç load() çağrılmamışsa)
            // veriyi hazırlar; bellek zaten doluysa hiçbir şeyin üzerine yazmaz.
            if (!this._data) {
                this.load();
            }
        },

        safeGet(path, defaultValue = null) {
            try {
                const parts = path.split("."); let current = this.load();
                for (const p of parts) { if (current == null) return defaultValue; current = current[p]; }
                return current !== undefined ? current : defaultValue;
            } catch(e) { return defaultValue; }
        },

        safeSet(path, value) {
            try {
                const parts = path.split("."); const d = this.load();
                let current = d;
                for (let i = 0; i < parts.length - 1; i++) {
                    if (!(parts[i] in current)) current[parts[i]] = {};
                    current = current[parts[i]];
                }
                current[parts[parts.length - 1]] = value;
                return true;
            } catch(e) { return false; }
        },

        // ============================================================
        // ZMC KÖPRÜSÜ: Artık tek gerçek para birimi "zmc" scoreboard'udur.
        // Krallığın "hazine" değeri ayrı bir sayaç değil; doğrudan krallık
        // LİDERİNİN kişisel zmc skorunun canlı bir görünümüdür (patch.js'in
        // kullandığı sistemle aynı). getKrallik() ile dönen krallık objesinde
        // .hazine okunduğunda liderin zmc'si okunur, .hazine'ye yazıldığında
        // liderin zmc'si değişir — geri kalan ~40 yerdeki "k.hazine" kodu
        // hiç değişmeden otomatik olarak gerçek zmc'yi kullanır.
        _zmcObjective() {
            try { return world.scoreboard.getObjective("zmc") || null; } catch(e) { return null; }
        },
        _getLeaderZmc(liderAdi) {
            if (!liderAdi) return 0;
            try {
                const obj = this._zmcObjective();
                if (!obj) return 0;
                const p = world.getAllPlayers().find(pl => pl.name === liderAdi);
                if (p) return obj.getScore(p.scoreboardIdentity) ?? 0;
                // Lider o an çevrimdışıysa kayıtlı katılımcılardan skor ara
                const participant = obj.getParticipants().find(pp => pp.displayName === liderAdi);
                if (participant) return obj.getScore(participant) ?? 0;
                return 0;
            } catch(e) { return 0; }
        },
        _setLeaderZmc(liderAdi, value) {
            if (!liderAdi) return;
            try {
                const obj = this._zmcObjective();
                if (!obj) return;
                // NOT: Bilerek 0'a clamp edilmiyor. Hazine sistemi -5000'e kadar
                // borçlanmayı (vergi cezası vb.) destekliyor (bkz. 03_economy.js,
                // 05_diplomacy.js), o yüzden lider zmc skoru da negatif olabilmeli.
                // Minecraft scoreboard'ları negatif tam sayıları destekler.
                const safeValue = Math.floor(value) || 0;
                const p = world.getAllPlayers().find(pl => pl.name === liderAdi);
                if (p) { obj.setScore(p.scoreboardIdentity, safeValue); return; }
                const participant = obj.getParticipants().find(pp => pp.displayName === liderAdi);
                if (participant) obj.setScore(participant, safeValue);
            } catch(e) {}
        },
        _bindHazineToZmc(krallik) {
            if (!krallik || krallik.__hazineBound) return krallik;
            const self = this;
            Object.defineProperty(krallik, "hazine", {
                get() { return self._getLeaderZmc(krallik.lider); },
                set(v) { self._setLeaderZmc(krallik.lider, v); },
                enumerable: true, configurable: true
            });
            Object.defineProperty(krallik, "__hazineBound", {
                value: true, enumerable: false, configurable: true, writable: true
            });
            return krallik;
        },

        getKrallik(id) {
            const k = this.safeGet(`kralliklar.${id}`);
            return this._bindHazineToZmc(k);
        },
        getOyuncuKrallikId(name) { return this.safeGet(`oyuncular.${name}`); },
        getClaimler(kid) { const d = this.load(); const result = []; for (const [id, c] of Object.entries(d.claimler || {})) if (c.krallik === kid) result.push({ id, ...c }); return result; }
    },

    Cache: {
        _entityCache: null, _entityCacheTime: 0, _entityById: {}, _chunkCache: {},
        _krallikEntityMap: {}, _krallikEntityCount: {}, _invalidEntities: new Set(),
        _claimCache: null, _claimCacheTime: 0, _claimByChunk: {},
        _profileCache: {}, _profileCacheTimeByPlayer: {}, _leaderboardCache: null, _leaderboardCacheTime: 0,
        CACHE_DURATION: 3000, CLAIM_CACHE_DURATION: 5000, PROFILE_CACHE_DURATION: 10000, LEADERBOARD_CACHE_DURATION: 30000,

        getEntities(forceRefresh = false) {
            const now = Date.now();
            if (!forceRefresh && this._entityCache && (now - this._entityCacheTime) < this.CACHE_DURATION) return this._entityCache;
            try {
                const dimension = world.getDimension("overworld");
                this._entityCache = [...dimension.getEntities()];
                this._entityCacheTime = now;
                this._rebuildIndexes();
            } catch(e) { KrallikCore.Logger.error("Cache.getEntities", e); if (!this._entityCache) this._entityCache = []; }
            return this._entityCache;
        },

        _rebuildIndexes() {
            this._entityById = {}; this._chunkCache = {}; this._krallikEntityMap = {}; this._krallikEntityCount = {};
            for (const e of this._entityCache) {
                if (!e?.id) continue;
                this._entityById[e.id] = e;
                if (e.location) {
                    const cx = Math.floor(e.location.x / 16), cz = Math.floor(e.location.z / 16);
                    const key = cx + "," + cz;
                    if (!this._chunkCache[key]) this._chunkCache[key] = [];
                    this._chunkCache[key].push(e);
                }
                try {
                    const tags = e.getTags?.() || [];
                    for (const t of tags) {
                        if (t.startsWith("krallik_")) {
                            const kid = t.replace("krallik_", "");
                            if (!this._krallikEntityMap[kid]) this._krallikEntityMap[kid] = [];
                            this._krallikEntityMap[kid].push(e);
                            this._krallikEntityCount[kid] = (this._krallikEntityCount[kid] || 0) + 1;
                            break;
                        }
                    }
                } catch(err) {}
            }
        },

        getEntityById(id) { if (!this._entityCache) this.getEntities(); return this._entityById[id] || null; },
        getNearbyEntities(loc, range) {
            if (!this._entityCache) this.getEntities();
            const entities = [], rangeSq = range * range;
            const startCX = Math.floor((loc.x - range) / 16), endCX = Math.floor((loc.x + range) / 16);
            const startCZ = Math.floor((loc.z - range) / 16), endCZ = Math.floor((loc.z + range) / 16);
            for (let cx = startCX; cx <= endCX; cx++) {
                for (let cz = startCZ; cz <= endCZ; cz++) {
                    const chunk = this._chunkCache[cx + "," + cz];
                    if (!chunk) continue;
                    for (const e of chunk) {
                        if (!e?.location) continue;
                        const dx = loc.x - e.location.x, dz = loc.z - e.location.z;
                        if (dx * dx + dz * dz <= rangeSq) entities.push(e);
                    }
                }
            }
            return entities;
        },

        getKrallikEntityCount(krallikId) { if (!this._entityCache) this.getEntities(); return this._krallikEntityCount[krallikId] || 0; },
        getKrallikEntities(krallikId) { if (!this._entityCache) this.getEntities(); return this._krallikEntityMap[krallikId] || []; },
        isValidEntity(entity) {
            if (!entity?.id) return false;
            if (this._invalidEntities.has(entity.id)) return false;
            try {
                if (!entity.isValid || !entity.isValid()) { this._invalidEntities.add(entity.id); return false; }
                return entity.location !== undefined;
            } catch(e) { this._invalidEntities.add(entity.id); return false; }
        },
        cleanupInvalid() { this._invalidEntities.clear(); this.getEntities(true); },
        getEntityKrallikId(entity) { try { const tags = entity.getTags?.() || []; for (const t of tags) if (t.startsWith("krallik_")) return t.replace("krallik_", ""); } catch(e) {} return null; },
        getClaimCache(forceRefresh = false) { const now = Date.now(); if (!forceRefresh && this._claimCache && (now - this._claimCacheTime) < this.CLAIM_CACHE_DURATION) return this._claimCache; const d = KrallikCore.Database.load(); this._claimCache = d.claimler || {}; this._claimCacheTime = now; this._rebuildClaimChunkIndex(); return this._claimCache; },
        _rebuildClaimChunkIndex() { this._claimByChunk = {}; this.invalidatePipCache?.(); if (!this._claimCache) return; const CHUNK = 16; for (const [id, claim] of Object.entries(this._claimCache)) { const entry = { id, ...claim }; if (entry.vertices && Array.isArray(entry.vertices) && entry.vertices.length >= 3) { let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity; for (const v of entry.vertices) { if (typeof v?.x !== "number" || typeof v?.z !== "number") continue; if (v.x < minX) minX = v.x; if (v.x > maxX) maxX = v.x; if (v.z < minZ) minZ = v.z; if (v.z > maxZ) maxZ = v.z; } if (isFinite(minX)) { entry._bbox = { minX, maxX, minZ, maxZ }; if (typeof entry.x !== "number") entry.x = (minX + maxX) / 2; if (typeof entry.z !== "number") entry.z = (minZ + maxZ) / 2; let rr = 0; for (const v of entry.vertices) { const dx = v.x - entry.x, dz = v.z - entry.z; const d2 = dx * dx + dz * dz; if (d2 > rr) rr = d2; } entry.radius = Math.max(entry.radius || 0, Math.sqrt(rr)); } } let chunkKeys; if (entry._bbox) { const cxMin = Math.floor(entry._bbox.minX / CHUNK), cxMax = Math.floor(entry._bbox.maxX / CHUNK), czMin = Math.floor(entry._bbox.minZ / CHUNK), czMax = Math.floor(entry._bbox.maxZ / CHUNK); chunkKeys = []; for (let cx = cxMin; cx <= cxMax; cx++) for (let cz = czMin; cz <= czMax; cz++) chunkKeys.push(cx + "," + cz); } else { const r = entry.radius || KrallikCore.Config?.CLAIM_RADIUS || 32; const cxMid = Math.floor((entry.x || 0) / CHUNK), czMid = Math.floor((entry.z || 0) / CHUNK); const spread = Math.ceil(r / CHUNK) + 1; chunkKeys = []; for (let dcx = -spread; dcx <= spread; dcx++) for (let dcz = -spread; dcz <= spread; dcz++) chunkKeys.push((cxMid + dcx) + "," + (czMid + dcz)); } for (const key of chunkKeys) { if (!this._claimByChunk[key]) this._claimByChunk[key] = []; this._claimByChunk[key].push(entry); } } },
        _pipCache: new Map(), _PIP_GRID: 4,
        _pointInPolygon(x, z, vertices) { let inside = false; for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) { const xi = vertices[i].x, zi = vertices[i].z; const xj = vertices[j].x, zj = vertices[j].z; const intersect = ((zi > z) !== (zj > z)) && (x < (xj - xi) * (z - zi) / ((zj - zi) || 1e-9) + xi); if (intersect) inside = !inside; } return inside; },
        _isPointInClaim(x, z, claim) { if (!claim) return false; if (claim.vertices && Array.isArray(claim.vertices) && claim.vertices.length >= 3) { const cid = claim.id; const gx = Math.floor(x / this._PIP_GRID), gz = Math.floor(z / this._PIP_GRID); if (cid) { const cached = this._pipCache.get(cid); if (cached && cached.gridX === gx && cached.gridZ === gz) return cached.result; } const result = this._pointInPolygon(x, z, claim.vertices); if (cid) this._pipCache.set(cid, { gridX: gx, gridZ: gz, result }); return result; } const r = claim.radius || KrallikCore.Config?.CLAIM_RADIUS || 32; const dx = x - claim.x, dz = z - claim.z; return (dx * dx + dz * dz) <= r * r; },
        invalidatePipCache(claimId) { if (claimId) this._pipCache.delete(claimId); else this._pipCache.clear(); },
        getClaimAt(loc, dimensionId) { this.getClaimCache(); const cx = Math.floor(loc.x / 16), cz = Math.floor(loc.z / 16); const key = cx + "," + cz; const chunk = this._claimByChunk[key]; if (!chunk) return null; const seen = new Set(); for (const c of chunk) { if (seen.has(c.id)) continue; seen.add(c.id); const dim = c.dimension ?? "minecraft:overworld"; if (dimensionId && dim !== dimensionId) continue; if (c._bbox) { if (loc.x < c._bbox.minX || loc.x > c._bbox.maxX || loc.z < c._bbox.minZ || loc.z > c._bbox.maxZ) continue; } else { const r = c.radius || KrallikCore.Config?.CLAIM_RADIUS || 32; const dx = loc.x - c.x, dz = loc.z - c.z; if (dx * dx + dz * dz > r * r) continue; } if (this._isPointInClaim(loc.x, loc.z, c)) return c; } return null; },
        getNearbyClaims(loc, range, dimensionId) { const claims = this.getClaimCache(); const result = [], rangeSq = range * range; for (const [id, c] of Object.entries(claims)) { const dim = (c.dimension ?? "minecraft:overworld"); if (dim !== dimensionId) continue; const dx = loc.x - c.x, dz = loc.z - c.z; if (dx * dx + dz * dz <= rangeSq) result.push({ id, ...c }); } return result; },
        invalidateClaimCache(claimId) { this._claimCache = null; this._claimCacheTime = 0; this._claimByChunk = {}; if (claimId) this.invalidatePipCache(claimId); else this.invalidatePipCache(); },
        getProfileCache(playerName, forceRefresh = false) { const now = Date.now(); const t = this._profileCacheTimeByPlayer[playerName] || 0; if (!forceRefresh && this._profileCache[playerName] && (now - t) < this.PROFILE_CACHE_DURATION) return this._profileCache[playerName]; const profile = KrallikCore.Profile?.getProfile?.(playerName) ?? null; this._profileCache[playerName] = profile; this._profileCacheTimeByPlayer[playerName] = now; return profile; },
        invalidateProfileCache(playerName) { delete this._profileCache[playerName]; delete this._profileCacheTimeByPlayer[playerName]; },
        getLeaderboardCache(forceRefresh = false) { const now = Date.now(); if (!forceRefresh && this._leaderboardCache && (now - this._leaderboardCacheTime) < this.LEADERBOARD_CACHE_DURATION) return this._leaderboardCache; try { if (typeof KrallikCore.Leaderboard?.calculateAll === "function") KrallikCore.Leaderboard.calculateAll(); } catch(e) {} const d = KrallikCore.Database.load(); this._leaderboardCache = d.leaderboard || { data: {}, weekly: {}, monthly: {}, season: {}, players: {}, kingdoms: {}, lastUpdate: 0 }; this._leaderboardCacheTime = now; return this._leaderboardCache; },
        invalidateLeaderboardCache() { this._leaderboardCache = null; this._leaderboardCacheTime = 0; }
    },

    Scheduler: {
        _intervals: {}, _tickCount: 0, _playerCount: 0, _adaptiveRates: {}, _throttledEvents: {},
        init() {
            system.runInterval(() => {
                this._tickCount++;
                KrallikCore.Performance.tick();
                try { KrallikCore.Telemetry.tick(); } catch(e) {}
                try { KrallikCore.MemoryCache.cleanup(); } catch(e) {}
                try { KrallikCore.SafeEntity.cleanup(10 * 60 * 1000); } catch(e) {}
                try { KrallikCore.Guardian.check(); } catch(e) {}
                try { KrallikCore.AllocationStormDetector.tick(); } catch(e) {}
                this._playerCount = world.getAllPlayers().length;
                this._updateAdaptiveRates();
                try { KrallikCore.EmergencyTPSDowngrade.tick(); } catch(e) {}
            }, 20);
        },
        _updateAdaptiveRates() {
            const p = this._playerCount;
            if (p === 0) this._adaptiveRates = { ai: 200, economy: 600, save: 600, siege: 80, morale: 1200, power: 2400, maintenance: 3600, event: 2400, devriye: 120, leaderboard: 1200, news: 200 };
            else if (p < 5) this._adaptiveRates = { ai: 60, economy: 200, save: 300, siege: 40, morale: 600, power: 1200, maintenance: 1800, event: 1200, devriye: 60, leaderboard: 600, news: 100 };
            else if (p < 20) this._adaptiveRates = { ai: 40, economy: KrallikCore.Config?.GELIR_ARALIK || 1200, save: 200, siege: 30, morale: 400, power: 900, maintenance: 1200, event: 800, devriye: 40, leaderboard: 400, news: 60 };
            else this._adaptiveRates = { ai: 30, economy: KrallikCore.Config?.GELIR_ARALIK || 1200, save: 150, siege: 25, morale: 300, power: 600, maintenance: 900, event: 600, devriye: 30, leaderboard: 300, news: 40 };
        },
        register(name, callback, defaultInterval) { this.unregister(name); this._intervals[name] = system.runInterval(() => { try { callback(); } catch(e) { KrallikCore.Logger.error(`Scheduler.${name}`, e); } }, defaultInterval); },
        registerAdaptive(name, callback, rateKey) { this.unregister(name); this._intervals[name] = system.runInterval(() => { const rates = this._adaptiveRates || {}; const rate = Math.max(1, rates[rateKey] || 60); if (this._tickCount % rate !== 0) return; try { callback(); } catch(e) { KrallikCore.Logger.error(`Scheduler.${name}`, e); } }, 20); },
        registerThrottled(name, callback, minInterval) { this._intervals[name] = system.runInterval(() => { const now = Date.now(); if (this._throttledEvents[name] && now - this._throttledEvents[name] < minInterval) return; this._throttledEvents[name] = now; try { callback(); } catch(e) { KrallikCore.Logger.error(`Scheduler.${name}`, e); } }, 20); },
        unregister(name) { if (this._intervals[name]) { try { system.clearRun(this._intervals[name]); } catch(e) {} delete this._intervals[name]; } },
        runLater(callback, delayTicks) { return system.runTimeout(() => { try { callback(); } catch(e) { KrallikCore.Logger.error("Scheduler.runLater", e); } }, delayTicks); }
    },

    DataRegistry: {
        _schemas: {}, _validators: {},
        registerSchema(name, schema) { this._schemas[name] = schema; },
        getSchema(name) { return this._schemas[name] || null; },
        validate(data, schemaName) {
            const schema = this._schemas[schemaName];
            if (!schema) return { valid: false, error: "Şema bulunamadı" };
            for (const [key, rule] of Object.entries(schema)) {
                if (rule.required && (data[key] === undefined || data[key] === null)) return { valid: false, error: `${key} zorunludur` };
                if (data[key] !== undefined && rule.type) {
                    const actualType = Array.isArray(data[key]) ? "array" : typeof data[key];
                    if (actualType !== rule.type && !(rule.type === "number" && actualType === "number")) return { valid: false, error: `${key} tipi ${rule.type} olmalı, ${actualType} verildi` };
                }
                if (rule.min !== undefined && data[key] < rule.min) return { valid: false, error: `${key} minimum ${rule.min} olmalı` };
                if (rule.max !== undefined && data[key] > rule.max) return { valid: false, error: `${key} maksimum ${rule.max} olmalı` };
            }
            return { valid: true };
        }
    },

    ModuleRegistry: {
        _modules: {}, _hooks: {},
        registerModule(name, module) { this._modules[name] = module; if (module.onRegister) module.onRegister(); KrallikCore.Logger.info("module", `Modül kaydedildi: ${name}`); },
        getModule(name) { return this._modules[name] || null; },
        registerHook(hookName, callback) { if (!this._hooks[hookName]) this._hooks[hookName] = []; this._hooks[hookName].push(callback); },
        executeHook(hookName, ...args) { const hooks = this._hooks[hookName] || []; for (const hook of hooks) { try { hook(...args); } catch(e) { KrallikCore.Logger.error(`Hook.${hookName}`, e); } } },
        listModules() { return Object.keys(this._modules); }
    }
};

export const Core = KrallikCore;