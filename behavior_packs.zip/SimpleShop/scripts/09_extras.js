// ============================================================
// MODÜL 09: EXTRAS - Duvar, Yedek, API, Mobile, UX, AI_Otomasyon, Integration, Security (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager } from "./02_claim.js";
import { Systems } from "./04_military.js";
import { Admin, KrallikYonetim } from "./06_kingdom.js";

// ============================================================
// KRALLIK DUVARI (SUR) - v3.0
// ============================================================
export const Duvar = {
    BASE_PRICE: 50,
    MAX_HEIGHT: 50,
    MAX_THICKNESS: 10,
    
    ALLOWED_BLOCKS: [
        { id: "minecraft:dirt", name: "Toprak", mult: 0.5 },
        { id: "minecraft:sand", name: "Kum", mult: 0.6 },
        { id: "minecraft:stone", name: "Taş", mult: 1.0 },
        { id: "minecraft:cobblestone", name: "Kırık Taş", mult: 1.2 },
        { id: "minecraft:copper_block", name: "Bakır Bloğu", mult: 2.0 },
        { id: "minecraft:deepslate", name: "Derin Taş", mult: 1.0 },
        { id: "minecraft:brick_block", name: "Tuğla", mult: 1.5 },
        { id: "minecraft:nether_brick", name: "Nether Tuğlası", mult: 2.5 }
    ],

    _genId() { return `w_${Date.now().toString(36)}_${Math.floor(Math.random() * 1e6).toString(36)}`; },

    _getMult(blockId) {
        const def = this.ALLOWED_BLOCKS.find(b => b.id === blockId);
        return def ? def.mult : null;
    },

    _isAllowedBlock(blockId) { return this._getMult(blockId) !== null; },

    _getBBoxFromClaim(claim) {
        if (!claim) return null;
        if (claim.vertices && Array.isArray(claim.vertices) && claim.vertices.length >= 3) {
            let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
            for (const v of claim.vertices) {
                if (typeof v?.x !== "number" || typeof v?.z !== "number") continue;
                if (v.x < minX) minX = v.x;
                if (v.x > maxX) maxX = v.x;
                if (v.z < minZ) minZ = v.z;
                if (v.z > maxZ) maxZ = v.z;
            }
            if (isFinite(minX)) return { minX: Math.floor(minX), maxX: Math.floor(maxX), minZ: Math.floor(minZ), maxZ: Math.floor(maxZ) };
        }
        const r = claim.radius || Config.CLAIM_RADIUS;
        return {
            minX: Math.floor((claim.x || 0) - r),
            maxX: Math.floor((claim.x || 0) + r),
            minZ: Math.floor((claim.z || 0) - r),
            maxZ: Math.floor((claim.z || 0) + r)
        };
    },

    _getPlayerKrallikAndRole(player) {
        const d = Core.Database.load();
        const kid = Systems.getPlayerKrallikId(player);
        if (!kid) return { kid: null, k: null, rol: null };
        const k = d.kralliklar?.[kid] || null;
        const rol = (k?.roller?.[player.name]) || (k?.lider === player.name ? "kral" : null);
        return { kid, k, rol };
    },

    canBuild(player, claim) {
        const { kid, k, rol } = this._getPlayerKrallikAndRole(player);
        if (!kid || !k) return { ok: false, reason: "§cÖnce bir krallığa katılmalısın." };
        if (!claim || claim.krallik !== kid) return { ok: false, reason: "§cBu claim sana ait değil." };
        if (!(rol === "kral" || rol === "yardimci" || rol === "komutan")) return { ok: false, reason: "§cSur inşası için yetkin yok (kral/yardımcı/komutan)." };
        if (!Core.Permission?.hasPermission?.(player, "duvar.*")) return { ok: false, reason: "§cSur iznin yok (duvar.*)." };
        return { ok: true };
    },

    _getWallsStore() {
        const d = Core.Database.load();
        if (!d.duvarlar) d.duvarlar = {};
        return d.duvarlar;
    },

    getWallsByClaim(claimId) {
        const store = this._getWallsStore();
        return Object.values(store).filter(w => w.claimId === claimId);
    },

    calcPrice(blockId, count) {
        const mult = this._getMult(blockId);
        if (mult == null) return null;
        return Math.floor(this.BASE_PRICE * mult * count);
    },

    _computeEdges(claim, side) {
        const bb = this._getBBoxFromClaim(claim);
        if (!bb) return [];
        const edges = [];
        const minX = bb.minX, maxX = bb.maxX, minZ = bb.minZ, maxZ = bb.maxZ;
        const add = (s, a, b, inward) => edges.push({ side: s, a, b, inward });
        if (side === "N" || side === "ALL") add("N", { x: minX, z: maxZ }, { x: maxX, z: maxZ }, { axis: "z", dir: -1 });
        if (side === "S" || side === "ALL") add("S", { x: minX, z: minZ }, { x: maxX, z: minZ }, { axis: "z", dir: +1 });
        if (side === "E" || side === "ALL") add("E", { x: maxX, z: minZ }, { x: maxX, z: maxZ }, { axis: "x", dir: -1 });
        if (side === "W" || side === "ALL") add("W", { x: minX, z: minZ }, { x: minX, z: maxZ }, { axis: "x", dir: +1 });
        return edges;
    },

    _sliceFillCommands(edge, baseY, height, thickness, blockId, lengthOverride) {
        const fills = [];
        const ax = edge.a.x, az = edge.a.z, bx = edge.b.x, bz = edge.b.z;
        const len = Math.max(Math.abs(bx - ax), Math.abs(bz - az)) + 1;
        const targetLen = lengthOverride && lengthOverride > 0 ? Math.min(len, lengthOverride) : len;
        const startOffset = Math.floor((len - targetLen) / 2);
        const endOffset = startOffset + targetLen - 1;
        const y1 = baseY;
        const y2 = baseY + height - 1;
        const maxVol = 32000;
        const sliceLen = Math.max(1, Math.floor(maxVol / Math.max(1, height * thickness)));
        const step = Math.min(256, sliceLen);
        const isXLine = az === bz;
        const dir = (isXLine) ? (bx >= ax ? 1 : -1) : (bz >= az ? 1 : -1);
        const coordAt = (o) => {
            const t = o;
            const x = isXLine ? (ax + dir * t) : ax;
            const z = isXLine ? az : (az + dir * t);
            return { x, z };
        };
        for (let o = startOffset; o <= endOffset; o += step) {
            const o2 = Math.min(endOffset, o + step - 1);
            const p1 = coordAt(o);
            const p2 = coordAt(o2);
            let x1 = p1.x, z1 = p1.z, x2 = p2.x, z2 = p2.z;
            if (edge.inward.axis === "x") {
                const dx = edge.inward.dir * (thickness - 1);
                x1 = Math.min(x1, x1 + dx); x2 = Math.max(x2, x2 + dx);
            } else {
                const dz = edge.inward.dir * (thickness - 1);
                z1 = Math.min(z1, z1 + dz); z2 = Math.max(z2, z2 + dz);
            }
            const fx1 = Math.min(x1, x2), fx2 = Math.max(x1, x2);
            const fz1 = Math.min(z1, z2), fz2 = Math.max(z1, z2);
            fills.push({ fx1, y1, fz1, fx2, y2, fz2, blockId });
        }
        return { fills, targetLen };
    },

    _runFillQueue(dim, fills, onDone) {
        let i = 0;
        const run = () => {
            if (i >= fills.length) { if (onDone) onDone(); return; }
            const f = fills[i++];
            try { dim.runCommandAsync(`fill ${f.fx1} ${f.y1} ${f.fz1} ${f.fx2} ${f.y2} ${f.fz2} ${f.blockId} replace air`); } catch(e) {}
            Core.Scheduler?.runLater?.(run, 1);
        };
        run();
    },

    _runCmdQueue(dim, cmds, onDone) {
        let i = 0;
        const run = () => {
            if (i >= cmds.length) { if (onDone) onDone(); return; }
            const cmd = cmds[i++];
            try { dim.runCommandAsync(cmd); } catch(e) {}
            Core.Scheduler?.runLater?.(run, 1);
        };
        run();
    },

    build(player, params) {
        const { claimId, blockId, height, thickness, length, side } = params;
        const d = Core.Database.load();
        const claim = d.claimler?.[claimId];
        if (!claim) return { ok: false, reason: "§cClaim bulunamadı." };
        const auth = this.canBuild(player, claim);
        if (!auth.ok) return auth;
        if (!this._isAllowedBlock(blockId)) return { ok: false, reason: "§cBu blok sur için izinli değil." };
        const h = Core.Utils?.clamp?.(Math.floor(height || 1), 1, this.MAX_HEIGHT) || Math.min(50, Math.max(1, Math.floor(height || 1)));
        const t = Core.Utils?.clamp?.(Math.floor(thickness || 1), 1, this.MAX_THICKNESS) || Math.min(10, Math.max(1, Math.floor(thickness || 1)));
        const lenOverride = (length === "claim çevresi" || length === "claim cevresi") ? null : Math.max(1, Math.floor(Number(length || 0) || 0));
        const baseY = Math.floor(player.location.y);
        const edges = this._computeEdges(claim, side || "ALL");
        if (edges.length === 0) return { ok: false, reason: "§cClaim sınırı hesaplanamadı." };
        let fillsAll = [];
        let totalLen = 0;
        for (const e of edges) {
            const { fills, targetLen } = this._sliceFillCommands(e, baseY, h, t, blockId, lenOverride);
            totalLen += targetLen;
            fillsAll = fillsAll.concat(fills);
        }
        const totalBlocks = totalLen * h * t;
        const price = this.calcPrice(blockId, totalBlocks);
        if (price == null) return { ok: false, reason: "§cFiyat hesaplanamadı." };
        const zmc = Systems.getZMC(player);
        if (zmc < price) return { ok: false, reason: `§cYetersiz ZMC. Gereken: ${price.toLocaleString()} ZMC` };
        Systems.removeZMC(player, price);
        const id = this._genId();
        const store = this._getWallsStore();
        store[id] = {
            id, claimId, krallikId: claim.krallik, side: side || "ALL",
            height: h, thickness: t, length: lenOverride || "claim çevresi",
            blockId, baseY, createdAt: Date.now(), createdBy: player.name
        };
        Core.Database.markDirty("krallik_duvarlar");
        this._runFillQueue(player.dimension, fillsAll, () => {
            Systems.sendMessage(player, `§a✔ Sur inşası tamamlandı! §7(${totalBlocks.toLocaleString()} blok)`);
        });
        return { ok: true, price, totalBlocks };
    },

    removeWall(player, wallId) {
        const store = this._getWallsStore();
        const w = store?.[wallId];
        if (!w) return { ok: false, reason: "§cSur kaydı bulunamadı." };
        const d = Core.Database.load();
        const claim = d.claimler?.[w.claimId];
        if (!claim) return { ok: false, reason: "§cClaim bulunamadı." };
        const { kid, rol } = this._getPlayerKrallikAndRole(player);
        const isAdmin = Systems.isAdmin(player);
        if (!isAdmin) {
            if (!kid || kid !== claim.krallik) return { ok: false, reason: "§cSadece sahibi krallık suru kaldırabilir." };
            if (!(rol === "kral" || rol === "yardimci" || rol === "komutan")) return { ok: false, reason: "§cSur kaldırma yetkin yok." };
            if (!Core.Permission?.hasPermission?.(player, "duvar.*")) return { ok: false, reason: "§cSur iznin yok." };
        }
        const baseY = Math.floor(w.baseY || player.location.y);
        const h = Core.Utils?.clamp?.(Math.floor(w.height || 1), 1, this.MAX_HEIGHT) || Math.min(50, Math.max(1, Math.floor(w.height || 1)));
        const t = Core.Utils?.clamp?.(Math.floor(w.thickness || 1), 1, this.MAX_THICKNESS) || Math.min(10, Math.max(1, Math.floor(w.thickness || 1)));
        const lenOverride = (w.length === "claim çevresi" || w.length === "claim cevresi") ? null : Math.max(1, Math.floor(Number(w.length || 0) || 0));
        const edges = this._computeEdges(claim, w.side || "ALL");
        if (edges.length === 0) return { ok: false, reason: "§cSınır hesaplanamadı." };
        const cmds = [];
        for (const e of edges) {
            const { fills } = this._sliceFillCommands(e, baseY, h, t, "minecraft:air", lenOverride);
            for (const f of fills) cmds.push(`fill ${f.fx1} ${f.y1} ${f.fz1} ${f.fx2} ${f.y2} ${f.fz2} minecraft:air replace ${w.blockId}`);
        }
        delete store[wallId];
        Core.Database.markDirty("krallik_duvarlar");
        this._runCmdQueue(player.dimension, cmds, () => { Systems.sendMessage(player, "§a✔ Sur kaldırıldı."); });
        return { ok: true };
    },

    _isLocInsideWallRecord(loc, wall) {
        if (!loc || !wall) return false;
        const y = Math.floor(loc.y);
        if (y < (wall.baseY || 0) || y > (wall.baseY || 0) + (wall.height || 1) - 1) return false;
        const d = Core.Database.load();
        const claim = d.claimler?.[wall.claimId];
        if (!claim) return false;
        const bb = this._getBBoxFromClaim(claim);
        if (!bb) return false;
        const x = Math.floor(loc.x), z = Math.floor(loc.z);
        const t = Math.max(1, wall.thickness || 1);
        if (wall.side === "N") return (z <= bb.maxZ && z >= bb.maxZ - (t - 1) && x >= bb.minX && x <= bb.maxX);
        if (wall.side === "S") return (z >= bb.minZ && z <= bb.minZ + (t - 1) && x >= bb.minX && x <= bb.maxX);
        if (wall.side === "E") return (x <= bb.maxX && x >= bb.maxX - (t - 1) && z >= bb.minZ && z <= bb.maxZ);
        if (wall.side === "W") return (x >= bb.minX && x <= bb.minX + (t - 1) && z >= bb.minZ && z <= bb.maxZ);
        if (wall.side === "ALL") {
            const onN = (z <= bb.maxZ && z >= bb.maxZ - (t - 1) && x >= bb.minX && x <= bb.maxX);
            const onS = (z >= bb.minZ && z <= bb.minZ + (t - 1) && x >= bb.minX && x <= bb.maxX);
            const onE = (x <= bb.maxX && x >= bb.maxX - (t - 1) && z >= bb.minZ && z <= bb.maxZ);
            const onW = (x >= bb.minX && x <= bb.minX + (t - 1) && z >= bb.minZ && z <= bb.maxZ);
            return onN || onS || onE || onW;
        }
        return false;
    },

    findWallAt(loc, dimensionId) {
        const store = this._getWallsStore();
        for (const w of Object.values(store)) {
            const d = Core.Database.load();
            const claim = d.claimler?.[w.claimId];
            if (!claim) continue;
            if (dimensionId && claim.dimension && claim.dimension !== dimensionId) continue;
            if (this._isLocInsideWallRecord(loc, w)) return w;
        }
        return null;
    },

    canBreak(player, loc) {
        const w = this.findWallAt(loc, player.dimension.id);
        if (!w) return { isWall: false, ok: true };
        const d = Core.Database.load();
        const claim = d.claimler?.[w.claimId];
        if (!claim) return { isWall: true, ok: true };
        const pKid = Systems.getPlayerKrallikId(player);
        if (pKid && pKid === claim.krallik) return { isWall: true, ok: true };
        const hasPerm = ClaimManager?.hasPermission?.(claim.id, player.name);
        if (hasPerm) return { isWall: true, ok: true };
        const attacker = d.kralliklar?.[pKid];
        const defender = d.kralliklar?.[claim.krallik];
        const atWar = !!(attacker?.savaslar?.includes(claim.krallik) || defender?.savaslar?.includes(pKid));
        const siegeActive = !!(claim.id && d.sieges?.[claim.id]);
        if (atWar || siegeActive) return { isWall: true, ok: true };
        return { isWall: true, ok: false, reason: "§cSur sadece savaş/kuşatma sırasında veya izinliyken kırılabilir." };
    },

    onClaimDeleted(claimId) {
        const store = this._getWallsStore();
        let changed = false;
        for (const [id, w] of Object.entries(store)) {
            if (w.claimId === claimId) { delete store[id]; changed = true; }
        }
        if (changed) Core.Database.markDirty("krallik_duvarlar");
    }
};

// ============================================================
// YEDEKLEME SİSTEMİ (Backup)
// ============================================================
export const Backup = {
    create(type = "auto", actor = "system") {
        const d = Core.Database.load();
        d.adminAyarlari = d.adminAyarlari || {};
        d.adminAyarlari.backups = d.adminAyarlari.backups || [];
        const payloadObj = {
            kralliklar: d.kralliklar,
            oyuncular: d.oyuncular,
            claimler: d.claimler,
            askerKayit: d.askerKayit
        };
        const payload = JSON.stringify(payloadObj);
        const id = `b_${Date.now()}`;
        d.adminAyarlari.backups.unshift({ id, type, actor, t: Date.now(), payload });
        if (d.adminAyarlari.backups.length > 20) d.adminAyarlari.backups.length = 20;
        Core.Database.markDirty("krallik_admin");
        return id;
    },

    listBackups() {
        const d = Core.Database.load();
        return (d.adminAyarlari?.backups || []).map(b => ({
            id: b.id, t: b.t, type: b.type, actor: b.actor,
            label: `${b.type === "auto" ? "Otomatik" : "Manuel"} – ${new Date(b.t).toLocaleString("tr-TR")}`
        }));
    },

    restore(backupId) {
        const d = Core.Database.load();
        const a = d.adminAyarlari || {};
        const snap = (a.backups || []).find(b => b.id === backupId);
        if (!snap) return false;
        try {
            const parsed = JSON.parse(snap.payload);
            Object.assign(d.kralliklar, parsed.kralliklar || {});
            Object.assign(d.oyuncular, parsed.oyuncular || {});
            Object.assign(d.claimler, parsed.claimler || {});
            Object.assign(d.askerKayit, parsed.askerKayit || {});
            Core.Database.markDirty("krallik_core");
            Core.Database.markDirty("krallik_claims");
            Core.Database.markDirty("krallik_army");
            return true;
        } catch(e) { return false; }
    },

    autoBackup() { return this.create("auto"); },
    manualBackup(actor = "admin") { return this.create("manual", actor); }
};

// ============================================================
// API SİSTEMİ (Entegrasyon)
// ============================================================
export const API = {
    registerModule(name, module) { Core.ModuleRegistry?.registerModule?.(name, module); },
    Commands: {
        _cmd: {},
        register(name, handler) { this._cmd[name] = handler; },
        execute(name, ctx) { if (this._cmd[name]) return this._cmd[name](ctx); return null; }
    },
    Events: {
        on(hookName, cb) { Core.ModuleRegistry?.registerHook?.(hookName, cb); },
        emit(hookName, ...args) { Core.ModuleRegistry?.executeHook?.(hookName, ...args); }
    }
};

// ============================================================
// MOBİL & DOKUNMATİK DESTEĞİ
// ============================================================
export const Mobile = {
    setBuyukButon(playerName, aktif) { return Core.Profile?.setSetting?.(playerName, "buyukButon", !!aktif); },
    setSwipe(playerName, aktif) { return Core.Profile?.setSetting?.(playerName, "swipeMenu", !!aktif); },
    setUzunBasma(playerName, aktif) { return Core.Profile?.setSetting?.(playerName, "uzunBasma", !!aktif); },
    setElModu(playerName, mode) { return Core.Profile?.setSetting?.(playerName, "elModu", mode); },
    setSesliKomut(playerName, aktif) { return Core.Profile?.setSetting?.(playerName, "sesliKomut", !!aktif); }
};

// ============================================================
// KULLANICI DENEYİMİ (UX)
// ============================================================
export const UX = {
    tutorialGoster(player) {
        if (!player) return;
        Systems.sendMessage(player, "§e📘 Rehber: / Krallık kur → Claim al → Ordu kur → Ekonomi geliştir → Diplomasi/Savaş!");
        Systems.sendMessage(player, "§7İpucu: Krallık menüsü için krallik:trigger itemini kullan.");
    },
    tooltip(id) {
        const tips = {
            claim: "Claim: Bölge koruması ve yönetim.",
            market: "Market: Dinamik fiyatlar ve borsa etkisi.",
            savas: "Savaş: Kuşatma, tazminat, esir ve kahramanlık."
        };
        return tips[id] || "";
    },
    playSound(player, soundId = "random.click") {
        try { world.getDimension(player.dimension.id).runCommandAsync(`playsound ${soundId} "${player.name}"`); } catch(e) {}
    },
    anim(player, type = "menu") {
        if (!player) return;
        if (type === "menu") Systems.runCommand(player, "particle minecraft:basic_flame_particle ~ ~1 ~");
    },
    renkKoruMod(playerName, aktif) { return Core.Profile?.setSetting?.(playerName, "renkKoru", !!aktif); },
    yuksekKontrast(playerName, aktif) { return Core.Profile?.setSetting?.(playerName, "yuksekKontrast", !!aktif); }
};

// ============================================================
// ENTEGRASYON (Integration) - Veri Dışa Aktarma
// ============================================================
export const Integration = {
    Export: {
        toJSON() { const d = Core.Database.load(); return JSON.stringify(d); },
        toCSVLogs(limit = 100) {
            const d = Core.Database.load();
            const logs = (d.logs || []).slice(0, limit);
            const header = "timestamp,level,category,message,actor,target";
            const rows = logs.map(l => [l.timestamp, l.level, l.category, (l.message || "").replace(/,/g, ";"), l.actor, l.target].join(","));
            return [header, ...rows].join("\n");
        }
    }
};

// ============================================================
// GÜVENLİK (Security) - Checksum ve Basit Şifreleme
// ============================================================
export const Security = {
    checksum(str) {
        str = String(str || "");
        let h = 5381;
        for (let i = 0; i < str.length; i++) h = ((h << 5) + h) + str.charCodeAt(i);
        return (h >>> 0).toString(16);
    },
    encrypt(str, key = "krallik") {
        str = String(str || "");
        let out = "";
        for (let i = 0; i < str.length; i++) out += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
        return out;
    },
    decrypt(enc, key = "krallik") { return this.encrypt(enc, key); }
};

// ============================================================
// AI OTOMASYON (AI Vali)
// ============================================================
export const AI_Otomasyon = {
    tick() {
        const d = Core.Database.load();
        for (const [kid, k] of Object.entries(d.kralliklar || {})) {
            if (!k?.aiVali?.aktif) continue;
            const asker = Core.Cache?.getKrallikEntityCount?.(kid) || 0;
            if (asker < 5) k.takviyeTalebi = { t: Date.now(), type: "soldier", hedef: 10 };
            if ((k.hazine || 0) < 0) k.VERGI_ORAN = (k.VERGI_ORAN || Config.VERGI_ORAN) + 1;
            k.aiGenişleme = k.aiGenişleme || { aktif: true, son: 0 };
            if (Date.now() - (k.aiGenişleme.son || 0) > 30 * 60 * 1000) {
                k.aiGenişleme.son = Date.now();
                k.aiGenişleme.oneri = "Yeni claim alın (yakın boş alan).";
            }
        }
        Core.Database.markDirty("krallik_core");
    }
};