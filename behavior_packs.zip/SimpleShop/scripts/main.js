// ============================================================
// KRALLIK FRAMEWORK v6.0 - ANA GİRİŞ (MODÜLER TAM SÜRÜM)
// ============================================================
import { world, system } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager, ClaimHarita } from "./02_claim.js";
import { Economy, Market, TradeRoute, EkonomiEk } from "./03_economy.js";
import { Systems, AI, Combat, Morale, Siege, Formasyon, Devriye } from "./04_military.js";
import { Diplomacy, Vassal, Hero, KrallikBildirim } from "./05_diplomacy.js";
import { KrallikYonetim, Profile, Leaderboard, News, SavasRaporu, Alarm, LogSistemi, Admin } from "./06_kingdom.js";
// 07_ui.js 07_ui2.js tarafından zaten import ediliyor (UI2 = { ...UI1, ...kendi })
import { UI as UI2 } from "./07_ui2.js";
import { Customize, Debug } from "./08_customize.js";
import { Duvar, Backup, API, Mobile, UX, Integration, Security, AI_Otomasyon } from "./09_extras.js";
import { Power } from "./10_power.js";
import { EventManager, Events, SpecialEvents } from "./11_events.js";
import { GelisimAgaci, Permission, KrallikIstatistik } from "./12_gelisim.js";
import { Inventory, ItemHandlers, ChestSystem, BlockValueSystem } from "./13_inventory.js";
import { Maintenance, AutoSave, PerformanceMonitor, DataOptimizer, EmergencyRecovery } from "./maintenance.js";
import { Patch } from "./patch.js";

// UI2 zaten 07_ui.js'in tüm fonksiyonlarını içeriyor
const FullUI = UI2;

// ============================================================
// TÜM MODÜLLERİ TEK BİR KRALLIK NESNESİNDE TOPLA
// ============================================================
const Krallik = {
    ...Core,
    Config,
    ClaimManager, ClaimHarita,
    Economy, Market, TradeRoute, EkonomiEk,
    Systems, AI, Combat, Morale, Siege, Formasyon, Devriye,
    Diplomacy, Vassal, Hero, KrallikBildirim,
    KrallikYonetim, Profile, Leaderboard, News, SavasRaporu, Alarm, LogSistemi, Admin,
    UI: FullUI,
    Customize, Debug,
    Duvar, Backup, API, Mobile, UX, Integration, Security, AI_Otomasyon,
    Power,
    EventManager, Events, SpecialEvents,
    GelisimAgaci, Permission, KrallikIstatistik,
    Inventory, ItemHandlers, ChestSystem, BlockValueSystem,
    Maintenance, AutoSave, PerformanceMonitor, DataOptimizer, EmergencyRecovery,
    Patch,
};

globalThis.Krallik = Krallik;

// ============================================================
// OLAY DİNLEYİCİLERİ ve BAŞLATMA
// ============================================================

world.beforeEvents.worldInitialize.subscribe((initEvent) => {
    // Krallık ana menü item'ı
    initEvent.itemComponentRegistry.registerCustomComponent("krallik:trigger", {
        onUse: (e) => { system.run(() => Krallik.UI.anaMenu(e.source)); }
    });

    // Market item'ı
    initEvent.itemComponentRegistry.registerCustomComponent("invshop:trigger", {
        onUse: (e) => { system.run(() => Krallik.UI.marketMenusu(e.source)); }
    });

    Krallik.Logger?.info?.("system", "Custom component'ler kaydedildi (krallik, invshop, zmc)");
});

// afterEvents.itemUse: custom component olmayan eski item tiplerine de destek
world.afterEvents.itemUse.subscribe((e) => {
    const typeId = e.itemStack?.typeId;
    if (typeId === "krallik:trigger") {
        system.run(() => Krallik.UI.anaMenu(e.source));
    } else if (typeId === "invshop:trigger") {
        system.run(() => Krallik.UI.marketMenusu(e.source));
    }
    Krallik.ItemHandlers?.handleItemUse?.(e.source, e.itemStack);
});

world.afterEvents.playerSpawn.subscribe((e) => {
    Krallik.Database.reloadPlayer(e.player.name);
    Krallik.Inventory?.giveItems?.(e.player);
    Krallik.Profile?.initializeProfile?.(e.player.name);

    try {
        e.player._onlineStart = Date.now();
        Krallik.Profile._onlineStarts = Krallik.Profile._onlineStarts || {};
        Krallik.Profile._onlineStarts[e.player.name] = e.player._onlineStart;
    } catch (err) {}

    Krallik.Logger?.info?.("system", `${e.player.name} oyuncu spawn oldu`);
});

world.afterEvents.playerLeave.subscribe((e) => {
    const name = e.playerName || e.player?.name;
    if (!name) return;
    const start = e.player?._onlineStart || Krallik.Profile?._onlineStarts?.[name];
    if (start) {
        const seconds = Math.floor((Date.now() - start) / 1000);
        if (seconds > 0) Krallik.Profile?.addOnlineTime?.(name, seconds);
    }
    if (Krallik.Profile?._onlineStarts) delete Krallik.Profile._onlineStarts[name];
    Krallik.Logger?.info?.("system", `${name} oyuncu çıktı`);
});

world.afterEvents.entityHurt.subscribe((e) => {
    let dmg = e.damage;
    try {
        if ((e.damageSource?.damagingEntity?.getTags?.() || []).includes("hero_bonus")) {
            dmg = Math.floor(dmg * 1.20);
        }
    } catch {}
    Krallik.Combat?.onEntityHurt?.(e.hurtEntity, dmg, e.damageSource?.damagingEntity);
});

world.afterEvents.entityDie.subscribe((e) => {
    try { Krallik.Hero?.onHeroDeath?.(e.deadEntity?.id); } catch {}
    Krallik.Combat?.onEntityDeath?.(e.deadEntity);
});

world.beforeEvents.playerBreakBlock.subscribe((e) => {
    try {
        if (Krallik.ClaimManager?.isProtected?.(e.player, e.block.location)) {
            e.cancel = true;
            Krallik.Systems?.sendMessage?.(e.player, "§cBu bölge başka krallığa ait!");
            const claim = Krallik.ClaimManager?.getClaimAt?.(e.block.location, e.player.dimension.id);
            if (claim) Krallik.Alarm?.triggerBlockBreakAlarm?.(claim.krallik, e.player.name, e.block.typeId);
        }
    } catch (_) {}

    try {
        const chk = Krallik.Duvar?.canBreak?.(e.player, e.block.location);
        if (chk?.isWall && !chk.ok) {
            e.cancel = true;
            Krallik.Systems?.sendMessage?.(e.player, chk.reason || "§cBu sur kırılamaz.");
        }
    } catch (_) {}
});

world.beforeEvents.playerPlaceBlock.subscribe((e) => {
    try {
        if (Krallik.ClaimManager?.isProtected?.(e.player, e.block.location)) {
            e.cancel = true;
            Krallik.Systems?.sendMessage?.(e.player, "§cBu bölge başka krallığa ait!");
        }
    } catch (_) {}
});

world.beforeEvents.itemDrop.subscribe((e) => {
    Krallik.Inventory?.preventDrop?.(e);
});

// ============================================================
// SCHEDULER KAYITLARI
// ============================================================
function registerSchedulers() {
    Krallik.Scheduler?.registerAdaptive?.("economy_tick", () => Krallik.Economy?.tick?.(), "economy");
    Krallik.Scheduler?.registerAdaptive?.("borsa_tick", () => Krallik.EkonomiEk?.borsaTick?.(), "economy");
    Krallik.Scheduler?.registerAdaptive?.("ai_tick", () => Krallik.AI?.tickAll?.(), "ai");
    Krallik.Scheduler?.registerAdaptive?.("siege_tick", () => Krallik.Siege?.tick?.(), "siege");
    Krallik.Scheduler?.registerAdaptive?.("morale_update", () => {
        const d = Krallik.Database?.load?.();
        if (d?.kralliklar) {
            for (const id of Object.keys(d.kralliklar)) Krallik.Morale?.update?.(id);
        }
    }, "morale");
    Krallik.Scheduler?.registerAdaptive?.("formasyon_tick", () => Krallik.Formasyon?.formasyonTick?.(), "combat");
    Krallik.Scheduler?.registerAdaptive?.("devriye_tick", () => Krallik.Devriye?.devriyeTick?.(), "devriye");
    Krallik.Scheduler?.registerAdaptive?.("claim_tick", () => Krallik.ClaimManager?.tick?.(), "maintenance");
    Krallik.Scheduler?.registerAdaptive?.("power_update", () => {
        const d = Krallik.Database?.load?.();
        if (d?.kralliklar) {
            for (const id of Object.keys(d.kralliklar)) Krallik.Power?.calculateKrallikPower?.(id);
        }
        Krallik.Power?.recordPowerHistory?.();
    }, "power");
    Krallik.Scheduler?.registerAdaptive?.("leaderboard_update", () => Krallik.Leaderboard?.calculateAll?.(), "leaderboard");
    Krallik.Scheduler?.registerAdaptive?.("events_tick", () => Krallik.Events?.tick?.(), "event");
    Krallik.Scheduler?.registerAdaptive?.("event_manager_tick", () => Krallik.EventManager?.tick?.(), "event");
    Krallik.Scheduler?.registerAdaptive?.("maintenance_tick", () => Krallik.Maintenance?.runAll?.(), "maintenance");
    Krallik.Scheduler?.registerAdaptive?.("auto_save", () => Krallik.AutoSave?.save?.(), "save");
    Krallik.Scheduler?.register?.("cache_cleanup", () => Krallik.Cache?.getEntities?.(true), 1200);
    Krallik.Scheduler?.register?.("rate_limiter_cleanup", () => Krallik.RateLimiter?.cleanup?.(), 400);
    Krallik.Scheduler?.register?.("inventory_check", () => Krallik.Inventory?.checkAllPlayers?.(), 100);
    Krallik.Scheduler?.registerAdaptive?.("ai_vali_tick", () => Krallik.AI_Otomasyon?.tick?.(), "economy");
    Krallik.Scheduler?.register?.("auto_backup", () => Krallik.Backup?.autoBackup?.(), 432000);
    Krallik.Scheduler?.register?.("performance_check", () => Krallik.PerformanceMonitor?.check?.(), 200);
    Krallik.Scheduler?.register?.("data_optimizer", () => Krallik.DataOptimizer?.run?.(), 43200);

    Krallik.Logger?.info?.("system", "Tüm scheduler'lar kaydedildi");
}

// ============================================================
// BAŞLATMA — system.run() ile early-execution dışına alındı
// ============================================================
function startKrallik() {
    try {
        Krallik.Database?.load?.();
        // ZMC (para) skor tablosunun en başta hazır olduğundan emin ol.
        // Daha önce sadece Systems._getZmcObjective() çağrıldığında (yani bir
        // oyuncunun bakiyesi okunduğunda) lazy olarak oluşturuluyordu. Bu yüzden
        // Admin.paraVer/paraAl gibi objective'i doğrudan okuyan fonksiyonlar,
        // henüz hiç oluşturulmamışsa sessizce hiçbir şey yapmıyordu.
        Krallik.Patch?.init?.();
        Krallik.Scheduler?.init?.();
        registerSchedulers();
        Krallik.ItemHandlers?.registerDefaultHandlers?.();
        Krallik.CoreRuntime?.start?.();
        Krallik.EmergencyRecovery?.recoverFromCorruption?.();
        Krallik.Customize?.applyConfigOverrides?.();
        Krallik.Guardian?.init?.();

        Krallik.Logger?.info?.("system", "§a[Krallik Framework v6.0] Modüler sistem başarıyla başlatıldı!");
        console.log("§a[Krallik Framework v6.0] Tüm sistemler başarıyla başlatıldı!");
    } catch (e) {
        console.error("§c[Krallik Framework] Başlatma hatası:", e);
        Krallik.Logger?.error?.("system", e);
        try { Krallik.EmergencyRecovery?.emergencyRestart?.(); } catch (e2) {}
    }
}

// Early-execution kısıtlamasından kaçınmak için system.run ile erteleniyor
system.run(() => startKrallik());
