// ============================================================
// MODÜL 01: CONFIG - Tüm Sabitler (EKSİKSİZ)
// ============================================================
export const KrallikConfig = {
    CLAIM_RADIUS: 32,
    CLAIM_WARNING_RANGE: 64,
    MIN_BAYRAK_MESAFE: 10,
    MAX_CLAIM_LEVEL: 5,
    MAX_SOLDIER_LEVEL: 10,

    GELIR_ARALIK: 1200,
    ASKER_MAAS: 50,
    VERGI_ORAN: 5,
    CACHE_DURATION: 3000,
    SAVE_INTERVAL: 300,

    SIEGE_CAPTURE_TIME: 120,
    SIEGE_CONTEST_RANGE: 50,
    SIEGE_DEFENSE_BONUS: 1.5,

    MAX_TREATIES: 10,
    TRUST_DECAY_RATE: 0.1,

    AI_SEARCH_RANGE: 32,
    AI_AGGRO_RANGE: 16,
    AI_VIEW_RANGE: 64,
    AI_RETREAT_HP: 0.25,
    AI_MORALE_RETREAT: 25,
    AI_TARGET_MEMORY: 100,
    AI_COMBAT_CHECK: 20,
    AI_TICK_SPREAD: 4,
    AI_SLEEP_DISTANCE: 64,

    CLAIM_SHIELD_DURATION: 3600,
    CLAIM_MAINTENANCE_INTERVAL: 72000,

    MAX_LOGS: 500,
    LOG_CLEANUP_AGE: 604800000,

    SEVIYE_GEREKLERI: [
        { seviye: 1, askerLimiti: 70, maxYardimci: 1, maxToprak: 3, seviyeUcreti: 0, marketKapasite: 10, stokLimiti: 100, claimBonusRadius: 0 },
        { seviye: 2, askerLimiti: 140, maxYardimci: 2, maxToprak: 6, seviyeUcreti: 5000, marketKapasite: 25, stokLimiti: 250, claimBonusRadius: 3 },
        { seviye: 3, askerLimiti: 250, maxYardimci: 3, maxToprak: 10, seviyeUcreti: 15000, marketKapasite: 50, stokLimiti: 500, claimBonusRadius: 5 },
        { seviye: 4, askerLimiti: 400, maxYardimci: 4, maxToprak: 15, seviyeUcreti: 40000, marketKapasite: 80, stokLimiti: 1000, claimBonusRadius: 8 },
        { seviye: 5, askerLimiti: 700, maxYardimci: 5, maxToprak: 20, seviyeUcreti: 100000, marketKapasite: 120, stokLimiti: 2000, claimBonusRadius: 12 }
    ],

    ASKER_RANKLARI: [
        { min: 0, rank: "Acemi", emoji: "🔰", bonus: 1.0, speedBonus: 1.0, viewBonus: 1.0 },
        { min: 5, rank: "Kıdemli", emoji: "⭐", bonus: 1.2, speedBonus: 1.05, viewBonus: 1.1 },
        { min: 15, rank: "Uzman", emoji: "🌟", bonus: 1.4, speedBonus: 1.1, viewBonus: 1.2 },
        { min: 40, rank: "Elit", emoji: "💎", bonus: 1.6, speedBonus: 1.15, viewBonus: 1.35 },
        { min: 100, rank: "Muhafız", emoji: "🛡️", bonus: 2.0, speedBonus: 1.25, viewBonus: 1.5 }
    ],

    ASKERLER: {
        soldier: { id: "soldier", name: "Piyade", emoji: "⚔️", fiyat: 3000, hp: 20, damage: 4, speed: 1.15, range: 1.5, armor: 0, type: "melee", category: "melee", limitCost: 1, bakim: 10, entityType: "soldier", fallbackEntity: "minecraft:husk" },
        cuirassier: { id: "cuirassier", name: "Süvari", emoji: "🐴", fiyat: 5000, hp: 30, damage: 7, speed: 2.1, range: 1.5, armor: 2, type: "cavalry", category: "cavalry", limitCost: 2, bakim: 20, entityType: "cuirassier", chargeBonus: 1.5, fallbackEntity: "minecraft:zombie_horse" },
        gunner: { id: "gunner", name: "Topçu", emoji: "💣", fiyat: 4500, hp: 22, damage: 8, speed: 0.8, range: 20, armor: 1, type: "ranged", category: "ranged", limitCost: 1.5, bakim: 15, entityType: "gunner", reloadTime: 60, siege: true, fallbackEntity: "minecraft:skeleton" }
    },

    // NapoleonicMergedBp paketindeki gerçek ülke-bazlı asker modelleri.
    // askerAlMenusu() bu haritadan krallığın ulkeTipi'ne göre doğru entity'yi seçer.
    // Eşleşme bulunamazsa ASKERLER[].fallbackEntity (vanilla mob) kullanılır.
    ASKER_ENTITY_MAP: {
        british: { soldier: "knights:british_soldier", cuirassier: "knights:british_cuirassier", gunner: "knights:british_gunner" },
        french: { soldier: "knights:french_soldier", cuirassier: "knights:french_cuirassier", gunner: "knights:french_gunner" },
        german: { soldier: "knights:german_soldier", cuirassier: "knights:german_cuirassier", gunner: "knights:german_gunner" },
        russian: { soldier: "knights:russian_soldier", cuirassier: "knights:russian_cuirassier", gunner: "knights:russian_gunner" },
        italian: { soldier: "knights:italian_soldier", cuirassier: "knights:italian_cuirassier", gunner: "knights:italian_gunner" },
        spanish: { soldier: "knights:spanish_soldier", cuirassier: "knights:spanish_cuirassier", gunner: "knights:spanish_gunner" }
    },

    // Krallık tarafından alınan (yani "tamed"/sahipli) askerler bu event ile
    // vahşi canavar-saldırı davranışından çıkıp sadece komutla saldıran pasif moda geçer.
    ASKER_RECRUIT_EVENT: "knights:recruited_event",
    // AI bir hedefe saldırı emri verdiğinde hedefe eklenen, entity JSON'larındaki
    // tame davranışının izlemesine izin verdiği işaret tag'i.
    ASKER_HEDEF_TAG: "knights_emir_hedefi",

    ULKELER: {
        british: { id: "british", name: "İngiliz", emoji: "🏴", bonus: { gunnerAccuracy: 1.2, defense: 1.15 } },
        french: { id: "french", name: "Fransız", emoji: "🏴", bonus: { speed: 1.1, morale: 1.2 } },
        german: { id: "german", name: "Alman", emoji: "🏴", bonus: { armor: 1.15, damage: 1.1 } },
        russian: { id: "russian", name: "Rus", emoji: "🏴", bonus: { durability: 1.25, gunnerPower: 1.15 } },
        italian: { id: "italian", name: "İtalyan", emoji: "🏴", bonus: { speed: 1.2, cost: 0.85 } },
        spanish: { id: "spanish", name: "İspanyol", emoji: "🏴", bonus: { armySize: 1.1, defense: 1.1 } }
    },

    MARKET_ITEMS: {
        mancinik: { id: "mancinik", name: "Mancınık", emoji: "🏗️", basePrice: 50000, category: "siege", stockLimit: 5, warMultiplier: 2.0 },
        cephane: { id: "cephane", name: "Cephane", emoji: "🔫", basePrice: 500, category: "consumable", stockLimit: 100, warMultiplier: 1.8 },
        barut: { id: "barut", name: "Barut", emoji: "💥", basePrice: 800, category: "consumable", stockLimit: 80, warMultiplier: 1.5 },
        siper_kit: { id: "siper_kit", name: "Siper Kiti", emoji: "🛡️", basePrice: 3000, category: "defense", stockLimit: 20, warMultiplier: 1.3 },
        top_mermisi: { id: "top_mermisi", name: "Top Mermisi", emoji: "🚀", basePrice: 1500, category: "ammo", stockLimit: 50, warMultiplier: 2.5 },
        savunma_ekipman: { id: "savunma_ekipman", name: "Savunma Ekipmanı", emoji: "🔰", basePrice: 5000, category: "defense", stockLimit: 30, warMultiplier: 1.4 },
        nadir_savas: { id: "nadir_savas", name: "Nadir Savaş Eşyası", emoji: "💎", basePrice: 25000, category: "rare", stockLimit: 5, warMultiplier: 1.2 }
    },

    ROLLER: {
        admin: { id: "admin", permissions: ["admin.*", "*"], maxCount: 5, color: "§4", icon: "🔱" },
        kral: { id: "kral", permissions: ["*"], maxCount: 1, color: "§6", icon: "👑" },
        yardimci: { id: "yardimci", permissions: ["claim.*", "military.*", "economy.*", "diplomacy.*", "member.*", "market.*", "duvar.*"], maxCount: 5, color: "§e", icon: "⭐" },
        komutan: { id: "komutan", permissions: ["military.*", "siege.*", "combat.*", "member.invite", "duvar.*"], maxCount: 3, color: "§c", icon: "⚔️" },
        diplomat: { id: "diplomat", permissions: ["diplomacy.*", "member.invite"], maxCount: 2, color: "§b", icon: "🕊️" },
        ekonomist: { id: "ekonomist", permissions: ["economy.*", "market.*"], maxCount: 2, color: "§a", icon: "💰" },
        claimci: { id: "claimci", permissions: ["claim.*"], maxCount: 3, color: "§3", icon: "🏁" },
        uye: { id: "uye", permissions: [], maxCount: Infinity, color: "§7", icon: "👤" }
    },

    GELISIM_AGACI: {
        askeri: { id: "askeri", name: "Askeri Gelişim", emoji: "⚔️", maxLevel: 10, costs: [0, 2000, 5000, 10000, 20000, 40000, 70000, 100000, 150000, 200000], bonusPerLevel: { damage: 0.03, armor: 0.02 } },
        ekonomi: { id: "ekonomi", name: "Ekonomi Gelişimi", emoji: "💰", maxLevel: 10, costs: [0, 3000, 6000, 12000, 25000, 45000, 75000, 110000, 160000, 220000], bonusPerLevel: { gelir: 0.05, vergiAzaltma: 0.02 } },
        savunma: { id: "savunma", name: "Savunma Gelişimi", emoji: "🏰", maxLevel: 10, costs: [0, 2500, 5500, 11000, 22000, 42000, 72000, 105000, 155000, 210000], bonusPerLevel: { claimHp: 0.05, siegeDirenc: 0.03 } },
        diplomasi: { id: "diplomasi", name: "Diplomasi Gelişimi", emoji: "🕊️", maxLevel: 5, costs: [0, 5000, 15000, 30000, 50000], bonusPerLevel: { reputation: 5, treatySlots: 1 } }
    },

    ADDON_AKTIF: null,

    ANA_MENU: {
        buttons: [
            { id: "ordu", name: "Ordu", emoji: "👥", permission: null, order: 0, visible: true },
            { id: "claim", name: "Claim", emoji: "🏁", permission: null, order: 1, visible: true },
            { id: "toprak", name: "Toprak", emoji: "🗺️", permission: null, order: 2, visible: true },
            { id: "ekonomi", name: "Ekonomi", emoji: "💰", permission: null, order: 3, visible: true },
            { id: "savas", name: "Savaş", emoji: "⚔️", permission: null, order: 4, visible: true },
            { id: "diplomasi", name: "Diplomasi", emoji: "🕊️", permission: "diplomacy.*", order: 5, visible: true },
            { id: "uyeler", name: "Üyeler", emoji: "👤", permission: null, order: 6, visible: true },
            { id: "seviye", name: "Seviye", emoji: "⬆️", permission: null, order: 7, visible: true },
            { id: "market", name: "Market", emoji: "🏪", permission: "market.*", order: 8, visible: true },
            { id: "gelisim", name: "Gelişim", emoji: "🌳", permission: null, order: 9, visible: true },
            { id: "guc", name: "Güç", emoji: "💪", permission: null, order: 10, visible: true },
            { id: "rapor", name: "Rapor", emoji: "📊", permission: null, order: 11, visible: true },
            { id: "profil", name: "Profil", emoji: "📋", permission: null, order: 12, visible: true },
            { id: "liderlik", name: "Sıralama", emoji: "🏆", permission: null, order: 13, visible: true },
            { id: "haberler", name: "Haberler", emoji: "📰", permission: null, order: 14, visible: true },
            { id: "sur", name: "SUR", emoji: "🏰", permission: "duvar.*", order: 15, visible: true },
            { id: "customize", name: "Customize", emoji: "🔧", permission: null, order: 16, visible: true },
            { id: "ticaret_yolu", name: "Ticaret Yolu", emoji: "🛤️", permission: null, order: 17, visible: true },
            { id: "kahraman", name: "Kahraman", emoji: "🦸", permission: null, order: 18, visible: true }
        ]
    },

    EVENTS: {
        ekonomikKriz: { id: "ekonomikKriz", chance: 0.02, duration: 6000, gelirMultiplier: 0.5, message: "§cEkonomik kriz başladı!" },
        kitlik: { id: "kitlik", chance: 0.03, duration: 8000, marketPriceMultiplier: 1.5, message: "§eKıtlık dönemi!" },
        askeriBonus: { id: "askeriBonus", chance: 0.04, duration: 4000, damageMultiplier: 1.3, message: "§aAskeri bonus dönemi!" },
        indirim: { id: "indirim", chance: 0.05, duration: 5000, marketDiscount: 0.7, message: "§aMarket indirimleri başladı!" },
        savasAlarmi: { id: "savasAlarmi", chance: 0.01, duration: 3000, aggressionBonus: 1.5, message: "§cSavaş alarmı!" }
    },

    LEADERBOARD_KATEGORILERI: [
        { id: "power", name: "En Güçlü Krallık", emoji: "💪", field: "totalPower" },
        { id: "zengin", name: "En Zengin Krallık", emoji: "💰", field: "hazine" },
        { id: "savas", name: "En Çok Savaş Kazanan", emoji: "🏆", field: "warScore" },
        { id: "claim", name: "En Çok Claim", emoji: "🏁", field: "claimCount" },
        { id: "asker", name: "En Büyük Ordu", emoji: "👥", field: "askerCount" },
        { id: "reputation", name: "En Yüksek İtibar", emoji: "⭐", field: "reputation" },
        { id: "kd", name: "En Yüksek K/D", emoji: "🎯", field: "kdRatio" },
        { id: "gelir", name: "En İyi Ekonomi", emoji: "📈", field: "gelir" },
        { id: "market", name: "En Çok Market Satışı", emoji: "🛒", field: "marketSales" },
        { id: "online", name: "En Aktif Oyuncu", emoji: "⏱️", field: "onlineSure" },
        { id: "ittifak", name: "En Büyük İttifak", emoji: "🤝", field: "ittifakCount" },
        { id: "seviye", name: "En Yüksek Seviye", emoji: "⬆️", field: "seviye" },
        { id: "kusatma", name: "En Çok Kuşatma", emoji: "🏰", field: "kusatmaCount" }
    ],

    MARKET_PRICE_PROPERTY: "market_prices",
    SOLDIER_LEVEL_COST_MULTIPLIER: 2.5,
    SOLDIER_LEVEL_STATS_INCREMENT: 0.08,
    CHEST_SCAN_INTERVAL: 6000,
    CLAIM_BLOCK_SCAN_INTERVAL: 12000,
    CLAIM_PARTICLE_INTERVAL: 40,

    CLAIM_FLAG_COST: 250,
    CLAIM_FLAG_TIMEOUT: 600000,

    CLAIM_UPGRADE_COSTS: [0, 10000, 25000, 50000, 90000],
    CLAIM_MAINTENANCE_PER_LEVEL: [10, 20, 30, 40, 50]
};

export const Config = KrallikConfig;