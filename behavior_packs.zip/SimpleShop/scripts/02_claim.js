// ============================================================
// MODÜL 02: CLAIM V3 - SINIR TAŞI SİSTEMİ (KUSURSUZ)
// ============================================================
import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";

// ============================================================
// KENAR TABELA YÖNETİCİSİ (3D, DÜNYADA SABİT)
// Oyuncu bir claim kenarına yaklaşınca, o kenarın ortasında
// havada asılı duran görünmez bir entity (armor stand) + nameTag
// ile krallık bilgisi tabelası oluşturur.
// ============================================================
const ClaimEdgeSignManager = {
    // claimId -> { entity, edgeKey, lastText }
    _signs: {},

    _entityIdFor(claimId, edgeKey) {
        return `${claimId}::${edgeKey}`;
    },

    ensureSign(claim, krallik, edgeMidpoint, edgeKey, dimension) {
        const signId = this._entityIdFor(claim.id, edgeKey);
        const text = this._buildText(claim, krallik);
        const height = (claim.hudSettings?.signHeight) ?? ClaimManager.CONFIG.DEFAULT_HUD_SETTINGS.signHeight;
        const y = (claim.baseY ?? 64) + height;

        let entry = this._signs[signId];

        // Savaş sırasında, savaşan taraflara gizlenecek - bu kontrol gösterim anında yapılır (per-player değil,
        // tabela tek bir dünya entity'si olduğu için "kimden gizleneceği" ayrı bir mekanizma gerektirir).
        // Bu yüzden gizleme işini nameTag'i boşaltarak değil, oyuncuya özel olarak yapamayız;
        // bunun yerine savaş durumunda tabelayı TÜMÜYLE kaldırırız (aşağıdaki shouldHide ile).

        if (entry?.entity) {
            try {
                if (entry.entity.isValid?.() === false) throw new Error("invalid");
                if (entry.lastText !== text) {
                    entry.entity.nameTag = text;
                    entry.lastText = text;
                }
                return;
            } catch (e) {
                delete this._signs[signId];
                entry = null;
            }
        }

        try {
            const entity = dimension.spawnEntity("minecraft:armor_stand", {
                x: edgeMidpoint.x + 0.5,
                y,
                z: edgeMidpoint.z + 0.5
            });
            entity.nameTag = text;
            try { entity.setProperty?.("minecraft:marker_variant", 0); } catch (e) {}
            try { entity.addTag?.("krallik_edge_sign"); } catch (e) {}
            try { entity.addTag?.(`claim_${claim.id}`); } catch (e) {}
            try { entity.triggerEvent?.("minecraft:become_invisible"); } catch (e) {}
            try { entity.isInvisible = true; } catch (e) {}
            this._signs[signId] = { entity, edgeKey, lastText: text };
        } catch (e) {}
    },

    removeSign(claimId, edgeKey) {
        const signId = this._entityIdFor(claimId, edgeKey);
        const entry = this._signs[signId];
        if (!entry) return;
        try { if (entry.entity?.isValid?.()) entry.entity.kill(); } catch (e) {}
        delete this._signs[signId];
    },

    removeAllForClaim(claimId) {
        for (const signId of Object.keys(this._signs)) {
            if (signId.startsWith(`${claimId}::`)) {
                this.removeSign(claimId, signId.split("::")[1]);
            }
        }
    },

    _buildText(claim, krallik) {
        const s = claim.hudSettings || ClaimManager.CONFIG.DEFAULT_HUD_SETTINGS;
        const lines = [];
        if (s.showName) lines.push(`§l§6${krallik.isim}`);
        const parts = [];
        if (s.showLevel)  parts.push(`§7Seviye: §e${krallik.seviye || 1}`);
        if (s.showPower)  parts.push(`§7Güç: §d${(krallik.totalPower || 0).toLocaleString()}`);
        if (s.showLeader) parts.push(`§7Lider: §6${krallik.lider || "?"}`);
        if (parts.length) lines.push(parts.join("  §8|  "));
        return lines.join("\n");
    }
};

// ============================================================
// CLAIM MANAGER
// ============================================================
export const ClaimManager = {
    CONFIG: {
        CREATE_COST_PER_BLOCK: 39, // 3 kat pahalandırıldı (eski: 13)
        SELL_REFUND_RATE: 0.6,
        HUD_CHECK_RANGE: 40,
        EDGE_PROXIMITY_RANGE: 20,
        MAX_VERTICES: 20,
        MIN_VERTICES: 3,
        DEFAULT_HUD_SETTINGS: {
            showName: true,
            showLevel: true,
            showPower: true,
            showLeader: true,
            signHeight: 25
        }
    },

    // ============================================================
    // VERİ YÖNETİMİ
    // ============================================================

    _getData() {
        const d = Core.Database.load();
        if (!d.claimler) d.claimler = {};
        if (!d.claimDrawSessions) d.claimDrawSessions = {};

        if (d.claimsV2 && Object.keys(d.claimsV2).length) {
            for (const [id, c] of Object.entries(d.claimsV2)) {
                if (!d.claimler[id]) d.claimler[id] = c;
            }
            d.claimsV2 = {};
            Core.Database.markDirty("krallik_claims");
        }

        return d.claimler;
    },

    _save() {
        Core.Database.markDirty("krallik_claims");
    },

    getKingdomClaim(kid) {
        if (!kid) return null;
        const claims = this._getData();
        for (const [id, claim] of Object.entries(claims)) {
            if (claim.krallik === kid) return { id, ...claim };
        }
        return null;
    },

    getClaim(claimId) {
        if (!claimId) return null;
        const claims = this._getData();
        return claims[claimId] ? { id: claimId, ...claims[claimId] } : null;
    },

    // ============================================================
    // ALAN & FİYAT
    // ============================================================

    _calculateArea(vertices) {
        if (!vertices || vertices.length < 3) return 0;
        let sum = 0;
        for (let i = 0; i < vertices.length; i++) {
            const j = (i + 1) % vertices.length;
            sum += vertices[i].x * vertices[j].z;
            sum -= vertices[j].x * vertices[i].z;
        }
        return Math.abs(sum) / 2;
    },

    getClaimArea(claim) {
        if (!claim?.vertices || claim.vertices.length < 3) return 0;
        return this._calculateArea(claim.vertices);
    },

    calculatePrice(area) {
        return Math.floor(area * this.CONFIG.CREATE_COST_PER_BLOCK);
    },

    getClaimPrice(kid) {
        const claim = this.getKingdomClaim(kid);
        const area  = claim ? this.getClaimArea(claim) : 0;
        return this.calculatePrice(area);
    },

    // ============================================================
    // BAYRAK YÖNETİMİ
    // ============================================================

    _getFlagEntityId(ulkeTipi) {
        const flagMap = {
            british: "knights:napoleonic_flag_of_england",
            french:  "knights:napoleonic_flag_of_france",
            german:  "knights:napoleonic_flag_of_germany",
            russian: "knights:napoleonic_flag_of_russia",
            italian: "knights:napoleonic_flag_of_italy",
            spanish: "knights:napoleonic_flag_of_spain"
        };
        return flagMap[ulkeTipi] || "knights:napoleonic_flag_of_england";
    },

    async _spawnFlags(claim, dimension) {
        if (!claim.vertices?.length) return;

        const d       = Core.Database.load();
        const krallik = d.kralliklar[claim.krallik];
        const flagId  = this._getFlagEntityId(krallik?.ulkeTipi || "british");

        await this._clearFlags(claim);

        const newFlagIds = [];
        const baseY      = claim.baseY ?? 64;

        for (const vertex of claim.vertices) {
            try {
                const entity = dimension.spawnEntity(flagId, {
                    x: Math.floor(vertex.x) + 0.5,
                    y: baseY,
                    z: Math.floor(vertex.z) + 0.5
                });
                entity.addTag("krallik_claim_flag");
                entity.addTag(`claim_${claim.id}`);
                newFlagIds.push(entity.id);
            } catch(e) {}
        }

        const claims = this._getData();
        if (claims[claim.id]) {
            claims[claim.id].flagIds = newFlagIds;
        }
        this._save();
    },

    async _clearFlags(claim) {
        if (!claim.flagIds?.length) return;
        for (const fId of claim.flagIds) {
            try {
                const entity = Core.Cache?.getEntityById?.(fId);
                if (entity?.isValid?.()) entity.kill();
            } catch(e) {}
        }
        const claims = this._getData();
        if (claims[claim.id]) claims[claim.id].flagIds = [];
        this._save();
    },

    // ============================================================
    // SESSION YÖNETİMİ
    // ============================================================

    startCreateSession(player) {
        const kid = Core.Database.getOyuncuKrallikId(player.name);
        if (!kid) {
            Core.Systems?.sendMessage?.(player, "§cÖnce bir krallığa katılmalısın!");
            return false;
        }
        if (this.getKingdomClaim(kid)) {
            Core.Systems?.sendMessage?.(player, "§cKrallığının zaten bir toprağı var! Düzenlemek için Claim menüsünden 'Köşe Düzenle' seç.");
            return false;
        }

        const d = Core.Database.load();
        const existing = d.claimDrawSessions[player.name];

        // ÖNEMLİ: Daha önce başlatılmış, tamamlanmamış bir oluşturma oturumu varsa
        // (oyuncu köşe ekleyip menüyü kapattıysa) onu SİLİP SIFIRLAMAK YERİNE devam
        // ettiriyoruz. Eski davranışta burası her zaman vertices:[] ile üzerine
        // yazıyordu; bu da "menüyü kapatınca eklenen köşeler kayboluyor" sorununun
        // gerçek nedeniydi (TOPRAK menüsündeki "CLAIM KUR" butonu her tıklamada bu
        // fonksiyonu çağırıyordu).
        if (existing && !existing.isEdit && existing.kid === kid) {
            Core.Systems?.sendMessage?.(player, `§aKaydedilmiş bir claim oturumu bulundu (§e${existing.vertices.length}§a köşe). Devam ediliyor...`);
            this._showCreateMenu(player);
            return true;
        }

        d.claimDrawSessions[player.name] = {
            kid,
            vertices:  [],
            startedAt: Date.now(),
            isEdit:    false
        };
        Core.Database.markDirty("krallik_claims");

        Core.Systems?.sendMessage?.(player, "§aClaim oluşturma başladı! En az 3 köşe ekle.");
        this._showCreateMenu(player);
        return true;
    },

    _getSession(playerName) {
        return Core.Database.load().claimDrawSessions?.[playerName] || null;
    },

    _showCreateMenu(player) {
        const session = this._getSession(player.name);
        if (!session || session.isEdit) { this.startCreateSession(player); return; }

        const area  = this._calculateArea(session.vertices);
        const price = this.calculatePrice(area);
        const d     = Core.Database.load();
        const kh    = d.kralliklar?.[session.kid]?.hazine ?? 0;

        let body = `§l🏁 CLAIM OLUŞTURMA\n§8────────────────\n`;
        body += `§fKöşe: §e${session.vertices.length} / ${this.CONFIG.MAX_VERTICES}\n`;
        body += `§fAlan: §e${Math.floor(area)} m²\n`;
        body += `§fTahmini Ücret: §a${price.toLocaleString()} ZMC\n`;
        body += `§fHazine: §a${kh.toLocaleString()} ZMC\n`;
        body += `§8────────────────\n`;

        if (session.vertices.length > 0) {
            body += `§7Köşeler:\n`;
            session.vertices.forEach((v, i) => {
                body += `  §f${i + 1}. §7(${Math.floor(v.x)}, ${Math.floor(v.z)})\n`;
            });
        } else {
            body += `§7Henüz köşe eklenmemiş\n`;
        }

        const form = new ActionFormData()
            .title("§l🏁 CLAIM KUR")
            .body(body)
            .button("§l📍 KÖŞE EKLE",        "textures/ui/plus")
            .button("§l✏️ KÖŞE DÜZENLE",     "textures/ui/edit")
            .button("§l🗑️ KÖŞE SİL",        "textures/ui/trash")
            .button("§l💾 KÖŞELERİ KAYDET", "textures/ui/save")
            .button("§l✅ CLAİM'İ TAMAMLA",  "textures/ui/check")
            .button("§l❌ İPTAL",             "textures/ui/cancel");

        form.show(player).then(r => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: this._addVertex(player, false);         break;
                case 1: this._editVertexSelect(player, false);  break;
                case 2: this._deleteVertexSelect(player, false); break;
                case 3: this._saveDraft(player, false);          break;
                case 4: this._finalizeClaim(player);            break;
                case 5: this._cancelSession(player);            break;
            }
        });
    },

    // Köşe ekleme/düzenleme oturumunu CLAIM'İ TAMAMLAMADAN, anında diske
    // kaydeder. Oyuncu menüyü kapatsa, çıksa veya sunucu yeniden başlasa
    // bile o ana kadar eklenen köşeler kaybolmaz.
    _saveDraft(player, isEdit) {
        const session = this._getSession(player.name);
        if (!session) {
            Core.Systems?.sendMessage?.(player, "§cKaydedilecek bir oturum bulunamadı!");
            return;
        }
        Core.Database.markDirty("krallik_claims");
        Core.Database.save(true); // anında diske yaz — taslağı periyodik auto-save'e bağlı bırakma
        Core.Systems?.sendMessage?.(player, `§a💾 Köşeler kaydedildi (§e${session.vertices.length}§a adet). Menüyü kapatıp daha sonra devam edebilirsin.`);
        isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
    },

    // ============================================================
    // KÖŞE EKLE
    // ============================================================

    _addVertex(player, isEdit) {
        const session = this._getSession(player.name);
        if (!session) { isEdit ? this.startEditSession(player) : this.startCreateSession(player); return; }

        if (session.vertices.length >= this.CONFIG.MAX_VERTICES) {
            Core.Systems?.sendMessage?.(player, `§cEn fazla ${this.CONFIG.MAX_VERTICES} köşe eklenebilir!`);
            isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
            return;
        }

        const curX = Math.floor(player.location.x);
        const curZ = Math.floor(player.location.z);

        new ModalFormData()
            .title("§l📍 KÖŞE EKLE")
            .textField("X koordinatı:", curX.toString(), curX.toString())
            .textField("Z koordinatı:", curZ.toString(), curZ.toString())
            .toggle("§eMevcut konumumu kullan", false)
            .show(player).then(r => {
                if (r.canceled) { isEdit ? this._showEditMenu(player) : this._showCreateMenu(player); return; }

                let x, z;
                if (r.formValues[2]) {
                    x = Math.floor(player.location.x);
                    z = Math.floor(player.location.z);
                } else {
                    x = parseInt(r.formValues[0]);
                    z = parseInt(r.formValues[1]);
                    if (isNaN(x) || isNaN(z)) {
                        Core.Systems?.sendMessage?.(player, "§cGeçersiz koordinat!");
                        this._addVertex(player, isEdit);
                        return;
                    }
                }

                // Session'ı taze oku
                const fresh = this._getSession(player.name);
                if (!fresh) { isEdit ? this._showMainMenu(player) : this._showMainMenu(player); return; }
                fresh.vertices.push({ x, z });
                Core.Database.markDirty("krallik_claims");
                Core.Systems?.sendMessage?.(player, `§aKöşe eklendi: (${x}, ${z}) — Toplam: ${fresh.vertices.length}`);
                isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
            });
    },

    // ============================================================
    // KÖŞE DÜZENLE
    // ============================================================

    _editVertexSelect(player, isEdit) {
        const session = this._getSession(player.name);
        if (!session || session.vertices.length === 0) {
            Core.Systems?.sendMessage?.(player, "§cDüzenlenecek köşe yok!");
            isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
            return;
        }

        const form = new ActionFormData()
            .title("§l✏️ KÖŞE SEÇ")
            .body("§fDüzenlenecek köşeyi seçin:");

        session.vertices.forEach((v, i) => form.button(`${i + 1}. (${Math.floor(v.x)}, ${Math.floor(v.z)})`));
        form.button("§l❌ GERİ");

        form.show(player).then(r => {
            if (r.canceled || r.selection === session.vertices.length) {
                isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
                return;
            }
            this._editVertexForm(player, r.selection, isEdit);
        });
    },

    _editVertexForm(player, index, isEdit) {
        const session = this._getSession(player.name);
        if (!session) return;

        const vertex = session.vertices[index];

        new ModalFormData()
            .title(`§l✏️ ${index + 1}. KÖŞEYİ DÜZENLE`)
            .textField("Yeni X:", vertex.x.toString(), vertex.x.toString())
            .textField("Yeni Z:", vertex.z.toString(), vertex.z.toString())
            .toggle("§eMevcut konumumu kullan", false)
            .show(player).then(r => {
                if (r.canceled) { this._editVertexSelect(player, isEdit); return; }

                let newX, newZ;
                if (r.formValues[2]) {
                    newX = Math.floor(player.location.x);
                    newZ = Math.floor(player.location.z);
                } else {
                    newX = parseInt(r.formValues[0]);
                    newZ = parseInt(r.formValues[1]);
                    if (isNaN(newX) || isNaN(newZ)) {
                        Core.Systems?.sendMessage?.(player, "§cGeçersiz koordinat!");
                        this._editVertexForm(player, index, isEdit);
                        return;
                    }
                }

                const fresh = this._getSession(player.name);
                if (!fresh) return;
                fresh.vertices[index] = { x: newX, z: newZ };
                Core.Database.markDirty("krallik_claims");
                Core.Systems?.sendMessage?.(player, `§aKöşe güncellendi: (${newX}, ${newZ})`);
                isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
            });
    },

    // ============================================================
    // KÖŞE SİL
    // ============================================================

    _deleteVertexSelect(player, isEdit) {
        const session = this._getSession(player.name);
        if (!session || session.vertices.length <= this.CONFIG.MIN_VERTICES) {
            Core.Systems?.sendMessage?.(player, `§cEn az ${this.CONFIG.MIN_VERTICES} köşe kalmalı!`);
            isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
            return;
        }

        const form = new ActionFormData()
            .title("§l🗑️ KÖŞE SİL")
            .body("§fSilinecek köşeyi seçin:");

        session.vertices.forEach((v, i) => form.button(`${i + 1}. (${Math.floor(v.x)}, ${Math.floor(v.z)})`));
        form.button("§l❌ GERİ");

        form.show(player).then(r => {
            if (r.canceled || r.selection === session.vertices.length) {
                isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
                return;
            }

            const fresh = this._getSession(player.name);
            if (!fresh) return;
            const removed = fresh.vertices.splice(r.selection, 1)[0];
            Core.Database.markDirty("krallik_claims");
            Core.Systems?.sendMessage?.(player, `§eKöşe silindi: (${Math.floor(removed.x)}, ${Math.floor(removed.z)})`);
            isEdit ? this._showEditMenu(player) : this._showCreateMenu(player);
        });
    },

    // ============================================================
    // CLAİM FİNALİZE
    // ============================================================

    _finalizeClaim(player) {
        const session = this._getSession(player.name);
        if (!session) return;

        if (session.vertices.length < this.CONFIG.MIN_VERTICES) {
            Core.Systems?.sendMessage?.(player, `§cEn az ${this.CONFIG.MIN_VERTICES} köşe gerekli!`);
            this._showCreateMenu(player);
            return;
        }

        const area    = this._calculateArea(session.vertices);
        const price   = this.calculatePrice(area);
        const d       = Core.Database.load();
        const krallik = d.kralliklar?.[session.kid];

        if (!krallik) {
            Core.Systems?.sendMessage?.(player, "§cKrallık bulunamadı!");
            this._cancelSession(player);
            return;
        }

        new MessageFormData()
            .title("§l✅ CLAİM'İ TAMAMLA")
            .body(`§fAlan: §e${Math.floor(area)} m²\n§fÜcret: §c${price.toLocaleString()} ZMC\n§fHazine: §a${(krallik.hazine || 0).toLocaleString()} ZMC\n§8────────────────\n§aBu claim'i oluşturmak istiyor musun?`)
            .button1("§a✔ ONAYLA")
            .button2("§c✖ İPTAL")
            .show(player).then(r => {
                if (r.selection !== 0) { this._showCreateMenu(player); return; }

                if ((krallik.hazine || 0) < price) {
                    Core.Systems?.sendMessage?.(player, `§cYetersiz hazine! Gereken: §c${price.toLocaleString()} ZMC, Mevcut: §a${(krallik.hazine || 0).toLocaleString()} ZMC`);
                    this._showCreateMenu(player);
                    return;
                }

                krallik.hazine -= price;

                const claimId  = `claim_${Date.now()}_${session.kid}`;
                const newClaim = {
                    id:          claimId,
                    krallik:     session.kid,
                    vertices:    session.vertices,
                    baseY:       Math.floor(player.location.y),
                    dimension:   player.dimension.id,
                    createdAt:   Date.now(),
                    flagIds:     [],
                    hudSettings: { ...this.CONFIG.DEFAULT_HUD_SETTINGS }
                };

                const claims = this._getData();
                claims[claimId] = newClaim;
                this._recomputeClaimMeta(newClaim);
                this._spawnFlags(newClaim, player.dimension);

                delete d.claimDrawSessions[player.name];

                Core.Database.markDirty("krallik_core");
                Core.Database.markDirty("krallik_claims");
                Core.Database.save(true); // anında diske yaz — köşe/claim verisi periyodik auto-save'e (5 dk'ya kadar) bağlı kalmasın
                Core.Systems?.sendMessage?.(player, `§a✅ Claim başarıyla kuruldu! Alan: §e${Math.floor(area)} m²`);
                this._showMainMenu(player);
            });
    },

    _cancelSession(player) {
        const d = Core.Database.load();
        delete d.claimDrawSessions[player.name];
        Core.Database.markDirty("krallik_claims");
        Core.Systems?.sendMessage?.(player, "§7Claim işlemi iptal edildi.");
        this._showMainMenu(player);
    },

    // ============================================================
    // ANA MENÜ
    // ============================================================

    _showMainMenu(player) {
        const kid     = Core.Database.getOyuncuKrallikId(player.name);
        const krallik = Core.Database.getKrallik(kid);

        if (!krallik) {
            Core.Systems?.sendMessage?.(player, "§cÖnce bir krallığa katılmalısın!");
            return;
        }

        const claim    = this.getKingdomClaim(kid);
        const hasClaim = !!claim;
        const area     = claim ? this.getClaimArea(claim) : 0;
        const kh       = krallik.hazine || 0;

        let body = `§l🏁 TOPRAK YÖNETİMİ\n§8────────────────\n`;
        body += `§fKrallık: §6${krallik.isim}\n`;
        body += `§fHazine: §a${kh.toLocaleString()} ZMC\n`;

        if (hasClaim) {
            body += `§fToprak Alanı: §e${Math.floor(area)} m²\n`;
            body += `§fKöşe Sayısı: §e${claim.vertices?.length || 0}\n`;
            body += `§fToprak Değeri: §a${this.calculatePrice(area).toLocaleString()} ZMC\n`;
            body += `§fBayrak: §7${claim.flagIds?.length || 0} adet\n`;
        } else {
            body += `§7Henüz toprağınız yok\n`;
        }

        const form = new ActionFormData()
            .title("§l🏁 TOPRAK")
            .body(body);

        if (!hasClaim) {
            form.button("§l🟢 CLAIM KUR", "textures/ui/plus");
        } else {
            form.button("§l✏️ KÖŞE DÜZENLE",       "textures/ui/edit");
            form.button("§l📊 HUD AYARLARI",        "textures/ui/settings");
            form.button("§l🗺️ TOPRAK BİLGİSİ",    "textures/ui/map");
            form.button("§l🏁 BAYRAKLARI YENİLE",  "textures/ui/refresh");
        }
        form.button("§l❌ KAPAT", "textures/ui/cancel");

        form.show(player).then(r => {
            if (r.canceled) return;

            if (!hasClaim) {
                if (r.selection === 0) this.startCreateSession(player);
                return;
            }

            switch (r.selection) {
                case 0: this.startEditSession(player);  break;
                case 1: this.showHUDSettings(player);   break;
                case 2: this._showBorderInfo(player);   break;
                case 3: this._refreshFlags(player);     break;
            }
        });
    },

    // ============================================================
    // KÖŞE DÜZENLEME (MEVCUT CLAIM)
    // ============================================================

    startEditSession(player) {
        const kid   = Core.Database.getOyuncuKrallikId(player.name);
        const claim = this.getKingdomClaim(kid);

        if (!claim) {
            Core.Systems?.sendMessage?.(player, "§cToprağınız yok!");
            this._showMainMenu(player);
            return;
        }

        const d = Core.Database.load();
        const existing = d.claimDrawSessions[player.name];

        // Aynı sorun düzenleme akışında da vardı: "KÖŞE DÜZENLE" her tıklandığında
        // mevcut taslak siliniyor ve orijinal claim'den sıfırdan kopyalanıyordu.
        // Kaydedilmemiş bir düzenleme oturumu varsa onu silmeden devam ettiriyoruz.
        if (existing && existing.isEdit && existing.claimId === claim.id) {
            Core.Systems?.sendMessage?.(player, `§aKaydedilmemiş bir düzenleme bulundu (§e${existing.vertices.length}§a köşe). Devam ediliyor...`);
            this._showEditMenu(player);
            return;
        }

        d.claimDrawSessions[player.name] = {
            kid,
            vertices:  JSON.parse(JSON.stringify(claim.vertices)),
            claimId:   claim.id,
            isEdit:    true,
            startedAt: Date.now()
        };
        Core.Database.markDirty("krallik_claims");
        this._showEditMenu(player);
    },

    _showEditMenu(player) {
        const session = this._getSession(player.name);
        if (!session?.isEdit) { this.startEditSession(player); return; }

        const origClaim = this.getClaim(session.claimId);
        const origArea  = origClaim ? this.getClaimArea(origClaim) : 0;
        const newArea   = this._calculateArea(session.vertices);
        const areaDiff  = newArea - origArea;
        const priceDiff = this.calculatePrice(Math.abs(areaDiff));

        const d  = Core.Database.load();
        const kh = d.kralliklar?.[session.kid]?.hazine ?? 0;

        let body = `§l✏️ KÖŞE DÜZENLEME\n§8────────────────\n`;
        body += `§fKöşe: §e${session.vertices.length} / ${this.CONFIG.MAX_VERTICES}\n`;
        body += `§fYeni Alan: §e${Math.floor(newArea)} m²\n`;
        body += `§fHazine: §a${kh.toLocaleString()} ZMC\n`;

        if (Math.abs(areaDiff) > 0.5) {
            if (areaDiff > 0) {
                body += `§cEk Maliyet: §c${priceDiff.toLocaleString()} ZMC (Alan arttı +${Math.floor(areaDiff)} m²)\n`;
            } else {
                const refund = Math.floor(priceDiff * this.CONFIG.SELL_REFUND_RATE);
                body += `§aİade: §a${refund.toLocaleString()} ZMC (Alan azaldı -${Math.floor(-areaDiff)} m²)\n`;
            }
        }
        body += `§8────────────────\n`;
        body += `§7Köşeler:\n`;
        session.vertices.forEach((v, i) => {
            body += `  §f${i + 1}. §7(${Math.floor(v.x)}, ${Math.floor(v.z)})\n`;
        });

        const form = new ActionFormData()
            .title("§l✏️ KÖŞE DÜZENLE")
            .body(body)
            .button("§l📍 KÖŞE EKLE",              "textures/ui/plus")
            .button("§l✏️ KÖŞE DEĞİŞTİR",         "textures/ui/edit")
            .button("§l🗑️ KÖŞE SİL",              "textures/ui/trash")
            .button("§l💾 TASLAK KAYDET",          "textures/ui/save")
            .button("§l✅ DEĞİŞİKLİKLERİ KAYDET", "textures/ui/confirm")
            .button("§l❌ İPTAL (Kaydetmeden Çık)", "textures/ui/cancel");

        form.show(player).then(r => {
            if (r.canceled) return; // menü X ile kapatılırsa oturum silinmez, devam edilebilir
            switch (r.selection) {
                case 0: this._addVertex(player, true);          break;
                case 1: this._editVertexSelect(player, true);   break;
                case 2: this._deleteVertexSelect(player, true); break;
                case 3: this._saveDraft(player, true);          break;
                case 4: this._saveEditChanges(player);          break;
                case 5: this._cancelSession(player);            break;
            }
        });
    },

    _saveEditChanges(player) {
        const session = this._getSession(player.name);
        if (!session?.isEdit) return;

        if (session.vertices.length < this.CONFIG.MIN_VERTICES) {
            Core.Systems?.sendMessage?.(player, `§cEn az ${this.CONFIG.MIN_VERTICES} köşe olmalı!`);
            this._showEditMenu(player);
            return;
        }

        const origClaim = this.getClaim(session.claimId);
        if (!origClaim) {
            Core.Systems?.sendMessage?.(player, "§cOrijinal claim bulunamadı!");
            this._cancelSession(player);
            return;
        }

        const oldArea  = this._calculateArea(origClaim.vertices);
        const newArea  = this._calculateArea(session.vertices);
        const areaDiff = newArea - oldArea;

        const d       = Core.Database.load();
        const krallik = d.kralliklar?.[session.kid];

        if (!krallik) {
            Core.Systems?.sendMessage?.(player, "§cKrallık bulunamadı!");
            this._cancelSession(player);
            return;
        }

        if (areaDiff > 0.5) {
            const extraCost = this.calculatePrice(areaDiff);
            if ((krallik.hazine || 0) < extraCost) {
                Core.Systems?.sendMessage?.(player, `§cYetersiz hazine! Genişleme için §c${extraCost.toLocaleString()} ZMC§c gerekli. Mevcut: §a${(krallik.hazine || 0).toLocaleString()} ZMC`);
                this._showEditMenu(player);
                return;
            }
            krallik.hazine -= extraCost;
            Core.Systems?.sendMessage?.(player, `§eAlan genişledi: +${Math.floor(areaDiff)} m², ödenen: §c${extraCost.toLocaleString()} ZMC`);
        } else if (areaDiff < -0.5) {
            const refund = Math.floor(this.calculatePrice(-areaDiff) * this.CONFIG.SELL_REFUND_RATE);
            krallik.hazine = (krallik.hazine || 0) + refund;
            Core.Systems?.sendMessage?.(player, `§eAlan daraldı: -${Math.floor(-areaDiff)} m², iade: §a${refund.toLocaleString()} ZMC`);
        }

        const claims   = this._getData();
        const claimObj = claims[session.claimId];
        if (claimObj) {
            ClaimEdgeSignManager.removeAllForClaim(session.claimId);
            claimObj.vertices = session.vertices;
            this._recomputeClaimMeta(claimObj);
            this._spawnFlags({ ...claimObj, id: session.claimId }, player.dimension);
        }

        delete d.claimDrawSessions[player.name];

        Core.Database.markDirty("krallik_core");
        Core.Database.markDirty("krallik_claims");
        Core.Database.save(true); // anında diske yaz — "köşe kaydet" tıklandığında değişiklik gerçekten kalıcı olsun

        Core.Systems?.sendMessage?.(player, "§a✅ Değişiklikler kaydedildi!");
        this._showMainMenu(player);
    },

    // ============================================================
    // BAYRAKLARI YENİLE
    // ============================================================

    _refreshFlags(player) {
        const kid   = Core.Database.getOyuncuKrallikId(player.name);
        const claim = this.getKingdomClaim(kid);
        if (!claim) { Core.Systems?.sendMessage?.(player, "§cToprağınız yok!"); return; }

        Core.Systems?.sendMessage?.(player, "§eBayraklar yenileniyor...");
        this._spawnFlags(claim, player.dimension).then(() => {
            Core.Systems?.sendMessage?.(player, `§a✅ ${claim.vertices?.length || 0} bayrak yenilendi!`);
        });
        this._showMainMenu(player);
    },

    // ============================================================
    // TOPRAK BİLGİSİ
    // ============================================================

    _showBorderInfo(player) {
        const kid    = Core.Database.getOyuncuKrallikId(player.name);
        const claim  = this.getKingdomClaim(kid);

        if (!claim) {
            Core.Systems?.sendMessage?.(player, "§cToprağınız yok!");
            this._showMainMenu(player);
            return;
        }

        const area    = this.getClaimArea(claim);
        const price   = this.calculatePrice(area);
        const krallik = Core.Database.getKrallik(kid);

        let body = `§l🗺️ TOPRAK BİLGİLERİ\n§8────────────────\n`;
        body += `§fKrallık: §6${krallik?.isim || "?"}\n`;
        body += `§fSeviye: §e${krallik?.seviye || 1}\n`;
        body += `§fGüç: §d${(krallik?.totalPower || 0).toLocaleString()}\n`;
        body += `§fLider: §6${krallik?.lider || "?"}\n`;
        body += `§8────────────────\n`;
        body += `§fAlan: §e${Math.floor(area)} m²\n`;
        body += `§fKöşe: §e${claim.vertices?.length || 0}\n`;
        body += `§fDeğer: §a${price.toLocaleString()} ZMC\n`;
        body += `§fDimension: §7${claim.dimension || "overworld"}\n`;
        body += `§8────────────────\n`;
        body += `§7HUD: Toprak sınırına girilince otomatik görünür\n`;
        body += `§7Bayraklar: §f${claim.flagIds?.length || 0} adet köşede\n`;

        new ActionFormData()
            .title("§l🗺️ TOPRAK BİLGİSİ")
            .body(body)
            .button("§l❌ KAPAT")
            .show(player).then(() => {});
    },

    // ============================================================
    // HUD AYARLARI
    // ============================================================

    showHUDSettings(player) {
        const kid    = Core.Database.getOyuncuKrallikId(player.name);
        const claims = this._getData();
        let claimObj = null;
        let claimId  = null;

        for (const [id, c] of Object.entries(claims)) {
            if (c.krallik === kid) { claimObj = c; claimId = id; break; }
        }

        if (!claimObj) {
            Core.Systems?.sendMessage?.(player, "§cToprağınız yok!");
            this._showMainMenu(player);
            return;
        }

        if (!claimObj.hudSettings) claimObj.hudSettings = { ...this.CONFIG.DEFAULT_HUD_SETTINGS };
        const s = claimObj.hudSettings;
        if (s.signHeight === undefined) s.signHeight = this.CONFIG.DEFAULT_HUD_SETTINGS.signHeight;

        let body = `§l📊 HUD AYARLARI\n§8────────────────\n`;
        body += `§7Toprak sınırına ${this.CONFIG.EDGE_PROXIMITY_RANGE} blok yaklaşan herkes, en yakın kenarın §e${s.signHeight} blok§7 üstünde havada asılı bir tabela görür:\n\n`;
        body += `${s.showName   ? "§a✔" : "§c✖"} Krallık İsmi\n`;
        body += `${s.showLevel  ? "§a✔" : "§c✖"} Seviye\n`;
        body += `${s.showPower  ? "§a✔" : "§c✖"} Güç\n`;
        body += `${s.showLeader ? "§a✔" : "§c✖"} Lider\n`;
        body += `§7Tabela Yüksekliği: §e${s.signHeight} blok\n`;
        body += `§8────────────────\n§7Not: Savaş/kuşatma sırasında bu tabela, savaşan taraflara gizlenir.`;

        const form = new ActionFormData()
            .title("§l📊 HUD AYARLARI")
            .body(body)
            .button(`${s.showName   ? "§c🔘 GİZLE" : "§a🔘 GÖSTER"} Krallık İsmi`)
            .button(`${s.showLevel  ? "§c🔘 GİZLE" : "§a🔘 GÖSTER"} Seviye`)
            .button(`${s.showPower  ? "§c🔘 GİZLE" : "§a🔘 GÖSTER"} Güç`)
            .button(`${s.showLeader ? "§c🔘 GİZLE" : "§a🔘 GÖSTER"} Lider`)
            .button(`§e📏 TABELA YÜKSEKLİĞİ (${s.signHeight})`, "textures/ui/up_arrow")
            .button("§l💾 KAYDET", "textures/ui/save")
            .button("§l❌ GERİ",   "textures/ui/cancel");

        form.show(player).then(r => {
            if (r.canceled || r.selection === 6) { this._showMainMenu(player); return; }

            if (r.selection === 4) {
                this._editSignHeight(player, claimObj);
                return;
            }

            if (r.selection === 5) {
                claimObj.hudSettings = s;
                this._save();
                Core.Database.save(true);
                ClaimEdgeSignManager.removeAllForClaim(claimId);
                Core.Systems?.sendMessage?.(player, "§a✅ HUD ayarları kaydedildi!");
                this._showMainMenu(player);
                return;
            }

            if (r.selection === 0) s.showName   = !s.showName;
            if (r.selection === 1) s.showLevel  = !s.showLevel;
            if (r.selection === 2) s.showPower  = !s.showPower;
            if (r.selection === 3) s.showLeader = !s.showLeader;

            this.showHUDSettings(player);
        });
    },

    _editSignHeight(player, claimObj) {
        const s = claimObj.hudSettings || { ...this.CONFIG.DEFAULT_HUD_SETTINGS };
        new ModalFormData()
            .title("§l📏 TABELA YÜKSEKLİĞİ")
            .textField("Yükseklik (blok, 5-100):", String(s.signHeight ?? 25), String(s.signHeight ?? 25))
            .show(player).then(r => {
                if (r.canceled) { this.showHUDSettings(player); return; }
                const val = parseInt(r.formValues[0]);
                if (isNaN(val)) {
                    Core.Systems?.sendMessage?.(player, "§cGeçersiz değer!");
                    this._editSignHeight(player, claimObj);
                    return;
                }
                s.signHeight = Math.max(5, Math.min(100, val));
                claimObj.hudSettings = s;
                this.showHUDSettings(player);
            });
    },

    // ============================================================
    // KENAR GEOMETRİSİ YARDIMCILARI
    // ============================================================

    _closestPointOnSegment(px, pz, ax, az, bx, bz) {
        const dx = bx - ax, dz = bz - az;
        const lenSq = dx * dx + dz * dz;
        if (lenSq < 1e-9) return { x: ax, z: az, dist: Math.hypot(px - ax, pz - az) };
        let t = ((px - ax) * dx + (pz - az) * dz) / lenSq;
        t = Math.max(0, Math.min(1, t));
        const cx = ax + t * dx, cz = az + t * dz;
        return { x: cx, z: cz, dist: Math.hypot(px - cx, pz - cz) };
    },

    _getEdges(claim) {
        const v = claim.vertices;
        const edges = [];
        for (let i = 0; i < v.length; i++) {
            const a = v[i], b = v[(i + 1) % v.length];
            edges.push({ key: `${i}`, ax: a.x, az: a.z, bx: b.x, bz: b.z, midX: (a.x + b.x) / 2, midZ: (a.z + b.z) / 2 });
        }
        return edges;
    },

    // ============================================================
    // KENAR TABELASI TETİKLEYİCİ
    // ============================================================

    _playerNearbyEdges: {},

    _isHiddenDueToWar(claimKid, player) {
        const pKid = Core.Database.getOyuncuKrallikId(player.name);
        if (!pKid) return false;
        if (pKid === claimKid) return false;
        try { return !!Core.Diplomacy?.isAtWar?.(pKid, claimKid); } catch (e) { return false; }
    },

    checkProximityAndShowHUD(player) {
        const loc = player.location;
        if (!loc) return;

        const claims = this._getData();
        const dim    = player.dimension.id;
        const range  = this.CONFIG.EDGE_PROXIMITY_RANGE;
        const d      = Core.Database.load();

        const nearNow = new Set();

        for (const [id, claim] of Object.entries(claims)) {
            if (claim.dimension && claim.dimension !== dim) continue;
            if (!claim.vertices || claim.vertices.length < 3) continue;

            const kr = d.kralliklar?.[claim.krallik];
            if (!kr) continue;

            const hidden = this._isHiddenDueToWar(claim.krallik, player);

            for (const edge of this._getEdges(claim)) {
                const cp = this._closestPointOnSegment(loc.x, loc.z, edge.ax, edge.az, edge.bx, edge.bz);
                const signId = `${id}::${edge.key}`;

                if (cp.dist <= range && !hidden) {
                    nearNow.add(signId);
                    ClaimEdgeSignManager.ensureSign(claim, kr, { x: edge.midX, z: edge.midZ }, edge.key, player.dimension);
                } else if (hidden) {
                    // Savaşan taraf için: bu kenarın tabelası tamamen kaldırılır (kuşatma sırasında gizli).
                    ClaimEdgeSignManager.removeSign(id, edge.key);
                }
            }
        }

        // Artık kimsenin yakınında olmayan tabelaları temizle (basit GC: hiçbir oyuncu için "near" değilse kaldır)
        const stillNeeded = this._anyPlayerStillNearSign(claims, dim);
        for (const signId of Object.keys(ClaimEdgeSignManager._signs)) {
            if (!stillNeeded.has(signId)) {
                const [claimId, edgeKey] = signId.split("::");
                ClaimEdgeSignManager.removeSign(claimId, edgeKey);
            }
        }
    },

    _anyPlayerStillNearSign(claims, dim) {
        const range = this.CONFIG.EDGE_PROXIMITY_RANGE;
        const needed = new Set();
        const d = Core.Database.load();
        for (const player of world.getAllPlayers()) {
            if (player.dimension.id !== dim) continue;
            const loc = player.location;
            for (const [id, claim] of Object.entries(claims)) {
                if (claim.dimension && claim.dimension !== dim) continue;
                if (!claim.vertices || claim.vertices.length < 3) continue;
                if (this._isHiddenDueToWar(claim.krallik, player)) continue;
                for (const edge of this._getEdges(claim)) {
                    const cp = this._closestPointOnSegment(loc.x, loc.z, edge.ax, edge.az, edge.bx, edge.bz);
                    if (cp.dist <= range) needed.add(`${id}::${edge.key}`);
                }
            }
        }
        return needed;
    },

    // ============================================================
    // DIŞA AÇIK METODLAR
    // ============================================================

    showMenu(player) {
        this._showMainMenu(player);
    },

    getClaimAt(loc, dimensionId) {
        const claims = this._getData();
        for (const [id, claim] of Object.entries(claims)) {
            if (dimensionId && claim.dimension && claim.dimension !== dimensionId) continue;
            if (this._isPointInPolygon(loc.x, loc.z, claim.vertices)) {
                return { id, ...claim };
            }
        }
        return null;
    },

    _isPointInPolygon(x, z, vertices) {
        if (!vertices || vertices.length < 3) return false;
        let inside = false;
        for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
            const xi = vertices[i].x, zi = vertices[i].z;
            const xj = vertices[j].x, zj = vertices[j].z;
            if (((zi > z) !== (zj > z)) && (x < (xj - xi) * (z - zi) / ((zj - zi) || 1e-9) + xi)) {
                inside = !inside;
            }
        }
        return inside;
    },

    isProtected(player, loc) {
        const claim = this.getClaimAt(loc, player.dimension.id);
        if (!claim) return false;
        const kid = Core.Database.getOyuncuKrallikId(player.name);
        if (claim.krallik === kid) return false;
        if (Core.Diplomacy?.hasAccess?.(claim.krallik, kid)) return false;
        return true;
    },

    hasPermission(claimId, playerName) {
        if (!playerName) return false;
        const claim = this.getClaim(claimId);
        if (!claim) return false;
        const d       = Core.Database.load();
        const krallik = d.kralliklar?.[claim.krallik];
        if (!krallik) return false;
        if (krallik.lider === playerName) return true;
        if ((krallik.uyeler || []).includes(playerName)) return true;
        const playerKid = d.oyuncular?.[playerName];
        if (playerKid && Core.Diplomacy?.hasAccess?.(claim.krallik, playerKid)) return true;
        return false;
    },

    _recomputeClaimMeta(claim) {
        if (!claim?.vertices || claim.vertices.length < 3) return;

        let sumX = 0, sumZ = 0;
        let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;

        for (const v of claim.vertices) {
            sumX += v.x; sumZ += v.z;
            if (v.x < minX) minX = v.x;
            if (v.x > maxX) maxX = v.x;
            if (v.z < minZ) minZ = v.z;
            if (v.z > maxZ) maxZ = v.z;
        }

        const cx = sumX / claim.vertices.length;
        const cz = sumZ / claim.vertices.length;

        let maxDistSq = 0;
        for (const v of claim.vertices) {
            const dx = v.x - cx, dz = v.z - cz;
            const dSq = dx * dx + dz * dz;
            if (dSq > maxDistSq) maxDistSq = dSq;
        }

        claim.x      = Math.round(cx);
        claim.z      = Math.round(cz);
        claim.radius = Math.max(1, Math.ceil(Math.sqrt(maxDistSq)));
        claim._bbox  = { minX, maxX, minZ, maxZ };

        if (claim.level  === undefined) claim.level  = 1;
        if (claim.health === undefined) claim.health = 100;
        if (claim.shield === undefined) claim.shield = 0;
    },

    getKrallikClaims(kid) {
        const claims = this._getData();
        const result = [];
        for (const [id, claim] of Object.entries(claims)) {
            if (claim.krallik === kid) result.push({ id, ...claim });
        }
        return result;
    },

    tick() {
        for (const player of world.getAllPlayers()) {
            this.checkProximityAndShowHUD(player);
        }
    },

    showBorders() {},

    removeAllSignsForClaim(claimId) {
        ClaimEdgeSignManager.removeAllForClaim(claimId);
    },
};

// ============================================================
// HARİTA
// ============================================================
export const ClaimHarita = {
    komsulariGetir(kid, mesafe = 64) {
        const d     = Core.Database.load();
        const claim = ClaimManager.getKingdomClaim(kid);
        if (!claim) return [];

        const komsuKidSet = new Set();
        const claims      = ClaimManager._getData();

        for (const [cid, c] of Object.entries(claims)) {
            if (c.krallik === kid) continue;
            if (!c.vertices?.length) continue;
            let minDist = Infinity;
            for (const v1 of claim.vertices) {
                for (const v2 of c.vertices) {
                    const dx = v1.x - v2.x, dz = v1.z - v2.z;
                    const dist = Math.sqrt(dx * dx + dz * dz);
                    if (dist < minDist) minDist = dist;
                }
            }
            if (minDist <= mesafe) komsuKidSet.add(c.krallik);
        }

        return Array.from(komsuKidSet).map(k => ({
            kid:    k,
            isim:   d.kralliklar?.[k]?.isim || k,
            iliski: Core.Diplomacy?.getRelation?.(kid, k) ?? 0
        }));
    },

    toplamAlan(kid) {
        const claim = ClaimManager.getKingdomClaim(kid);
        return claim ? Math.floor(ClaimManager.getClaimArea(claim)) : 0;
    },

    claimBul(x, z, dimensionId) {
        return ClaimManager.getClaimAt({ x, z }, dimensionId);
    },

    renderText(player) {
        const ploc = player?.location;
        if (!ploc) return { text: "§7Konum alınamadı", legend: "" };
        const cx  = Math.floor(ploc.x), cz = Math.floor(ploc.z);
        const kid = Core.Database.getOyuncuKrallikId(player.name);
        const claim = ClaimManager.getKingdomClaim(kid || "");
        const lines = [];
        lines.push(`§7📍 Konum: §f(${cx}, ${cz})`);
        if (claim) {
            lines.push(`§7🏰 Toprak Alanı: §f${Math.floor(ClaimManager.getClaimArea(claim))} m²`);
            lines.push(`§7📐 Köşe Sayısı: §f${claim.vertices?.length || 0}`);
        } else {
            lines.push(`§7🏰 Toprak: §fYok`);
        }
        const komsular = kid ? this.komsulariGetir(kid) : [];
        if (komsular.length > 0) lines.push(`§7🗺 Komşular: §f${komsular.map(k => k.isim).join(", ")}`);
        return { text: lines.join("\n"), legend: "§8P=Sen  #=Toprağın  X=Düşman" };
    }
};
