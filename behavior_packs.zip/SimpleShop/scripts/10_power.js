// ============================================================
// MODÜL 10: POWER - Güç Sistemi (EKSİKSİZ)
// ============================================================
import { world } from "@minecraft/server";
import { Core } from "./00_core.js";
import { Config } from "./01_config.js";
import { ClaimManager } from "./02_claim.js";
import { Systems, AI } from "./04_military.js";
import { Diplomacy } from "./05_diplomacy.js";
import { Leaderboard } from "./06_kingdom.js";

export const Power = {
    _marketPrices: null,
    _powerHistoryCache: {},

    getMarketPrices() {
        if (this._marketPrices) return this._marketPrices;
        try {
            const raw = world.getDynamicProperty(Config.MARKET_PRICE_PROPERTY);
            this._marketPrices = raw ? JSON.parse(raw) : {};
        } catch(e) { this._marketPrices = {}; }
        return this._marketPrices;
    },

    calculateKrallikPower(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return 0;
        let totalPower = 0;

        // Asker gücü
        const askerler = Core.Cache?.getKrallikEntities?.(kid) || [];
        for (const asker of askerler) {
            const tip = AI._getSoldierType(asker);
            const askerConfig = Config.ASKERLER[tip];
            if (!askerConfig) continue;
            let power = askerConfig.fiyat * 0.5;
            const kayit = d.askerKayit?.[asker.id];
            if (kayit) {
                const rank = Systems.getAskerRank(kayit.kill || 0);
                power *= rank.bonus;
                power *= (1 + ((kayit.level || 1) - 1) * 0.1);
            }
            totalPower += power;
        }

        // Claim gücü
        const claims = ClaimManager.getKrallikClaims(kid);
        totalPower += claims.length * 10000 * (1 + (k.gelisimAgaci?.savunma || 0) * 0.05);

        // Hazine gücü
        totalPower += (k.hazine || 0) * 0.5;

        // İttifak bonusu: her müttefik +%2
        try {
            const ittifakCount = Diplomacy.getAllies?.(kid)?.length ?? (k.muttefikler || []).length;
            totalPower *= (1 + ittifakCount * 0.02);
        } catch(e) {}

        // Gelişim ağacı bonusları
        const askeriGelisim = k.gelisimAgaci?.askeri || 0;
        totalPower *= (1 + askeriGelisim * 0.05);
        
        const ekonomiGelisim = k.gelisimAgaci?.ekonomi || 0;
        totalPower *= (1 + ekonomiGelisim * 0.03);

        // Krallık seviye bonusu
        totalPower *= (1 + (k.seviye || 1) * 0.1);

        // Moral bonusu (moral > 70 ise +%20, moral < 30 ise -%20)
        const moral = k.moral || 60;
        if (moral > 70) totalPower *= 1.2;
        if (moral < 30) totalPower *= 0.8;

        // Savaş durumu (savaşta güç gösterimi +%15)
        if (k.status === "savas" || k.status === "kusatma") totalPower *= 1.15;

        k.totalPower = Math.floor(totalPower);
        
        // Periyodik leaderboard kayıtları
        try {
            Leaderboard.recordKingdomStat?.(kid, "totalPower", k.totalPower);
            Leaderboard.recordKingdomStat?.(kid, "hazine", k.hazine || 0);
            Leaderboard.recordKingdomStat?.(kid, "claimCount", claims.length);
            Leaderboard.recordKingdomStat?.(kid, "askerCount", askerler.length);
        } catch(e) {}
        
        Core.Database.markDirty("krallik_core");
        return k.totalPower;
    },

    formatPower(power) {
        if (power >= 1000000) return (power / 1000000).toFixed(1) + "M";
        if (power >= 1000) return (power / 1000).toFixed(1) + "K";
        return power.toString();
    },

    // Krallık sıralaması (en güçlü 10)
    getTopKingdoms(limit = 10) {
        const d = Core.Database.load();
        const kingdoms = [];
        for (const [kid, k] of Object.entries(d.kralliklar || {})) {
            kingdoms.push({
                id: kid,
                name: k.isim,
                power: k.totalPower || 0,
                leader: k.lider,
                level: k.seviye || 1,
                moral: k.moral || 60,
                claimCount: ClaimManager.getKrallikClaims(kid).length,
                askerCount: Core.Cache?.getKrallikEntityCount?.(kid) || 0
            });
        }
        kingdoms.sort((a, b) => b.power - a.power);
        return kingdoms.slice(0, limit);
    },

    // Oyuncu sıralaması (en güçlü oyuncular)
    getTopPlayers(limit = 10) {
        const d = Core.Database.load();
        const players = [];
        for (const [name, profile] of Object.entries(d.profiles || {})) {
            const kid = d.oyuncular?.[name];
            const krallik = kid ? d.kralliklar?.[kid] : null;
            players.push({
                name: name,
                power: profile.guc || 0,
                kingdomPower: krallik?.totalPower || 0,
                kingdomName: krallik?.isim || "Yok",
                kill: profile.kill || 0,
                death: profile.death || 0,
                onlineSure: profile.onlineSure || 0
            });
        }
        players.sort((a, b) => b.power - a.power);
        return players.slice(0, limit);
    },

    // Krallık güç geçmişi (son 7 gün)
    getPowerHistory(kid, days = 7) {
        const d = Core.Database.load();
        const history = d.powerHistory?.[kid] || [];
        const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
        const filtered = history.filter(h => h.timestamp > cutoff).slice(-days * 4);
        
        // Her gün için ortalama al (4 kayıt/gün varsayalım)
        const dailyAvg = [];
        const dayMap = new Map();
        for (const h of filtered) {
            const day = Math.floor(h.timestamp / 86400000);
            if (!dayMap.has(day)) dayMap.set(day, { sum: 0, count: 0 });
            const entry = dayMap.get(day);
            entry.sum += h.power;
            entry.count++;
        }
        for (const [day, data] of dayMap) {
            dailyAvg.push({ day: new Date(day * 86400000).toISOString().slice(0,10), power: Math.floor(data.sum / data.count) });
        }
        return dailyAvg.sort((a, b) => a.day.localeCompare(b.day));
    },

    recordPowerHistory() {
        const d = Core.Database.load();
        if (!d.powerHistory) d.powerHistory = {};
        const now = Date.now();
        for (const [kid, k] of Object.entries(d.kralliklar || {})) {
            if (!d.powerHistory[kid]) d.powerHistory[kid] = [];
            d.powerHistory[kid].push({
                timestamp: now,
                power: k.totalPower || 0,
                hazine: k.hazine || 0,
                askerCount: Core.Cache?.getKrallikEntityCount?.(kid) || 0,
                claimCount: ClaimManager.getKrallikClaims(kid).length,
                moral: k.moral || 60
            });
            if (d.powerHistory[kid].length > 120) d.powerHistory[kid].shift();
        }
        Core.Database.markDirty("krallik_economy");
    },

    // Güç karşılaştırma
    compareKingdoms(kidA, kidB) {
        const d = Core.Database.load();
        const kA = d.kralliklar[kidA];
        const kB = d.kralliklar[kidB];
        if (!kA || !kB) return null;
        
        const powerA = kA.totalPower || 0;
        const powerB = kB.totalPower || 0;
        const ratio = powerB === 0 ? Infinity : powerA / powerB;
        
        let result = "§eEşit güçte";
        let advantage = "equal";
        if (ratio > 1.5) { result = `§a${kA.isim} §fçok daha güçlü (${Math.round(ratio * 100)}%)`; advantage = "A_strong"; }
        else if (ratio > 1.2) { result = `§a${kA.isim} §fdaha güçlü (${Math.round(ratio * 100)}%)`; advantage = "A_advantage"; }
        else if (ratio < 0.67) { result = `§c${kB.isim} §fçok daha güçlü (${Math.round((1/ratio) * 100)}%)`; advantage = "B_strong"; }
        else if (ratio < 0.83) { result = `§c${kB.isim} §fdaha güçlü (${Math.round((1/ratio) * 100)}%)`; advantage = "B_advantage"; }
        
        return {
            kidA, kidB,
            nameA: kA.isim, nameB: kB.isim,
            powerA, powerB,
            ratio: ratio,
            result: result,
            advantage: advantage,
            details: {
                hazineA: kA.hazine || 0, hazineB: kB.hazine || 0,
                askerA: Core.Cache?.getKrallikEntityCount?.(kidA) || 0,
                askerB: Core.Cache?.getKrallikEntityCount?.(kidB) || 0,
                claimA: ClaimManager.getKrallikClaims(kidA).length,
                claimB: ClaimManager.getKrallikClaims(kidB).length,
                moralA: kA.moral || 60, moralB: kB.moral || 60,
                levelA: kA.seviye || 1, levelB: kB.seviye || 1
            }
        };
    },

    // Güç hesaplama için detaylı rapor
    getPowerReport(kid) {
        const d = Core.Database.load();
        const k = d.kralliklar[kid];
        if (!k) return null;
        
        const askerler = Core.Cache?.getKrallikEntities?.(kid) || [];
        let askerPower = 0;
        const askerDetails = {};
        
        for (const asker of askerler) {
            const tip = AI._getSoldierType(asker);
            const askerConfig = Config.ASKERLER[tip];
            if (!askerConfig) continue;
            let power = askerConfig.fiyat * 0.5;
            const kayit = d.askerKayit?.[asker.id];
            if (kayit) {
                const rank = Systems.getAskerRank(kayit.kill || 0);
                power *= rank.bonus;
                power *= (1 + ((kayit.level || 1) - 1) * 0.1);
            }
            askerPower += power;
            askerDetails[tip] = (askerDetails[tip] || 0) + 1;
        }
        
        const claims = ClaimManager.getKrallikClaims(kid);
        const claimPower = claims.length * 10000 * (1 + (k.gelisimAgaci?.savunma || 0) * 0.05);
        const hazinePower = (k.hazine || 0) * 0.5;
        
        const ittifakCount = Diplomacy.getAllies?.(kid)?.length ?? (k.muttefikler || []).length;
        const allianceBonus = 1 + (ittifakCount * 0.02);
        
        const askeriGelisim = k.gelisimAgaci?.askeri || 0;
        const ekonomiGelisim = k.gelisimAgaci?.ekonomi || 0;
        const gelisimBonus = (1 + askeriGelisim * 0.05) * (1 + ekonomiGelisim * 0.03);
        
        const levelBonus = 1 + (k.seviye || 1) * 0.1;
        const moral = k.moral || 60;
        const moralBonus = moral > 70 ? 1.2 : (moral < 30 ? 0.8 : 1.0);
        const warBonus = (k.status === "savas" || k.status === "kusatma") ? 1.15 : 1.0;
        
        const rawTotal = askerPower + claimPower + hazinePower;
        const finalTotal = Math.floor(rawTotal * allianceBonus * gelisimBonus * levelBonus * moralBonus * warBonus);
        
        return {
            kid,
            name: k.isim,
            rawTotal: Math.floor(rawTotal),
            finalTotal: finalTotal,
            components: {
                askerPower: Math.floor(askerPower),
                claimPower: Math.floor(claimPower),
                hazinePower: Math.floor(hazinePower)
            },
            multipliers: {
                allianceBonus: allianceBonus,
                gelisimBonus: gelisimBonus,
                levelBonus: levelBonus,
                moralBonus: moralBonus,
                warBonus: warBonus
            },
            details: {
                askerCount: askerler.length,
                askerDetails: askerDetails,
                claimCount: claims.length,
                hazine: k.hazine || 0,
                ittifakCount: ittifakCount,
                askeriGelisim: askeriGelisim,
                ekonomiGelisim: ekonomiGelisim,
                seviye: k.seviye || 1,
                moral: moral,
                status: k.status || "baris"
            }
        };
    },

    // Güç tahmini (yeni claim/asker eklenirse ne olur)
    estimatePowerChange(kid, newClaims = 0, newSoldiers = 0, newHazine = 0) {
        const current = this.getPowerReport(kid);
        if (!current) return null;
        
        const newAskerPower = current.components.askerPower + (newSoldiers * 1500); // yaklaşık asker başı
        const newClaimPower = current.components.claimPower + (newClaims * 10000);
        const newHazinePower = current.components.hazinePower + (newHazine * 0.5);
        
        const newRaw = newAskerPower + newClaimPower + newHazinePower;
        const newTotal = Math.floor(newRaw * current.multipliers.allianceBonus * current.multipliers.gelisimBonus * 
            current.multipliers.levelBonus * current.multipliers.moralBonus * current.multipliers.warBonus);
        
        return {
            currentPower: current.finalTotal,
            estimatedPower: newTotal,
            increase: newTotal - current.finalTotal,
            percentageIncrease: ((newTotal - current.finalTotal) / current.finalTotal * 100).toFixed(1)
        };
    },

    // Düşmanlık seviyesine göre savaş riski
    getWarRisk(kidA, kidB) {
        const powerComp = this.compareKingdoms(kidA, kidB);
        if (!powerComp) return null;
        
        const d = Core.Database.load();
        const relation = Diplomacy.getRelation?.(kidA, kidB) || 0;
        const atWar = Diplomacy.isAtWar?.(kidA, kidB) || false;
        const allied = Diplomacy.isAllied?.(kidA, kidB) || false;
        
        let riskLevel = "düşük";
        let riskColor = "§a";
        let riskScore = 0;
        
        if (atWar) { riskLevel = "savaşta"; riskColor = "§c"; riskScore = 100; }
        else if (allied) { riskLevel = "müttefik"; riskColor = "§a"; riskScore = 0; }
        else if (relation < -50) { riskLevel = "yüksek"; riskColor = "§c"; riskScore = 80; }
        else if (relation < -20) { riskLevel = "orta"; riskColor = "§e"; riskScore = 50; }
        else if (relation < 0) { riskLevel = "düşük"; riskColor = "§a"; riskScore = 20; }
        else { riskLevel = "çok düşük"; riskColor = "§2"; riskScore = 5; }
        
        // Güç farkı riski artırır/azaltır
        if (powerComp.advantage === "A_strong" && riskScore > 0) riskScore = Math.min(100, riskScore + 20);
        if (powerComp.advantage === "B_strong" && riskScore > 0) riskScore = Math.max(0, riskScore - 20);
        
        return {
            kidA, kidB,
            nameA: powerComp.nameA, nameB: powerComp.nameB,
            powerA: powerComp.powerA, powerB: powerComp.powerB,
            relation: relation,
            atWar: atWar,
            allied: allied,
            riskLevel: riskColor + riskLevel,
            riskScore: riskScore,
            recommendation: riskScore > 70 ? "Savaşa hazırlan!" : (riskScore > 40 ? "Dikkatli ol" : "Güvenli")
        };
    }
};