replaceitem entity @s slot.armor.chest 1 knights:napoleonic_spanish_cuirassier_armour
replaceitem entity @s slot.weapon.mainhand 0 air