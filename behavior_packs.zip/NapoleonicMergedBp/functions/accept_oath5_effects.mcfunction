gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_accept_oath5,location=slot.weapon.offhand}] add spanish
tag @a[hasitem={item=knights:napoleonic_accept_oath5,location=slot.weapon.offhand}] remove spanish_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath5,location=slot.weapon.offhand}] add english_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath5,location=slot.weapon.offhand}] add german_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath5,location=slot.weapon.offhand}] add russian_enemy