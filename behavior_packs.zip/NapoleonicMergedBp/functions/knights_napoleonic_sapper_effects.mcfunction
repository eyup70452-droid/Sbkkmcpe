effect @e[hasitem={item=knights:napoleonic_british_sapper_uniform,location=slot.armor.chest}] haste 1 1 true
effect @e[hasitem={item=knights:napoleonic_french_sapper_uniform,location=slot.armor.chest}] haste 1 1 true
effect @e[hasitem={item=knights:napoleonic_german_sapper_uniform,location=slot.armor.chest}] haste 1 1 true
effect @e[hasitem={item=knights:napoleonic_italian_sapper_uniform,location=slot.armor.chest}] haste 1 1 true
effect @e[hasitem={item=knights:napoleonic_spanish_sapper_uniform,location=slot.armor.chest}] haste 1 1 true
effect @e[hasitem={item=knights:napoleonic_russian_sapper_uniform,location=slot.armor.chest}] haste 1 1 true