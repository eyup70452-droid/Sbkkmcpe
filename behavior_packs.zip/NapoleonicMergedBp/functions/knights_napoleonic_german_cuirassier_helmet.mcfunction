replaceitem entity @s slot.armor.head 1 knights:napoleonic_german_cuirassier_helmet
replaceitem entity @s slot.weapon.mainhand 0 air