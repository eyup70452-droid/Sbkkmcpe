gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_accept_oath4,location=slot.weapon.offhand}] add italian
tag @a[hasitem={item=knights:napoleonic_accept_oath4,location=slot.weapon.offhand}] remove italian_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath4,location=slot.weapon.offhand}] add english_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath4,location=slot.weapon.offhand}] add german_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath4,location=slot.weapon.offhand}] add russian_enemy