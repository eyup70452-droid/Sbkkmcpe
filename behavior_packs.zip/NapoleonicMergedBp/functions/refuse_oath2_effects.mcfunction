gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_refuse_oath2,location=slot.weapon.offhand}] remove french
tag @a[hasitem={item=knights:napoleonic_refuse_oath2,location=slot.weapon.offhand}] add french_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath2,location=slot.weapon.offhand}] remove english_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath2,location=slot.weapon.offhand}] remove german_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath2,location=slot.weapon.offhand}] remove russian_enemy