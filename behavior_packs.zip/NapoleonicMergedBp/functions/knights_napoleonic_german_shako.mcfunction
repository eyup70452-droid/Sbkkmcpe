replaceitem entity @s slot.armor.head 1 knights:napoleonic_german_shako
replaceitem entity @s slot.weapon.mainhand 0 air