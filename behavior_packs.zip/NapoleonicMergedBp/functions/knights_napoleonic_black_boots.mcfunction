replaceitem entity @s slot.armor.feet 1 knights:napoleonic_black_boots
replaceitem entity @s slot.weapon.mainhand 0 air