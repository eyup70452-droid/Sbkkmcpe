gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_refuse_oath3,location=slot.weapon.offhand}] remove german
tag @a[hasitem={item=knights:napoleonic_refuse_oath3,location=slot.weapon.offhand}] add german_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath3,location=slot.weapon.offhand}] remove french_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath3,location=slot.weapon.offhand}] remove italian_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath3,location=slot.weapon.offhand}] remove spanish_enemy