gamerule sendcommandfeedback false
gamerule commandblockoutput false
execute as @e [type=horse] at @s  positioned  ~ ~1 ~ if entity @e [family=player,c=1,r=1] run effect @s resistance 1 2 true
execute as @a [hasitem={item=knights:napoleonic_steel_spear,location=slot.weapon.mainhand}] at @s positioned ~ ~-1 ~ if entity @e[c=1,type=horse,r=1] run effect @s strength 1 2 true