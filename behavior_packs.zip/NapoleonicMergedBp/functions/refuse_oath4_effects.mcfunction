gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_refuse_oath4,location=slot.weapon.offhand}] remove italian
tag @a[hasitem={item=knights:napoleonic_refuse_oath4,location=slot.weapon.offhand}] add italian_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath4,location=slot.weapon.offhand}] remove english_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath4,location=slot.weapon.offhand}] remove german_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath4,location=slot.weapon.offhand}] remove russian_enemy