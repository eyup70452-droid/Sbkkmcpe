replaceitem entity @s slot.armor.chest 1 knights:napoleonic_russian_uniform
replaceitem entity @s slot.weapon.mainhand 0 air