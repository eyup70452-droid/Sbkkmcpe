gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_accept_oath6,location=slot.weapon.offhand}] add russian
tag @a[hasitem={item=knights:napoleonic_accept_oath6,location=slot.weapon.offhand}] remove russian_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath6,location=slot.weapon.offhand}] add french_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath6,location=slot.weapon.offhand}] add italian_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath6,location=slot.weapon.offhand}] add spanish_enemy