gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_accept_oath2,location=slot.weapon.offhand}] add french
tag @a[hasitem={item=knights:napoleonic_accept_oath2,location=slot.weapon.offhand}] remove french_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath2,location=slot.weapon.offhand}] add english_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath2,location=slot.weapon.offhand}] add german_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath2,location=slot.weapon.offhand}] add russian_enemy