gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_refuse_oath1,location=slot.weapon.offhand}] remove english
tag @a[hasitem={item=knights:napoleonic_refuse_oath1,location=slot.weapon.offhand}] add english_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath1,location=slot.weapon.offhand}] remove french_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath1,location=slot.weapon.offhand}] remove italian_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath1,location=slot.weapon.offhand}] remove spanish_enemy