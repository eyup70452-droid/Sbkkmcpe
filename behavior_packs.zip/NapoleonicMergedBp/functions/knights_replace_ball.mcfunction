gamerule sendcommandfeedback false
gamerule commandblockoutput false
execute as @e [hasitem={item=knights:napoleonic_cannon_ball_item,location=slot.weapon.mainhand}] at @s positioned ~ ~0.5 ~ if entity @e [c=1,type=knights:napoleonic_cannon,r=1.5] run replaceitem entity @s slot.weapon.mainhand 1 knights:napoleonic_cannon_ball_throwable