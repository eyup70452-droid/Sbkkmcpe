gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_accept_oath1,location=slot.weapon.offhand}] add english
tag @a[hasitem={item=knights:napoleonic_accept_oath1,location=slot.weapon.offhand}] remove english_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath1,location=slot.weapon.offhand}] add french_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath1,location=slot.weapon.offhand}] add italian_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath1,location=slot.weapon.offhand}] add spanish_enemy