replaceitem entity @s slot.armor.head 1 knights:napoleonic_spanish_shako
replaceitem entity @s slot.weapon.mainhand 0 air