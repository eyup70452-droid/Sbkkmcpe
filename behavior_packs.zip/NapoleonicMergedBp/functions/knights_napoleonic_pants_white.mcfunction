replaceitem entity @s slot.armor.legs 1 knights:napoleonic_pants_white
replaceitem entity @s slot.weapon.mainhand 0 air