gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_refuse_oath6,location=slot.weapon.offhand}] remove russian
tag @a[hasitem={item=knights:napoleonic_refuse_oath6,location=slot.weapon.offhand}] add russian_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath6,location=slot.weapon.offhand}] remove french_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath6,location=slot.weapon.offhand}] remove italian_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath6,location=slot.weapon.offhand}] remove spanish_enemy