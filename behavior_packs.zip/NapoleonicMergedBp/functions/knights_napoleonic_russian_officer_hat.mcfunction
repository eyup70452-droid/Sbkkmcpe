replaceitem entity @s slot.armor.head 1 knights:napoleonic_russian_officer_hat
replaceitem entity @s slot.weapon.mainhand 0 air