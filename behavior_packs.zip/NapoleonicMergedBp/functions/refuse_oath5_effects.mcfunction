gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_refuse_oath5,location=slot.weapon.offhand}] remove spanish
tag @a[hasitem={item=knights:napoleonic_refuse_oath5,location=slot.weapon.offhand}] add spanish_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath5,location=slot.weapon.offhand}] remove english_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath5,location=slot.weapon.offhand}] remove german_enemy
tag @a[hasitem={item=knights:napoleonic_refuse_oath5,location=slot.weapon.offhand}] remove russian_enemy