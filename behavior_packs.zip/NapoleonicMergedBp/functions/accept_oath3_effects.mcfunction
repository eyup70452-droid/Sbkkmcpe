gamerule sendcommandfeedback false
gamerule commandblockoutput false
tag @a[hasitem={item=knights:napoleonic_accept_oath3,location=slot.weapon.offhand}] add german
tag @a[hasitem={item=knights:napoleonic_accept_oath3,location=slot.weapon.offhand}] remove german_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath3,location=slot.weapon.offhand}] add french_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath3,location=slot.weapon.offhand}] add italian_enemy
tag @a[hasitem={item=knights:napoleonic_accept_oath3,location=slot.weapon.offhand}] add spanish_enemy